"""
数据模型定义 - 定义抗震节点设计中涉及的所有数据结构
"""

from pydantic import BaseModel, Field, field_validator
from typing import List, Optional, Dict, Any, Tuple, Union
from enum import Enum
from datetime import datetime
import uuid


class BoltGrade(str, Enum):
    """螺栓性能等级"""
    Q235 = "Q235"
    Q345 = "Q345"
    Q390 = "Q390"
    Q420 = "Q420"
    Q460 = "Q460"


class BoltDiameter(float, Enum):
    """螺栓直径(mm)"""
    M12 = 12.0
    M16 = 16.0
    M20 = 20.0
    M22 = 22.0
    M24 = 24.0
    M27 = 27.0
    M30 = 30.0


class SteelGrade(str, Enum):
    """钢材牌号"""
    Q235B = "Q235B"
    Q235C = "Q235C"
    Q345B = "Q345B"
    Q345C = "Q345C"
    Q345D = "Q345D"
    Q390C = "Q390C"
    Q390D = "Q390D"
    Q420C = "Q420C"
    Q420D = "Q420D"


class SeismicIntensity(int, Enum):
    """地震烈度"""
    VI = 6
    VII = 7
    VIII = 8
    IX = 9


class SiteClass(str, Enum):
    """场地类别"""
    I0 = "I0"
    I1 = "I1"
    II = "II"
    III = "III"
    IV = "IV"


class DesignGroup(int, Enum):
    """设计地震分组"""
    FIRST = 1
    SECOND = 2
    THIRD = 3


class ConnectionType(str, Enum):
    """节点连接类型"""
    END_PLATE = "端板连接"
    HEADER_PLATE = "腹板连接"
    WELDED = "全焊接"
    MIXED = "栓焊混合"


class LoadCase(BaseModel):
    """荷载工况"""
    name: str = Field(..., description="工况名称")
    dead_load: float = Field(..., ge=0, description="恒载(kN)")
    live_load: float = Field(..., ge=0, description="活载(kN)")
    wind_load: float = Field(default=0, ge=0, description="风荷载(kN)")
    earthquake_load: float = Field(default=0, ge=0, description="地震作用(kN)")
    temperature_load: float = Field(default=0, description="温度作用(kN·m)")

    @field_validator('dead_load', 'live_load')
    @classmethod
    def validate_positive(cls, v):
        if v < 0:
            raise ValueError('荷载值不能为负数')
        return v


class LoadCombination(BaseModel):
    """荷载组合"""
    name: str = Field(..., description="组合名称")
    factor_dead: float = Field(default=1.2, description="恒载分项系数")
    factor_live: float = Field(default=1.4, description="活载分项系数")
    factor_wind: float = Field(default=1.4, description="风载分项系数")
    factor_earthquake: float = Field(default=1.3, description="地震作用分项系数")
    factor_temperature: float = Field(default=1.0, description="温度作用分项系数")
    combination_value_live: float = Field(default=0.7, description="活载组合值系数")
    combination_value_wind: float = Field(default=0.6, description="风载组合值系数")

    def calculate_design_moment(
        self,
        load_cases: List[LoadCase],
        span_length: float
    ) -> float:
        """计算设计弯矩"""
        total_moment = 0.0
        for lc in load_cases:
            moment = (self.factor_dead * lc.dead_load +
                     self.factor_live * lc.live_load * self.combination_value_live +
                     self.factor_wind * lc.wind_load * self.combination_value_wind +
                     self.factor_earthquake * lc.earthquake_load) * span_length / 8
            total_moment = max(total_moment, moment)
        return total_moment

    def calculate_design_shear(
        self,
        load_cases: List[LoadCase]
    ) -> float:
        """计算设计剪力"""
        total_shear = 0.0
        for lc in load_cases:
            shear = (self.factor_dead * lc.dead_load +
                    self.factor_live * lc.live_load * self.combination_value_live +
                    self.factor_wind * lc.wind_load * self.combination_value_wind +
                    self.factor_earthquake * lc.earthquake_load) / 2
            total_shear = max(total_shear, shear)
        return total_shear


class BeamSection(BaseModel):
    """梁截面参数"""
    name: str = Field(..., description="截面名称")
    height: float = Field(..., gt=0, description="梁高(mm)")
    width: float = Field(..., gt=0, description="翼缘宽(mm)")
    web_thickness: float = Field(..., gt=0, description="腹板厚度(mm)")
    flange_thickness: float = Field(..., gt=0, description="翼缘厚度(mm)")
    root_radius: float = Field(default=16, ge=0, description="圆角半径(mm)")
    steel_grade: SteelGrade = Field(default=SteelGrade.Q345B, description="钢材牌号")

    @property
    def moment_of_inertia_x(self) -> float:
        """计算对x轴惯性矩(mm^4)"""
        h = self.height
        b = self.width
        tw = self.web_thickness
        tf = self.flange_thickness
        Ix = (b * h**3 / 12) - ((b - tw) * (h - 2*tf)**3 / 12)
        return Ix

    @property
    def section_modulus_x(self) -> float:
        """计算截面模量(mm^3)"""
        return self.moment_of_inertia_x / (self.height / 2)

    @property
    def plastic_section_modulus_x(self) -> float:
        """计算塑性截面模量(mm^3)"""
        h = self.height
        b = self.width
        tw = self.web_thickness
        tf = self.flange_thickness
        Wpx = b * tf * (h - tf) + tw * (h - 2*tf)**2 / 4
        return Wpx

    @property
    def area(self) -> float:
        """截面面积(mm^2)"""
        h = self.height
        b = self.width
        tw = self.web_thickness
        tf = self.flange_thickness
        A = 2 * b * tf + (h - 2*tf) * tw
        return A


class ColumnSection(BaseModel):
    """柱截面参数"""
    name: str = Field(..., description="截面名称")
    height: float = Field(..., gt=0, description="柱高(mm)")
    width: float = Field(..., gt=0, description="柱宽(mm)")
    web_thickness: float = Field(..., gt=0, description="腹板厚度(mm)")
    flange_thickness: float = Field(..., gt=0, description="翼缘厚度(mm)")
    steel_grade: SteelGrade = Field(default=SteelGrade.Q345B, description="钢材牌号")

    @property
    def moment_of_inertia_x(self) -> float:
        """计算对x轴惯性矩(mm^4)"""
        h = self.height
        b = self.width
        tw = self.web_thickness
        tf = self.flange_thickness
        Ix = (b * h**3 / 12) - ((b - tw) * (h - 2*tf)**3 / 12)
        return Ix

    @property
    def moment_of_inertia_y(self) -> float:
        """计算对y轴惯性矩(mm^4)"""
        h = self.height
        b = self.width
        tw = self.web_thickness
        tf = self.flange_thickness
        Iy = (h * b**3 / 12) - ((h - 2*tf) * (b - tw)**3 / 12)
        return Iy

    @property
    def area(self) -> float:
        """截面面积(mm^2)"""
        h = self.height
        b = self.width
        tw = self.web_thickness
        tf = self.flange_thickness
        A = 2 * b * tf + (h - 2*tf) * tw
        return A


class Stiffener(BaseModel):
    """加劲肋参数"""
    thickness: float = Field(..., gt=0, description="加劲肋厚度(mm)")
    width: float = Field(..., gt=0, description="加劲肋宽度(mm)")
    height: float = Field(default=0, ge=0, description="加劲肋高度(mm,0表示与梁等高)")
    steel_grade: SteelGrade = Field(default=SteelGrade.Q345B, description="钢材牌号")

    @field_validator('thickness')
    @classmethod
    def validate_thickness(cls, v):
        if v < 8 or v > 50:
            raise ValueError('加劲肋厚度应在8-50mm之间')
        return v


class WeldDetail(BaseModel):
    """焊缝参数"""
    weld_size: float = Field(..., gt=0, description="焊脚尺寸(mm)")
    weld_length: float = Field(..., gt=0, description="焊缝长度(mm)")
    weld_type: str = Field(default="角焊缝", description="焊缝类型")
    weld_grade: str = Field(default="二级", description="焊缝质量等级")

    @field_validator('weld_size')
    @classmethod
    def validate_weld_size(cls, v):
        if v < 3 or v > 20:
            raise ValueError('焊脚尺寸应在3-20mm之间')
        return v


class BoltLayout(BaseModel):
    """螺栓布置参数"""
    bolt_diameter: BoltDiameter = Field(..., description="螺栓直径(mm)")
    bolt_grade: BoltGrade = Field(default=BoltGrade.Q235, description="螺栓性能等级")
    bolt_number_x: int = Field(..., ge=2, description="x方向螺栓数量")
    bolt_number_y: int = Field(..., ge=2, description="y方向螺栓数量")
    bolt_spacing_x: float = Field(..., ge=60, description="x方向螺栓间距(mm)")
    bolt_spacing_y: float = Field(..., ge=60, description="y方向螺栓间距(mm)")
    edge_distance_x: float = Field(default=40, ge=25, description="x方向边距(mm)")
    edge_distance_y: float = Field(default=40, ge=25, description="y方向边距(mm)")
    initial_tension: float = Field(default=0, description="预拉力(kN)")

    @field_validator('bolt_spacing_x', 'bolt_spacing_y')
    @classmethod
    def validate_spacing(cls, v):
        if v < 60:
            raise ValueError('螺栓间距不应小于60mm')
        return v

    def calculate_bolt_capacity(self) -> float:
        """计算单个螺栓承载力设计值(kN)"""
        d = self.bolt_diameter.value
        if self.bolt_grade == BoltGrade.Q235:
            fb = 170
        elif self.bolt_grade == BoltGrade.Q345:
            fb = 215
        elif self.bolt_grade == BoltGrade.Q390:
            fb = 235
        elif self.bolt_grade == BoltGrade.Q420:
            fb = 255
        else:
            fb = 280

        Ae = 3.14159 * d**2 / 4
        Nv = 0.9 * fb * Ae / 1000
        return Nv

    @property
    def total_bolts(self) -> int:
        """螺栓总数"""
        return self.bolt_number_x * self.bolt_number_y


class EndPlate(BaseModel):
    """端板参数"""
    thickness: float = Field(..., gt=0, description="端板厚度(mm)")
    width: float = Field(..., gt=0, description="端板宽度(mm)")
    height: float = Field(..., gt=0, description="端板高度(mm)")
    steel_grade: SteelGrade = Field(default=SteelGrade.Q345B, description="钢材牌号")
    stiffener: Optional[Stiffener] = Field(default=None, description="加劲肋")

    @field_validator('thickness')
    @classmethod
    def validate_thickness(cls, v):
        if v < 12 or v > 80:
            raise ValueError('端板厚度应在12-80mm之间')
        return v

    @property
    def moment_of_inertia(self) -> float:
        """端板截面惯性矩(mm^4)"""
        b = self.width
        h = self.thickness
        return b * h**3 / 12

    @property
    def section_modulus(self) -> float:
        """端板截面模量(mm^3)"""
        return self.moment_of_inertia / (self.thickness / 2)


class MaterialProperties(BaseModel):
    """材料属性"""
    yield_strength: float = Field(..., gt=0, description="屈服强度(MPa)")
    ultimate_strength: float = Field(..., gt=0, description="极限强度(MPa)")
    elastic_modulus: float = Field(default=206000, gt=0, description="弹性模量(MPa)")
    poisson_ratio: float = Field(default=0.3, gt=0, lt=1, description="泊松比")
    density: float = Field(default=7850, gt=0, description="密度(kg/m³)")
    elongation: float = Field(default=22, ge=0, description="伸长率(%)")
    charpy_impact: float = Field(default=34, ge=0, description="冲击功(J)")

    def get_steel_material(self, grade: SteelGrade) -> 'MaterialProperties':
        """根据钢材牌号获取材料属性"""
        steel_data = {
            SteelGrade.Q235B: {"fy": 235, "fu": 370, "E": 206000},
            SteelGrade.Q235C: {"fy": 235, "fu": 370, "E": 206000},
            SteelGrade.Q345B: {"fy": 345, "fu": 470, "E": 206000},
            SteelGrade.Q345C: {"fy": 345, "fu": 470, "E": 206000},
            SteelGrade.Q345D: {"fy": 345, "fu": 470, "E": 206000},
            SteelGrade.Q390C: {"fy": 390, "fu": 490, "E": 206000},
            SteelGrade.Q390D: {"fy": 390, "fu": 490, "E": 206000},
            SteelGrade.Q420C: {"fy": 420, "fu": 520, "E": 206000},
            SteelGrade.Q420D: {"fy": 420, "fu": 520, "E": 206000},
        }
        data = steel_data.get(grade, steel_data[SteelGrade.Q345B])
        return MaterialProperties(
            yield_strength=data["fy"],
            ultimate_strength=data["fu"],
            elastic_modulus=data["E"]
        )


class SeismicDesignParams(BaseModel):
    """抗震设计参数"""
    intensity: SeismicIntensity = Field(..., description="地震烈度")
    site_class: SiteClass = Field(..., description="场地类别")
    design_group: DesignGroup = Field(..., description="设计地震分组")
    design_life: int = Field(default=50, gt=0, description="设计使用年限(年)")
    importance_factor: float = Field(default=1.0, ge=1.0, description="重要性系数")
    response_modification: float = Field(default=3.0, gt=0, description="承载力抗震调整系数")
    additional_damping: float = Field(default=0.05, ge=0, description="附加阻尼比")
    overstrength_factor: float = Field(default=1.0, ge=1.0, description="超强系数")

    @property
    def peak_ground_acceleration(self) -> float:
        """峰值地面加速度(g)"""
        pga_map = {
            SeismicIntensity.VI: 0.05,
            SeismicIntensity.VII: 0.10,
            SeismicIntensity.VIII: 0.20,
            SeismicIntensity.IX: 0.40
        }
        return pga_map.get(self.intensity, 0.10)

    @property
    def characteristic_period(self) -> float:
        """特征周期(s)"""
        Tg_map = {
            (SiteClass.I0, DesignGroup.FIRST): 0.20,
            (SiteClass.I0, DesignGroup.SECOND): 0.25,
            (SiteClass.I0, DesignGroup.THIRD): 0.30,
            (SiteClass.I1, DesignGroup.FIRST): 0.25,
            (SiteClass.I1, DesignGroup.SECOND): 0.30,
            (SiteClass.I1, DesignGroup.THIRD): 0.35,
            (SiteClass.II, DesignGroup.FIRST): 0.35,
            (SiteClass.II, DesignGroup.SECOND): 0.40,
            (SiteClass.II, DesignGroup.THIRD): 0.45,
            (SiteClass.III, DesignGroup.FIRST): 0.45,
            (SiteClass.III, DesignGroup.SECOND): 0.55,
            (SiteClass.III, DesignGroup.THIRD): 0.65,
            (SiteClass.IV, DesignGroup.FIRST): 0.65,
            (SiteClass.IV, DesignGroup.SECOND): 0.75,
            (SiteClass.IV, DesignGroup.THIRD): 0.90,
        }
        return Tg_map.get((self.site_class, self.design_group), 0.40)

    @property
    def damping_adjustment_factor(self) -> float:
        """阻尼调整系数"""
        if self.additional_damping == 0.05:
            return 1.0
        else:
            return (0.05 / (0.05 + self.additional_damping)) ** 0.3


class NodeGeometry(BaseModel):
    """节点几何参数"""
    beam: BeamSection = Field(..., description="梁截面")
    column: ColumnSection = Field(..., description="柱截面")
    connection_type: ConnectionType = Field(default=ConnectionType.END_PLATE, description="连接类型")
    end_plate: Optional[EndPlate] = Field(default=None, description="端板参数")
    bolt_layout: Optional[BoltLayout] = Field(default=None, description="螺栓布置")
    stiffeners: Optional[List[Stiffener]] = Field(default=None, description="加劲肋列表")
    welds: Optional[List[WeldDetail]] = Field(default=None, description="焊缝列表")
    beam_span: float = Field(default=6000, gt=0, description="梁跨度(mm)")
    column_height: float = Field(default=4000, gt=0, description="柱高度(mm)")

    def validate_geometry(self) -> List[str]:
        """校核几何参数"""
        errors = []
        if self.end_plate and self.bolt_layout:
            # 校核端板宽度与螺栓布置
            min_width = (self.bolt_layout.bolt_number_x - 1) * self.bolt_layout.bolt_spacing_x + \
                       2 * self.bolt_layout.edge_distance_x
            if self.end_plate.width < min_width:
                errors.append(f"端板宽度({self.end_plate.width}mm)小于最小要求({min_width}mm)")

            # 校核端板高度与螺栓布置
            min_height = (self.bolt_layout.bolt_number_y - 1) * self.bolt_layout.bolt_spacing_y + \
                        2 * self.bolt_layout.edge_distance_y
            if self.end_plate.height < min_height:
                errors.append(f"端板高度({self.end_plate.height}mm)小于最小要求({min_height}mm)")

            # 校核螺栓与梁翼缘
            if self.end_plate.thickness < 16:
                errors.append("端板厚度小于16mm，建议采用加厚端板或设置加劲肋")

        return errors


class AnalysisResult(BaseModel):
    """分析结果"""
    analysis_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: datetime = Field(default_factory=datetime.now)
    node_geometry: NodeGeometry
    design_params: SeismicDesignParams

    # 承载力结果
    moment_capacity: float = Field(default=0, description="节点弯矩承载力(kN·m)")
    shear_capacity: float = Field(default=0, description="节点剪力承载力(kN)")
    stiffness: float = Field(default=0, description="节点刚度(kN·m/rad)")
    rotation_capacity: float = Field(default=0, description="节点转动能力(rad)")

    # 经济性指标
    steel_weight: float = Field(default=0, description="用钢量(kg)")
    bolt_count: int = Field(default=0, description="螺栓数量")
    weld_length: float = Field(default=0, description="焊缝长度(mm)")

    # 校核结果
    safety_factor: float = Field(default=0, description="安全系数")
    compliance_status: Dict[str, bool] = Field(default_factory=dict, description="规范符合性")
    verification_report: str = Field(default="", description="校核报告")

    # 分析数据
    hysteresis_data: Optional[Dict[str, List[float]]] = Field(default=None, description="滞回曲线数据")
    skeleton_data: Optional[Dict[str, List[float]]] = Field(default=None, description="骨架曲线数据")
    stress_distribution: Optional[Dict[str, Any]] = Field(default=None, description="应力分布")


class OptimizationResult(BaseModel):
    """优化结果"""
    optimization_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: datetime = Field(default_factory=datetime.now)
    algorithm: str = Field(default="NSGA-II", description="优化算法")
    generation: int = Field(default=0, description="迭代代数")
    population_size: int = Field(default=0, description="种群大小")

    # Pareto前沿
    pareto_front: List[Dict[str, Any]] = Field(default_factory=list, description="Pareto前沿解集")
    objective_values: Dict[str, List[float]] = Field(default_factory=dict, description="目标函数值")

    # 最优解
    best_solution: Optional[Dict[str, Any]] = Field(default=None, description="最优解")
    best_fitness: Optional[Dict[str, float]] = Field(default=None, description="最优适应度")

    # 收敛历史
    convergence_history: List[Dict[str, float]] = Field(default_factory=list, description="收敛历史")

    # 推荐方案
    recommended_solutions: List[Dict[str, Any]] = Field(default_factory=list, description="推荐方案")


class DesignTask(BaseModel):
    """设计任务"""
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: datetime = Field(default_factory=datetime.now)
    name: str = Field(..., description="任务名称")
    description: str = Field(default="", description="任务描述")
    status: str = Field(default="pending", description="任务状态")

    # 输入参数
    load_cases: List[LoadCase] = Field(default_factory=list, description="荷载工况")
    load_combinations: List[LoadCombination] = Field(default_factory=list, description="荷载组合")
    seismic_params: SeismicDesignParams = Field(..., description="抗震设计参数")
    geometry: NodeGeometry = Field(..., description="节点几何参数")
    constraints: Dict[str, Any] = Field(default_factory=dict, description="设计约束")
    optimization_targets: Dict[str, bool] = Field(default_factory=dict, description="优化目标")

    # 输出结果
    analysis_results: List[AnalysisResult] = Field(default_factory=list, description="分析结果列表")
    optimization_result: Optional[OptimizationResult] = Field(default=None, description="优化结果")
    final_design: Optional[Dict[str, Any]] = Field(default=None, description="最终设计方案")

    # 执行信息
    agent_logs: List[Dict[str, Any]] = Field(default_factory=list, description="Agent执行日志")
    total_iterations: int = Field(default=0, description="总迭代次数")
    total_time: float = Field(default=0, description="总耗时(s)")
