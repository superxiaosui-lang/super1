"""
规范条文数据库 - 存储和管理抗震设计相关规范条文
支持多本规范的条文查询、约束提取和智能推理
"""

from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
import json
import re
from datetime import datetime


class CodeType(str, Enum):
    """规范类型"""
    GB50011 = "建筑抗震设计规范"
    GB50017 = "钢结构设计标准"
    JGJ82 = "钢结构高强度螺栓连接技术规程"
    GB50010 = "混凝土结构设计规范"
    JGJ99 = "高层民用建筑钢结构技术规程"
    GB50205 = "钢结构工程施工质量验收标准"


class ClauseType(str, Enum):
    """条文类型"""
    MANDATORY = "强制性条文"
    RECOMMENDED = "推荐性条文"
    REFERENCE = "参考性条文"


@dataclass
class CodeClause:
    """规范条文"""
    code_type: CodeType
    clause_number: str
    title: str
    content: str
    clause_type: ClauseType = ClauseType.RECOMMENDED
    keywords: List[str] = field(default_factory=list)
    cross_references: List[str] = field(default_factory=list)
    constraints: List[Dict[str, Any]] = field(default_factory=list)
    formulas: List[Dict[str, Any]] = field(default_factory=list)
    notes: str = ""

    def contains_keyword(self, keyword: str) -> bool:
        """检查条文是否包含关键词"""
        return keyword.lower() in self.content.lower() or \
               any(keyword.lower() in kw.lower() for kw in self.keywords)


@dataclass
class DesignConstraint:
    """设计约束"""
    constraint_id: str
    name: str
    description: str
    formula: str
    lower_bound: Optional[float] = None
    upper_bound: Optional[float] = None
    unit: str = ""
    reference_clause: str = ""
    severity: str = "must"  # must, should, may

    def check(self, value: float) -> Tuple[bool, str]:
        """检查约束是否满足"""
        if self.lower_bound is not None and value < self.lower_bound:
            return False, f"{self.name}不满足: {value} < {self.lower_bound} {self.unit}"
        if self.upper_bound is not None and value > self.upper_bound:
            return False, f"{self.name}不满足: {value} > {self.upper_bound} {self.unit}"
        return True, f"{self.name}满足: {value} {self.unit}"


class SeismicCodeDatabase:
    """抗震设计规范数据库"""

    def __init__(self):
        self.codes: Dict[CodeType, Dict[str, CodeClause]] = {}
        self.constraints: Dict[str, DesignConstraint] = {}
        self._initialize_database()

    def _initialize_database(self):
        """初始化规范数据库"""
        self._init_gb50011()
        self._init_gb50017()
        self._init_jgj82()
        self._init_constraints()

    def _init_gb50011(self):
        """初始化建筑抗震设计规范"""
        clauses = {
            "5.1.1": CodeClause(
                code_type=CodeType.GB50011,
                clause_number="5.1.1",
                title="地震作用计算",
                content="建筑结构的地震作用，应根据结构类型、结构高度、结构布置和结构刚度等因素，采用底部剪力法、振型分解反应谱法或时程分析法进行计算。",
                keywords=["地震作用", "计算方法", "底部剪力法", "振型分解"],
                formulas=[
                    {"name": "底部剪力", "formula": "FEK = α1 * Geq", "variables": ["FEK", "α1", "Geq"]}
                ]
            ),
            "5.2.1": CodeClause(
                code_type=CodeType.GB50011,
                clause_number="5.2.1",
                title="水平地震作用标准值",
                content="采用底部剪力法时，结构总水平地震作用标准值应按下列公式确定：FEK = α1Geq",
                keywords=["水平地震作用", "底部剪力", "标准值"],
                formulas=[
                    {"name": "底部剪力公式", "formula": "FEK = α1Geq", "variables": ["FEK", "α1", "Geq"]}
                ]
            ),
            "8.3.1": CodeClause(
                code_type=CodeType.GB50011,
                clause_number="8.3.1",
                title="钢框架梁柱连接",
                content="钢框架梁柱连接应符合下列要求：\n1. 梁柱连接处，梁翼缘与柱翼缘应采用全熔透坡口焊缝\n2. 梁腹板与柱翼缘连接应采用高强度螺栓摩擦型连接\n3. 梁翼缘对应位置的柱腹板应设置加劲肋",
                keywords=["梁柱连接", "全熔透", "高强度螺栓", "加劲肋"],
                constraints=[
                    {"name": "连接承载力", "condition": "连接承载力应大于梁承载力的1.2倍"}
                ]
            ),
            "8.3.2": CodeClause(
                code_type=CodeType.GB50011,
                clause_number="8.3.2",
                title="强柱弱梁",
                content="框架结构应符合强柱弱梁的要求，柱的承载力应大于梁的承载力。柱端弯矩设计值应按下列公式确定：\nΣMc ≥ ηc ΣMb\n其中ηc为强柱系数，应按规范表8.3.2采用",
                keywords=["强柱弱梁", "柱端弯矩", "强柱系数"],
                formulas=[
                    {"name": "强柱弱梁公式", "formula": "ΣMc ≥ ηc ΣMb", "variables": ["ΣMc", "ηc", "ΣMb"]}
                ]
            ),
            "8.3.3": CodeClause(
                code_type=CodeType.GB50011,
                clause_number="8.3.3",
                title="节点域承载力",
                content="梁柱节点域的承载力应按下列公式验算：\n1. 节点域剪力设计值 Vp ≤ (4/3) * fvp * ht * tpc\n2. 节点域体积比限值 Vp/Vbp ≤ 1.0",
                keywords=["节点域", "承载力", "剪力", "体积比"],
                formulas=[
                    {"name": "节点域剪力验算", "formula": "Vp ≤ (4/3) * fvp * ht * tpc", "variables": ["Vp", "fvp", "ht", "tpc"]}
                ]
            ),
            "8.3.4": CodeClause(
                code_type=CodeType.GB50011,
                clause_number="8.3.4",
                title="连接极限承载力",
                content="梁柱连接的极限承载力应满足下列要求：\n1. 连接的极限弯矩 Mu ≥ 1.2 * Mp\n2. 连接的极限剪力 Vu ≥ 1.3 * (2*Mp/L)\n其中Mp为梁的全塑性弯矩",
                keywords=["极限承载力", "极限弯矩", "极限剪力", "全塑性弯矩"],
                formulas=[
                    {"name": "极限弯矩", "formula": "Mu ≥ 1.2 * Mp", "variables": ["Mu", "Mp"]},
                    {"name": "极限剪力", "formula": "Vu ≥ 1.3 * (2*Mp/L)", "variables": ["Vu", "Mp", "L"]}
                ]
            ),
            "8.3.5": CodeClause(
                code_type=CodeType.GB50011,
                clause_number="8.3.5",
                title="连接延性",
                content="梁柱连接应具有足够的延性，连接的塑性转动能力应满足：\nθu ≥ 0.03 rad\n对于特别重要的结构，应满足：\nθu ≥ 0.04 rad",
                keywords=["延性", "塑性转动", "转动能力"],
                formulas=[
                    {"name": "延性要求", "formula": "θu ≥ 0.03 rad", "variables": ["θu"]}
                ]
            ),
        }
        self.codes[CodeType.GB50011] = clauses

    def _init_gb50017(self):
        """初始化钢结构设计标准"""
        clauses = {
            "7.2.1": CodeClause(
                code_type=CodeType.GB50017,
                clause_number="7.2.1",
                title="高强度螺栓连接",
                content="高强度螺栓连接应按下列要求设计：\n1. 摩擦型连接的抗剪承载力设计值 Nv ≤ 0.9 * nf * μ * P\n2. 承压型连接的抗剪承载力设计值 Nv ≤ 0.9 * nf * μ * P（与摩擦型相同）",
                keywords=["高强度螺栓", "摩擦型连接", "承压型连接", "抗剪承载力"],
                formulas=[
                    {"name": "摩擦型连接抗剪", "formula": "Nv ≤ 0.9 * nf * μ * P", "variables": ["Nv", "nf", "μ", "P"]}
                ]
            ),
            "7.2.2": CodeClause(
                code_type=CodeType.GB50017,
                clause_number="7.2.2",
                title="螺栓间距要求",
                content="高强度螺栓的间距应符合下列要求：\n1. 螺栓中心间距不应小于3d（d为螺栓直径）\n2. 螺栓中心至构件边缘距离不应小于2d\n3. 最大间距不应大于12d或150mm（取较小值）",
                keywords=["螺栓间距", "边距", "最大间距", "最小间距"],
                constraints=[
                    {"name": "最小间距", "condition": "3d", "unit": "mm"},
                    {"name": "最大间距", "condition": "min(12d, 150)", "unit": "mm"}
                ]
            ),
            "8.1.1": CodeClause(
                code_type=CodeType.GB50017,
                clause_number="8.1.1",
                title="焊缝连接",
                content="焊缝连接的设计应符合下列要求：\n1. 对接焊缝的强度设计值应按母材强度设计值取用\n2. 角焊缝的强度设计值应按规范表8.1.1采用\n3. 焊缝质量等级应根据结构的重要性、荷载特性和焊缝形式确定",
                keywords=["焊缝连接", "对接焊缝", "角焊缝", "强度设计值"],
                formulas=[
                    {"name": "角焊缝承载力", "formula": "N = 0.7 * hf * fw * Lw", "variables": ["N", "hf", "fw", "Lw"]}
                ]
            ),
            "8.2.1": CodeClause(
                code_type=CodeType.GB50017,
                clause_number="8.2.1",
                title="焊脚尺寸要求",
                content="角焊缝的焊脚尺寸应符合下列要求：\n1. 最小焊脚尺寸 hf,min ≥ 1.5√t（t为较厚焊件厚度）\n2. 最大焊脚尺寸 hf,max ≤ 1.2t（t为较薄焊件厚度）\n3. 直角角焊缝的有效厚度 he = 0.7*hf",
                keywords=["焊脚尺寸", "最小焊脚", "最大焊脚", "有效厚度"],
                constraints=[
                    {"name": "最小焊脚尺寸", "condition": "1.5√t", "unit": "mm"},
                    {"name": "最大焊脚尺寸", "condition": "1.2t", "unit": "mm"}
                ]
            ),
            "8.3.1": CodeClause(
                code_type=CodeType.GB50017,
                clause_number="8.3.1",
                title="焊缝长度要求",
                content="角焊缝的计算长度应符合下列要求：\n1. 侧焊缝的计算长度不应小于8hf（hf为焊脚尺寸）\n2. 侧焊缝的计算长度不应大于60hf（当hf>8mm时）\n3. 端焊缝的计算长度可取为焊缝实际长度",
                keywords=["焊缝长度", "侧焊缝", "端焊缝", "计算长度"],
                constraints=[
                    {"name": "最小焊缝长度", "condition": "8hf", "unit": "mm"},
                    {"name": "最大焊缝长度", "condition": "60hf", "unit": "mm"}
                ]
            ),
            "8.4.1": CodeClause(
                code_type=CodeType.GB50017,
                clause_number="8.4.1",
                title="端板连接",
                content="端板连接应按下列要求设计：\n1. 端板厚度应根据连接的弯矩和剪力计算确定\n2. 端板厚度不宜小于16mm\n3. 端板应采用高强度螺栓与柱翼缘连接\n4. 端板连接处应设置加劲肋",
                keywords=["端板连接", "端板厚度", "加劲肋", "高强度螺栓"],
                constraints=[
                    {"name": "端板最小厚度", "condition": "16mm", "upper_bound": None, "lower_bound": 16}
                ]
            ),
        }
        self.codes[CodeType.GB50017] = clauses

    def _init_jgj82(self):
        """初始化钢结构高强度螺栓连接技术规程"""
        clauses = {
            "4.1.1": CodeClause(
                code_type=CodeType.JGJ82,
                clause_number="4.1.1",
                title="高强度螺栓连接设计原则",
                content="高强度螺栓连接的设计应遵循下列原则：\n1. 摩擦型连接应按正常使用极限状态设计\n2. 承压型连接应按承载能力极限状态设计\n3. 连接的承载力设计值应取螺栓、连接板和被连接件中的较小值",
                keywords=["设计原则", "摩擦型连接", "承压型连接", "承载力"]
            ),
            "5.1.1": CodeClause(
                code_type=CodeType.JGJ82,
                clause_number="5.1.1",
                title="摩擦面处理",
                content="高强度螺栓连接的摩擦面应符合下列要求：\n1. 摩擦面的处理方法应根据设计要求确定\n2. 摩擦面的抗滑移系数μ应按规范表5.1.1采用\n3. 摩擦面不得涂油漆或有油污",
                keywords=["摩擦面", "抗滑移系数", "表面处理"],
                constraints=[
                    {"name": "抗滑移系数", "condition": "μ≥0.35（喷砂处理）"}
                ]
            ),
            "5.2.1": CodeClause(
                code_type=CodeType.JGJ82,
                clause_number="5.2.1",
                title="螺栓预拉力",
                content="高强度螺栓的预拉力应符合下列要求：\n1. 预拉力设计值应按规范表5.2.1采用\n2. 预拉力偏差不应超过设计值的±10%\n3. 螺栓施拧顺序应从连接件刚度大的部位向约束小的部位进行",
                keywords=["预拉力", "预拉力设计值", "偏差", "施拧顺序"],
                constraints=[
                    {"name": "预拉力偏差", "condition": "±10%", "lower_bound": -0.1, "upper_bound": 0.1}
                ]
            ),
            "6.1.1": CodeClause(
                code_type=CodeType.JGJ82,
                clause_number="6.1.1",
                title="连接构造要求",
                content="高强度螺栓连接的构造应符合下列要求：\n1. 螺栓排列应整齐、紧凑\n2. 最少螺栓数量不应少于2个\n3. 螺栓中心间距不应小于3d\n4. 螺栓中心至构件边缘距离不应小于1.5d",
                keywords=["构造要求", "螺栓排列", "最少数量", "间距"],
                constraints=[
                    {"name": "最少螺栓数量", "condition": "≥2"},
                    {"name": "最小中心间距", "condition": "3d"},
                    {"name": "最小边距", "condition": "1.5d"}
                ]
            ),
        }
        self.codes[CodeType.JGJ82] = clauses

    def _init_constraints(self):
        """初始化设计约束库"""
        self.constraints = {
            "bolt_spacing_min": DesignConstraint(
                constraint_id="BC001",
                name="螺栓最小间距",
                description="螺栓中心间距不应小于3倍螺栓直径",
                formula="s >= 3d",
                lower_bound=3.0,
                unit="d",
                reference_clause="GB50017-7.2.2",
                severity="must"
            ),
            "bolt_spacing_max": DesignConstraint(
                constraint_id="BC002",
                name="螺栓最大间距",
                description="螺栓中心间距不应大于12倍螺栓直径或150mm",
                formula="s <= min(12d, 150)",
                upper_bound=12.0,
                unit="d",
                reference_clause="GB50017-7.2.2",
                severity="must"
            ),
            "bolt_edge_distance_min": DesignConstraint(
                constraint_id="BC003",
                name="螺栓最小边距",
                description="螺栓中心至构件边缘距离不应小于1.5倍螺栓直径",
                formula="e >= 1.5d",
                lower_bound=1.5,
                unit="d",
                reference_clause="GB50017-7.2.2",
                severity="must"
            ),
            "weld_size_min": DesignConstraint(
                constraint_id="WC001",
                name="最小焊脚尺寸",
                description="角焊缝的最小焊脚尺寸不应小于1.5倍根号较厚焊件厚度",
                formula="hf >= 1.5√t",
                lower_bound=1.5,
                unit="√t",
                reference_clause="GB50017-8.2.1",
                severity="must"
            ),
            "weld_size_max": DesignConstraint(
                constraint_id="WC002",
                name="最大焊脚尺寸",
                description="角焊缝的最大焊脚尺寸不应大于1.2倍较薄焊件厚度",
                formula="hf <= 1.2t",
                upper_bound=1.2,
                unit="t",
                reference_clause="GB50017-8.2.1",
                severity="must"
            ),
            "weld_length_min": DesignConstraint(
                constraint_id="WC003",
                name="最小焊缝长度",
                description="侧焊缝的计算长度不应小于8倍焊脚尺寸",
                formula="Lw >= 8hf",
                lower_bound=8.0,
                unit="hf",
                reference_clause="GB50017-8.3.1",
                severity="must"
            ),
            "end_plate_thickness_min": DesignConstraint(
                constraint_id="EP001",
                name="端板最小厚度",
                description="端板厚度不宜小于16mm",
                formula="t >= 16mm",
                lower_bound=16.0,
                unit="mm",
                reference_clause="GB50017-8.4.1",
                severity="should"
            ),
            "connection_capacity_ratio": DesignConstraint(
                constraint_id="CC001",
                name="连接承载力比",
                description="连接承载力应大于梁承载力的1.2倍",
                formula="Mu >= 1.2Mp",
                lower_bound=1.2,
                unit="Mp",
                reference_clause="GB50011-8.3.4",
                severity="must"
            ),
            "joint_zone_ratio": DesignConstraint(
                constraint_id="JZ001",
                name="节点域体积比",
                description="节点域体积比不应大于1.0",
                formula="Vp/Vbp <= 1.0",
                upper_bound=1.0,
                unit="Vbp",
                reference_clause="GB50011-8.3.3",
                severity="must"
            ),
            "rotation_capacity": DesignConstraint(
                constraint_id="RC001",
                name="转动能力要求",
                description="连接的塑性转动能力应满足θu ≥ 0.03 rad",
                formula="θu >= 0.03 rad",
                lower_bound=0.03,
                unit="rad",
                reference_clause="GB50011-8.3.5",
                severity="must"
            ),
            "column_beam_ratio": DesignConstraint(
                constraint_id="CB001",
                name="强柱弱梁系数",
                description="柱梁弯矩比应满足ΣMc ≥ ηc ΣMb",
                formula="ΣMc/ΣMb >= ηc",
                lower_bound=1.0,
                unit="ηc",
                reference_clause="GB50011-8.3.2",
                severity="must"
            ),
        }

    def query_clause(self, code_type: CodeType, clause_number: str) -> Optional[CodeClause]:
        """查询规范条文"""
        if code_type in self.codes:
            return self.codes[code_type].get(clause_number)
        return None

    def search_by_keyword(self, keyword: str, code_type: Optional[CodeType] = None) -> List[CodeClause]:
        """按关键词搜索条文"""
        results = []
        codes_to_search = [code_type] if code_type else self.codes.keys()

        for ct in codes_to_search:
            if ct in self.codes:
                for clause in self.codes[ct].values():
                    if clause.contains_keyword(keyword):
                        results.append(clause)
        return results

    def get_constraints_for_component(self, component_type: str) -> List[DesignConstraint]:
        """获取特定构件的设计约束"""
        component_prefix = {
            "bolt": "BC",
            "weld": "WC",
            "end_plate": "EP",
            "connection": "CC",
            "joint_zone": "JZ",
            "rotation": "RC",
            "column_beam": "CB",
        }

        prefix = component_prefix.get(component_type, "")
        return [
            constraint for cid, constraint in self.constraints.items()
            if cid.startswith(prefix)
        ]

    def check_all_constraints(self, design_params: Dict[str, Any]) -> Dict[str, Tuple[bool, str]]:
        """检查所有设计约束"""
        results = {}
        for constraint_id, constraint in self.constraints.items():
            # 根据约束类型获取相应的设计参数值
            value = self._extract_param_value(constraint_id, design_params)
            if value is not None:
                passed, message = constraint.check(value)
                results[constraint_id] = (passed, message)
            else:
                results[constraint_id] = (True, "无对应参数，跳过检查")
        return results

    def _extract_param_value(self, constraint_id: str, design_params: Dict[str, Any]) -> Optional[float]:
        """从设计参数中提取约束检查所需的值"""
        # 这里需要根据具体的约束ID映射到设计参数
        # 简化实现
        if constraint_id.startswith("BC"):
            return design_params.get("bolt_spacing_ratio")
        elif constraint_id.startswith("WC"):
            return design_params.get("weld_size_ratio")
        elif constraint_id.startswith("EP"):
            return design_params.get("end_plate_thickness")
        elif constraint_id.startswith("CC"):
            return design_params.get("connection_capacity_ratio")
        elif constraint_id.startswith("JZ"):
            return design_params.get("joint_zone_ratio")
        elif constraint_id.startswith("RC"):
            return design_params.get("rotation_capacity")
        return None

    def get_code_summary(self) -> Dict[str, int]:
        """获取规范摘要信息"""
        summary = {}
        for code_type, clauses in self.codes.items():
            summary[code_type.value] = len(clauses)
        return summary

    def get_constraint_summary(self) -> Dict[str, int]:
        """获取约束摘要信息"""
        severity_count = {"must": 0, "should": 0, "may": 0}
        for constraint in self.constraints.values():
            if constraint.severity in severity_count:
                severity_count[constraint.severity] += 1
        return severity_count
