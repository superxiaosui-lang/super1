"""
知识图谱 - 构建抗震节点设计知识图谱，支持规范条文间的语义关系查询
"""

from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
import networkx as nx
from collections import defaultdict
import json


class NodeType(str, Enum):
    """节点类型"""
    CODE = "规范"
    CLAUSE = "条文"
    COMPONENT = "构件"
    PARAMETER = "参数"
    CONSTRAINT = "约束"
    FORMULA = "公式"
    CONCEPT = "概念"
    METHOD = "方法"


class RelationType(str, Enum):
    """关系类型"""
    BELONGS_TO = "属于"
    REFERENCES = "引用"
    SUPPLEMENTS = "补充"
    CONFLICTS = "冲突"
    DERIVES = "导出"
    CONSTRAINT = "约束"
    CALCULATES = "计算"
    APPLIES_TO = "适用于"
    SIMILAR_TO = "相似于"


@dataclass
class KGNode:
    """知识图谱节点"""
    node_id: str
    node_type: NodeType
    name: str
    description: str = ""
    properties: Dict[str, Any] = field(default_factory=dict)
    source: str = ""


@dataclass
class KGRelation:
    """知识图谱关系"""
    source_id: str
    target_id: str
    relation_type: RelationType
    weight: float = 1.0
    properties: Dict[str, Any] = field(default_factory=dict)


class SeismicKnowledgeGraph:
    """抗震节点设计知识图谱"""

    def __init__(self):
        self.graph = nx.DiGraph()
        self.node_index: Dict[str, KGNode] = {}
        self.relation_index: Dict[str, List[KGRelation]] = defaultdict(list)
        self._build_knowledge_graph()

    def _build_knowledge_graph(self):
        """构建知识图谱"""
        # 添加规范节点
        self._add_code_nodes()
        # 添加构件节点
        self._add_component_nodes()
        # 添加参数节点
        self._add_parameter_nodes()
        # 添加约束节点
        self._add_constraint_nodes()
        # 添加概念节点
        self._add_concept_nodes()
        # 添加关系
        self._add_relations()

    def _add_code_nodes(self):
        """添加规范节点"""
        codes = [
            KGNode("code_gb50011", NodeType.CODE, "GB50011-2010",
                   "建筑抗震设计规范", {"year": 2010, "status": "现行"}),
            KGNode("code_gb50017", NodeType.CODE, "GB50017-2017",
                   "钢结构设计标准", {"year": 2017, "status": "现行"}),
            KGNode("code_jgj82", NodeType.CODE, "JGJ82-2011",
                   "钢结构高强度螺栓连接技术规程", {"year": 2011, "status": "现行"}),
        ]
        for node in codes:
            self._add_node(node)

    def _add_component_nodes(self):
        """添加构件节点"""
        components = [
            KGNode("comp_beam", NodeType.COMPONENT, "梁", "钢梁构件"),
            KGNode("comp_column", NodeType.COMPONENT, "柱", "钢柱构件"),
            KGNode("comp_end_plate", NodeType.COMPONENT, "端板", "梁柱连接端板"),
            KGNode("comp_bolt", NodeType.COMPONENT, "高强度螺栓", "摩擦型高强度螺栓"),
            KGNode("comp_weld", NodeType.COMPONENT, "焊缝", "焊接连接"),
            KGNode("comp_stiffener", NodeType.COMPONENT, "加劲肋", "节点域加劲肋"),
            KGNode("comp_joint_zone", NodeType.COMPONENT, "节点域", "梁柱节点域"),
        ]
        for node in components:
            self._add_node(node)

    def _add_parameter_nodes(self):
        """添加参数节点"""
        parameters = [
            KGNode("param_bolt_diameter", NodeType.PARAMETER, "螺栓直径",
                   "高强度螺栓的公称直径", {"unit": "mm", "range": [12, 16, 20, 22, 24, 27, 30]}),
            KGNode("param_bolt_grade", NodeType.PARAMETER, "螺栓性能等级",
                   "螺栓的强度等级", {"values": ["8.8级", "10.9级"]}),
            KGNode("param_bolt_number", NodeType.PARAMETER, "螺栓数量",
                   "连接处的螺栓总数", {"unit": "个", "min": 2}),
            KGNode("param_bolt_spacing", NodeType.PARAMETER, "螺栓间距",
                   "螺栓中心间距", {"unit": "mm", "min_ratio": "3d", "max_ratio": "12d"}),
            KGNode("param_end_plate_thickness", NodeType.PARAMETER, "端板厚度",
                   "端板的厚度", {"unit": "mm", "min": 16}),
            KGNode("param_end_plate_width", NodeType.PARAMETER, "端板宽度",
                   "端板的宽度", {"unit": "mm"}),
            KGNode("param_end_plate_height", NodeType.PARAMETER, "端板高度",
                   "端板的高度", {"unit": "mm"}),
            KGNode("param_weld_size", NodeType.PARAMETER, "焊脚尺寸",
                   "角焊缝的焊脚尺寸", {"unit": "mm", "min_formula": "1.5sqrt(t)", "max_formula": "1.2t"}),
            KGNode("param_weld_length", NodeType.PARAMETER, "焊缝长度",
                   "焊缝的计算长度", {"unit": "mm", "min_formula": "8hf"}),
            KGNode("param_stiffener_thickness", NodeType.PARAMETER, "加劲肋厚度",
                   "加劲肋的厚度", {"unit": "mm", "range": [8, 50]}),
        ]
        for node in parameters:
            self._add_node(node)

    def _add_constraint_nodes(self):
        """添加约束节点"""
        constraints = [
            KGNode("constraint_bolt_spacing", NodeType.CONSTRAINT, "螺栓间距约束",
                   "螺栓间距应在3d到12d之间",
                   {"formula": "3d <= s <= min(12d, 150)", "severity": "must"}),
            KGNode("constraint_weld_size", NodeType.CONSTRAINT, "焊脚尺寸约束",
                   "焊脚尺寸应在1.5sqrt(t)到1.2t之间",
                   {"formula": "1.5sqrt(t) <= hf <= 1.2t", "severity": "must"}),
            KGNode("constraint_end_plate", NodeType.CONSTRAINT, "端板厚度约束",
                   "端板厚度不宜小于16mm",
                   {"formula": "t >= 16mm", "severity": "should"}),
            KGNode("constraint_connection_capacity", NodeType.CONSTRAINT, "连接承载力约束",
                   "连接承载力应大于梁承载力的1.2倍",
                   {"formula": "Mu >= 1.2Mp", "severity": "must"}),
            KGNode("constraint_joint_zone", NodeType.CONSTRAINT, "节点域约束",
                   "节点域体积比不应大于1.0",
                   {"formula": "Vp/Vbp <= 1.0", "severity": "must"}),
            KGNode("constraint_rotation", NodeType.CONSTRAINT, "转动能力约束",
                   "连接的塑性转动能力应满足theta_u >= 0.03 rad",
                   {"formula": "theta_u >= 0.03 rad", "severity": "must"}),
        ]
        for node in constraints:
            self._add_node(node)

    def _add_concept_nodes(self):
        """添加概念节点"""
        concepts = [
            KGNode("concept_strong_column_weak_beam", NodeType.CONCEPT, "强柱弱梁",
                   "柱的承载力应大于梁的承载力"),
            KGNode("concept_strong_joint_weak_member", NodeType.CONCEPT, "强节点弱构件",
                   "节点的承载力应大于构件的承载力"),
            KGNode("concept_ductility", NodeType.CONCEPT, "延性设计",
                   "结构应具有足够的延性以耗散地震能量"),
            KGNode("concept_capacity_design", NodeType.CONCEPT, "承载力设计",
                   "基于承载力的设计方法"),
            KGNode("concept_displacement_based", NodeType.CONCEPT, "基于位移的设计",
                   "以位移为设计目标的方法"),
            KGNode("concept_hysteretic_energy", NodeType.CONCEPT, "滞回耗能",
                   "结构通过滞回变形耗散地震能量"),
        ]
        for node in concepts:
            self._add_node(node)

    def _add_relations(self):
        """添加关系"""
        relations = [
            # 规范间的引用关系
            ("code_gb50011", "code_gb50017", RelationType.REFERENCES,
             "GB50011引用GB50017的钢结构设计内容"),
            ("code_jgj82", "code_gb50017", RelationType.SUPPLEMENTS,
             "JGJ82补充了高强度螺栓连接的具体要求"),

            # 构件与规范的关系
            ("comp_bolt", "code_jgj82", RelationType.BELONGS_TO,
             "高强度螺栓连接由JGJ82规定"),
            ("comp_weld", "code_gb50017", RelationType.BELONGS_TO,
             "焊缝连接由GB50017规定"),
            ("comp_end_plate", "code_gb50017", RelationType.BELONGS_TO,
             "端板连接由GB50017规定"),

            # 构件与参数的关系
            ("comp_bolt", "param_bolt_diameter", RelationType.CONSTRAINT,
                 "螺栓直径是螺栓的重要参数"),
            ("comp_bolt", "param_bolt_grade", RelationType.CONSTRAINT,
                 "螺栓性能等级是螺栓的重要参数"),
            ("comp_bolt", "param_bolt_spacing", RelationType.CONSTRAINT,
                 "螺栓间距影响连接的承载力"),
            ("comp_end_plate", "param_end_plate_thickness", RelationType.CONSTRAINT,
                 "端板厚度影响连接的刚度"),
            ("comp_weld", "param_weld_size", RelationType.CONSTRAINT,
                 "焊脚尺寸影响焊缝的承载力"),
            ("comp_weld", "param_weld_length", RelationType.CONSTRAINT,
                 "焊缝长度影响焊缝的承载力"),

            # 参数与约束的关系
            ("param_bolt_spacing", "constraint_bolt_spacing", RelationType.CONSTRAINT,
                 "螺栓间距受规范约束"),
            ("param_weld_size", "constraint_weld_size", RelationType.CONSTRAINT,
                 "焊脚尺寸受规范约束"),
            ("param_end_plate_thickness", "constraint_end_plate", RelationType.CONSTRAINT,
                 "端板厚度受规范约束"),

            # 构件间的关系
            ("comp_beam", "comp_column", RelationType.APPLIES_TO,
             "梁通过节点与柱连接"),
            ("comp_end_plate", "comp_beam", RelationType.APPLIES_TO,
             "端板连接梁的翼缘和腹板"),
            ("comp_end_plate", "comp_column", RelationType.APPLIES_TO,
             "端板通过螺栓连接柱翼缘"),
            ("comp_bolt", "comp_end_plate", RelationType.APPLIES_TO,
             "高强度螺栓连接端板和柱翼缘"),
            ("comp_weld", "comp_beam", RelationType.APPLIES_TO,
             "焊缝连接梁的各部分"),
            ("comp_weld", "comp_end_plate", RelationType.APPLIES_TO,
             "焊缝连接端板和梁"),
            ("comp_stiffener", "comp_joint_zone", RelationType.APPLIES_TO,
             "加劲肋加强节点域"),
            ("comp_stiffener", "comp_column", RelationType.APPLIES_TO,
             "加劲肋设置在柱腹板上"),

            # 概念与约束的关系
            ("concept_strong_column_weak_beam", "constraint_connection_capacity", RelationType.CONSTRAINT,
             "强柱弱梁要求连接有足够的承载力"),
            ("concept_strong_joint_weak_member", "constraint_connection_capacity", RelationType.CONSTRAINT,
             "强节点弱构件要求节点承载力大于构件承载力"),
            ("concept_ductility", "constraint_rotation", RelationType.CONSTRAINT,
             "延性设计要求连接有足够的转动能力"),
        ]

        for source, target, rel_type, desc in relations:
            if source in self.node_index and target in self.node_index:
                self._add_relation(source, target, rel_type, {"description": desc})

    def _add_node(self, node: KGNode):
        """添加节点"""
        self.node_index[node.node_id] = node
        self.graph.add_node(node.node_id,
                           node_type=node.node_type.value,
                           name=node.name,
                           properties=node.properties)

    def _add_relation(self, source_id: str, target_id: str,
                     relation_type: RelationType, properties: Dict = None):
        """添加关系"""
        relation = KGRelation(source_id, target_id, relation_type,
                             properties=properties or {})
        self.relation_index[source_id].append(relation)
        self.graph.add_edge(source_id, target_id,
                           relation_type=relation_type.value,
                           properties=properties or {})

    def query_related_nodes(self, node_id: str, relation_type: Optional[RelationType] = None) -> List[KGNode]:
        """查询相关节点"""
        related_nodes = []
        if node_id in self.node_index:
            for neighbor in self.graph.neighbors(node_id):
                edge_data = self.graph.edges[node_id, neighbor]
                if relation_type is None or edge_data.get('relation_type') == relation_type.value:
                    related_nodes.append(self.node_index[neighbor])
        return related_nodes

    def query_reverse_related_nodes(self, node_id: str, relation_type: Optional[RelationType] = None) -> List[KGNode]:
        """查询反向相关节点"""
        related_nodes = []
        if node_id in self.node_index:
            for predecessor in self.graph.predecessors(node_id):
                edge_data = self.graph.edges[predecessor, node_id]
                if relation_type is None or edge_data.get('relation_type') == relation_type.value:
                    related_nodes.append(self.node_index[predecessor])
        return related_nodes

    def find_path(self, source_id: str, target_id: str) -> List[KGNode]:
        """查找两个节点间的路径"""
        try:
            path = nx.shortest_path(self.graph, source_id, target_id)
            return [self.node_index[node_id] for node_id in path if node_id in self.node_index]
        except nx.NetworkXNoPath:
            return []

    def get_subgraph_by_type(self, node_type: NodeType) -> nx.DiGraph:
        """获取特定类型节点的子图"""
        nodes = [nid for nid, node in self.node_index.items()
                if node.node_type == node_type]
        return self.graph.subgraph(nodes)

    def query_by_pattern(self, pattern: Dict[str, Any]) -> List[KGNode]:
        """按模式查询节点"""
        results = []
        for node in self.node_index.values():
            match = True
            if 'node_type' in pattern and node.node_type != pattern['node_type']:
                match = False
            if 'name_contains' in pattern and pattern['name_contains'] not in node.name:
                match = False
            if 'properties' in pattern:
                for key, value in pattern['properties'].items():
                    if key not in node.properties or node.properties[key] != value:
                        match = False
            if match:
                results.append(node)
        return results

    def get_constraint_chain(self, component_id: str) -> List[Dict[str, Any]]:
        """获取构件的约束链"""
        chain = []
        # 获取构件的参数
        params = self.query_related_nodes(component_id, RelationType.CONSTRAINT)
        for param in params:
            # 获取参数的约束
            constraints = self.query_related_nodes(param.node_id, RelationType.CONSTRAINT)
            for constraint in constraints:
                chain.append({
                    "component": self.node_index[component_id].name,
                    "parameter": param.name,
                    "constraint": constraint.name,
                    "properties": constraint.properties
                })
        return chain

    def get_code_clause_network(self) -> Dict[str, List[str]]:
        """获取规范条文网络"""
        network = defaultdict(list)
        codes = self.query_by_pattern({'node_type': NodeType.CODE})
        for code in codes:
            related_codes = self.query_related_nodes(code.node_id)
            network[code.name] = [rc.name for rc in related_codes]
        return dict(network)

    def calculate_graph_metrics(self) -> Dict[str, float]:
        """计算图的指标"""
        metrics = {
            "num_nodes": self.graph.number_of_nodes(),
            "num_edges": self.graph.number_of_edges(),
            "density": nx.density(self.graph),
            "avg_clustering": nx.average_clustering(self.graph.to_undirected()),
        }

        # 计算中心性
        if self.graph.number_of_nodes() > 0:
            betweenness = nx.betweenness_centrality(self.graph)
            metrics["max_betweenness"] = max(betweenness.values()) if betweenness else 0
            metrics["avg_betweenness"] = sum(betweenness.values()) / len(betweenness)

        return metrics

    def export_to_json(self) -> str:
        """导出为JSON"""
        data = {
            "nodes": [
                {
                    "id": node.node_id,
                    "type": node.node_type.value,
                    "name": node.name,
                    "description": node.description,
                    "properties": node.properties
                }
                for node in self.node_index.values()
            ],
            "relations": [
                {
                    "source": source_id,
                    "target": rel.target_id,
                    "type": rel.relation_type.value,
                    "properties": rel.properties
                }
                for source_id, rels in self.relation_index.items()
                for rel in rels
            ]
        }
        return json.dumps(data, ensure_ascii=False, indent=2)

    def visualize(self, filename: str = "knowledge_graph"):
        """可视化知识图谱"""
        try:
            import matplotlib.pyplot as plt
            import matplotlib
            matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
            matplotlib.rcParams['axes.unicode_minus'] = False

            plt.figure(figsize=(16, 12))
            pos = nx.spring_layout(self.graph, k=2, iterations=50, seed=42)

            # 按节点类型分组
            node_colors = {
                NodeType.CODE: '#FF6B6B',
                NodeType.COMPONENT: '#4ECDC4',
                NodeType.PARAMETER: '#45B7D1',
                NodeType.CONSTRAINT: '#96CEB4',
                NodeType.CONCEPT: '#FFEAA7',
            }

            for node_type, color in node_colors.items():
                nodes = [nid for nid, node in self.node_index.items()
                        if node.node_type == node_type]
                if nodes:
                    nx.draw_networkx_nodes(self.graph, pos, nodelist=nodes,
                                          node_color=color, node_size=2000,
                                          alpha=0.8, label=node_type.value)

            nx.draw_networkx_edges(self.graph, pos, edge_color='gray',
                                  arrows=True, arrowsize=20, alpha=0.6,
                                  connectionstyle="arc3,rad=0.1")

            labels = {nid: node.name for nid, node in self.node_index.items()}
            nx.draw_networkx_labels(self.graph, pos, labels, font_size=8,
                                   font_family='SimHei')

            plt.title("抗震节点设计知识图谱", fontsize=16, fontweight='bold')
            plt.legend(scatterpoints=1, loc='upper left', fontsize=10)
            plt.axis('off')
            plt.tight_layout()
            plt.savefig(f"{filename}.png", dpi=150, bbox_inches='tight')
            plt.close()
            print(f"知识图谱已保存为 {filename}.png")
        except Exception as e:
            print(f"可视化失败: {e}")
