"""
多目标优化辅助模块 - 提供多目标优化的常用工具和指标计算
"""

import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass


@dataclass
class ParetoMetrics:
    """Pareto前沿指标"""
    hypervolume: float = 0.0
    spacing: float = 0.0
    spread: float = 0.0
    igd: float = 0.0
    diversity: float = 0.0


class MultiObjectiveMetrics:
    """多目标优化指标计算器"""

    @staticmethod
    def calculate_hypervolume(objectives: np.ndarray,
                             reference_point: Optional[np.ndarray] = None) -> float:
        """
        计算超体积指标(HV)

        Args:
            objectives: 目标值矩阵 (n_solutions x n_objectives)
            reference_point: 参考点（默认为各目标最大值+10%）

        Returns:
            超体积值
        """
        n_obj = objectives.shape[1]

        if reference_point is None:
            reference_point = np.max(objectives, axis=0) * 1.1

        # 简化计算：对于2D情况
        if n_obj == 2:
            # 按第一个目标排序
            sorted_idx = np.argsort(objectives[:, 0])
            sorted_obj = objectives[sorted_idx]

            hv = 0.0
            prev_y = reference_point[1]

            for i in range(len(sorted_obj)):
                if sorted_obj[i, 1] < prev_y:
                    hv += (reference_point[0] - sorted_obj[i, 0]) * (prev_y - sorted_obj[i, 1])
                    prev_y = sorted_obj[i, 1]

            return hv

        # 对于3D及以上使用蒙特卡洛近似
        n_samples = 10000
        random_points = np.random.uniform(
            np.min(objectives, axis=0),
            reference_point,
            size=(n_samples, n_obj)
        )

        dominated_count = 0
        for point in random_points:
            # 检查是否被任何解支配
            for sol in objectives:
                if np.all(sol <= point):
                    dominated_count += 1
                    break

        volume = np.prod(reference_point - np.min(objectives, axis=0))
        hv = volume * dominated_count / n_samples

        return hv

    @staticmethod
    def calculate_spacing(objectives: np.ndarray) -> float:
        """
        计算间距指标(SP)

        衡量Pareto前沿的均匀性
        """
        n_solutions = len(objectives)
        if n_solutions <= 1:
            return 0.0

        # 计算最近邻距离
        distances = []
        for i in range(n_solutions):
            min_dist = float('inf')
            for j in range(n_solutions):
                if i != j:
                    dist = np.linalg.norm(objectives[i] - objectives[j])
                    min_dist = min(min_dist, dist)
            distances.append(min_dist)

        distances = np.array(distances)
        mean_dist = np.mean(distances)

        # 计算SP
        sp = np.sqrt(np.sum((distances - mean_dist)**2) / (n_solutions - 1))

        return sp

    @staticmethod
    def calculate_spread(objectives: np.ndarray) -> float:
        """
        计算扩展性指标( Spread )

        衡量Pareto前沿的覆盖范围
        """
        n_solutions = len(objectives)
        if n_solutions <= 1:
            return 0.0

        # 计算极值点距离
        extremes = []
        for i in range(objectives.shape[1]):
            idx = np.argmin(objectives[:, i])
            extremes.append(idx)

        # 计算所有连续点之间的距离
        sorted_indices = np.argsort(objectives[:, 0])
        sorted_obj = objectives[sorted_indices]

        distances = []
        for i in range(len(sorted_obj) - 1):
            dist = np.linalg.norm(sorted_obj[i+1] - sorted_obj[i])
            distances.append(dist)

        distances = np.array(distances)
        mean_dist = np.mean(distances)

        # 计算极值点到边界的距离
        d_f = np.linalg.norm(sorted_obj[0] - sorted_obj[-1])

        # 计算扩展性
        if mean_dist > 0:
            spread = (d_f + np.sum(np.abs(distances - mean_dist))) / (d_f + (n_solutions-1) * mean_dist)
        else:
            spread = 0.0

        return spread

    @staticmethod
    def calculate_igd(objectives: np.ndarray,
                     true_pareto: np.ndarray) -> float:
        """
        计算反转生成距离(IGD)

        Args:
            objectives: 近似Pareto前沿
            true_pareto: 真实Pareto前沿

        Returns:
            IGD值
        """
        distances = []
        for point in true_pareto:
            min_dist = np.min(np.linalg.norm(objectives - point, axis=1))
            distances.append(min_dist)

        return np.mean(distances)

    @staticmethod
    def calculate_diversity(objectives: np.ndarray) -> float:
        """
        计算多样性指标

        衡量Pareto前沿的分布广度
        """
        n_obj = objectives.shape[1]
        diversity = 0.0

        for i in range(n_obj):
            obj_range = np.max(objectives[:, i]) - np.min(objectives[:, i])
            diversity += obj_range

        return diversity / n_obj

    @staticmethod
    def calculate_convergence_metrics(history: List[Dict]) -> Dict[str, List[float]]:
        """
        计算收敛指标历史

        Args:
            history: 优化历史

        Returns:
            收敛指标字典
        """
        metrics = {
            "generation": [],
            "best_objectives_mean": [],
            "hypervolume": [],
            "spacing": [],
        }

        for record in history:
            metrics["generation"].append(record["generation"])
            metrics["best_objectives_mean"].append(np.mean(record["best_objectives"]))
            metrics["hypervolume"].append(record.get("hypervolume", 0))
            metrics["spacing"].append(record.get("spacing", 0))

        return metrics


class ReferencePointGenerator:
    """参考点生成器"""

    @staticmethod
    def generate_uniform_reference_points(n_objectives: int,
                                         n_points: int) -> np.ndarray:
        """
        生成均匀分布的参考点

        Args:
            n_objectives: 目标数
            n_points: 参考点数

        Returns:
            参考点矩阵
        """
        if n_objectives == 2:
            # 2D情况：均匀分布
            angles = np.linspace(0, np.pi/2, n_points)
            ref_points = np.column_stack([np.cos(angles), np.sin(angles)])
            return ref_points

        # 多目标情况：使用Das and Dennis方法
        # 简化实现
        ref_points = np.random.dirichlet(np.ones(n_objectives), n_points)
        return ref_points

    @staticmethod
    def generate_adaptive_reference_points(pareto_front: np.ndarray,
                                          n_points: int) -> np.ndarray:
        """
        生成自适应参考点

        基于当前Pareto前沿的分布
        """
        # 计算前沿的极值点
        n_obj = pareto_front.shape[1]
        ideal_point = np.min(pareto_front, axis=0)
        nadir_point = np.max(pareto_front, axis=0)

        # 归一化前沿
        normalized_front = (pareto_front - ideal_point) / (nadir_point - ideal_point + 1e-10)

        # 基于前沿分布生成参考点
        # 简化实现：使用网格方法
        n_per_dim = int(np.ceil(n_points ** (1/n_obj)))
        grids = np.meshgrid(*[np.linspace(0, 1, n_per_dim) for _ in range(n_obj)])
        ref_points = np.column_stack([g.flatten() for g in grids])

        # 截取到所需数量
        if len(ref_points) > n_points:
            indices = np.random.choice(len(ref_points), n_points, replace=False)
            ref_points = ref_points[indices]

        return ref_points


class OptimizationVisualizer:
    """优化结果可视化器"""

    @staticmethod
    def plot_pareto_front_2d(objectives: np.ndarray,
                            obj_names: Optional[List[str]] = None,
                            title: str = "Pareto Front",
                            filename: str = "pareto_front.png"):
        """绘制2D Pareto前沿"""
        try:
            import matplotlib.pyplot as plt

            if obj_names is None:
                obj_names = [f"Objective {i+1}" for i in range(objectives.shape[1])]

            plt.figure(figsize=(10, 8))
            plt.scatter(objectives[:, 0], objectives[:, 1], c='blue', alpha=0.6, s=50)
            plt.xlabel(obj_names[0], fontsize=12)
            plt.ylabel(obj_names[1], fontsize=12)
            plt.title(title, fontsize=14)
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(filename, dpi=150, bbox_inches='tight')
            plt.close()
            print(f"Pareto前沿图已保存为 {filename}")
        except Exception as e:
            print(f"可视化失败: {e}")

    @staticmethod
    def plot_pareto_front_3d(objectives: np.ndarray,
                            obj_names: Optional[List[str]] = None,
                            title: str = "3D Pareto Front",
                            filename: str = "pareto_front_3d.png"):
        """绘制3D Pareto前沿"""
        try:
            from mpl_toolkits.mplot3d import Axes3D
            import matplotlib.pyplot as plt

            if obj_names is None:
                obj_names = [f"Objective {i+1}" for i in range(3)]

            fig = plt.figure(figsize=(12, 10))
            ax = fig.add_subplot(111, projection='3d')
            ax.scatter(objectives[:, 0], objectives[:, 1], objectives[:, 2],
                      c='blue', alpha=0.6, s=50)
            ax.set_xlabel(obj_names[0], fontsize=12)
            ax.set_ylabel(obj_names[1], fontsize=12)
            ax.set_zlabel(obj_names[2], fontsize=12)
            ax.set_title(title, fontsize=14)
            plt.tight_layout()
            plt.savefig(filename, dpi=150, bbox_inches='tight')
            plt.close()
            print(f"3D Pareto前沿图已保存为 {filename}")
        except Exception as e:
            print(f"可视化失败: {e}")

    @staticmethod
    def plot_convergence(history: List[Dict],
                        filename: str = "convergence.png"):
        """绘制收敛曲线"""
        try:
            import matplotlib.pyplot as plt

            generations = [h["generation"] for h in history]
            best_obj_mean = [np.mean(h["best_objectives"]) for h in history]

            plt.figure(figsize=(10, 6))
            plt.plot(generations, best_obj_mean, 'b-', linewidth=2)
            plt.xlabel('Generation', fontsize=12)
            plt.ylabel('Mean Objective Value', fontsize=12)
            plt.title('Convergence History', fontsize=14)
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(filename, dpi=150, bbox_inches='tight')
            plt.close()
            print(f"收敛曲线已保存为 {filename}")
        except Exception as e:
            print(f"可视化失败: {e}")

    @staticmethod
    def plot_parallel_coordinates(objectives: np.ndarray,
                                obj_names: Optional[List[str]] = None,
                                title: str = "Parallel Coordinates",
                                filename: str = "parallel_coordinates.png"):
        """绘制平行坐标图"""
        try:
            import matplotlib.pyplot as plt
            from sklearn.preprocessing import MinMaxScaler

            if obj_names is None:
                obj_names = [f"Objective {i+1}" for i in range(objectives.shape[1])]

            # 归一化
            scaler = MinMaxScaler()
            normalized = scaler.fit_transform(objectives)

            plt.figure(figsize=(12, 8))
            for i in range(len(normalized)):
                plt.plot(range(len(obj_names)), normalized[i], alpha=0.3, linewidth=1)

            plt.xticks(range(len(obj_names)), obj_names, fontsize=10)
            plt.ylabel('Normalized Value', fontsize=12)
            plt.title(title, fontsize=14)
            plt.grid(True, alpha=0.3)
            plt.tight_layout()
            plt.savefig(filename, dpi=150, bbox_inches='tight')
            plt.close()
            print(f"平行坐标图已保存为 {filename}")
        except Exception as e:
            print(f"可视化失败: {e}")
