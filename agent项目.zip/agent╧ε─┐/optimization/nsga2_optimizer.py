"""
NSGA-II多目标优化算法 - 实现抗震节点设计的多目标优化
支持承载力、延性、用钢量等多个目标的同时优化
"""

import numpy as np
from typing import List, Dict, Optional, Tuple, Callable, Any
from dataclasses import dataclass, field
from enum import Enum
import random


class ObjectiveType(str, Enum):
    """目标类型"""
    MAXIMIZE = "maximize"
    MINIMIZE = "minimize"


@dataclass
class DesignVariable:
    """设计变量"""
    name: str
    lower_bound: float
    upper_bound: float
    variable_type: str = "continuous"  # continuous, integer, categorical
    categories: Optional[List] = None


@dataclass
class ObjectiveFunction:
    """目标函数"""
    name: str
    objective_type: ObjectiveType
    function: Callable
    weight: float = 1.0


@dataclass
class Individual:
    """个体"""
    variables: np.ndarray
    objectives: np.ndarray = field(default_factory=lambda: np.array([]))
    rank: int = 0
    crowding_distance: float = 0.0
    constraint_violations: float = 0.0

    def dominates(self, other: 'Individual') -> bool:
        """判断是否支配另一个个体"""
        # 检查约束违反
        if self.constraint_violations < other.constraint_violations:
            return True
        elif self.constraint_violations > other.constraint_violations:
            return False

        # 检查目标支配
        better_in_any = False
        for i in range(len(self.objectives)):
            if self.objectives[i] < other.objectives[i]:
                better_in_any = True
            elif self.objectives[i] > other.objectives[i]:
                return False
        return better_in_any


@dataclass
class Constraint:
    """约束条件"""
    name: str
    function: Callable
    bound: float = 0.0
    constraint_type: str = "inequality"  # equality, inequality


class NSGA2Optimizer:
    """NSGA-II多目标优化器"""

    def __init__(self, design_variables: List[DesignVariable],
                 objective_functions: List[ObjectiveFunction],
                 constraints: Optional[List[Constraint]] = None,
                 population_size: int = 100,
                 num_generations: int = 200,
                 crossover_rate: float = 0.9,
                 mutation_rate: float = 0.1,
                 crossover_eta: float = 20,
                 mutation_eta: float = 20):
        """
        初始化NSGA-II优化器

        Args:
            design_variables: 设计变量列表
            objective_functions: 目标函数列表
            constraints: 约束条件列表
            population_size: 种群大小
            num_generations: 迭代代数
            crossover_rate: 交叉概率
            mutation_rate: 变异概率
            crossover_eta: 交叉分布指数
            mutation_eta: 变异分布指数
        """
        self.design_variables = design_variables
        self.objective_functions = objective_functions
        self.constraints = constraints or []
        self.pop_size = population_size
        self.num_gen = num_generations
        self.pc = crossover_rate
        self.pm = mutation_rate
        self.eta_c = crossover_eta
        self.eta_m = mutation_eta

        self.population: List[Individual] = []
        self.pareto_front: List[Individual] = []
        self.history: List[Dict[str, Any]] = []

    def initialize_population(self) -> List[Individual]:
        """初始化种群"""
        self.population = []

        for _ in range(self.pop_size):
            # 随机生成变量值
            variables = np.array([
                np.random.uniform(var.lower_bound, var.upper_bound)
                for var in self.design_variables
            ])

            # 评估目标函数和约束
            objectives, violations = self._evaluate(variables)

            individual = Individual(
                variables=variables,
                objectives=objectives,
                constraint_violations=violations
            )
            self.population.append(individual)

        return self.population

    def _evaluate(self, variables: np.ndarray) -> Tuple[np.ndarray, float]:
        """评估目标函数和约束"""
        objectives = []
        for obj_func in self.objective_functions:
            value = obj_func.function(variables)
            if obj_func.objective_type == ObjectiveType.MAXIMIZE:
                value = -value  # 转换为最小化
            objectives.append(value * obj_func.weight)

        # 检查约束
        violations = 0.0
        for constraint in self.constraints:
            value = constraint.function(variables)
            if constraint.constraint_type == "inequality":
                violation = max(0, value - constraint.bound)
            else:
                violation = abs(value - constraint.bound)
            violations += violation

        return np.array(objectives), violations

    def fast_non_dominated_sort(self, population: List[Individual]) -> List[List[int]]:
        """快速非支配排序"""
        n = len(population)
        domination_count = np.zeros(n, dtype=int)
        dominated_set = [[] for _ in range(n)]
        front = [[]]

        for i in range(n):
            for j in range(i + 1, n):
                if population[i].dominates(population[j]):
                    dominated_set[i].append(j)
                    domination_count[j] += 1
                elif population[j].dominates(population[i]):
                    dominated_set[j].append(i)
                    domination_count[i] += 1

            if domination_count[i] == 0:
                front[0].append(i)

        current_front = 0
        while front[current_front]:
            next_front = []
            for i in front[current_front]:
                for j in dominated_set[i]:
                    domination_count[j] -= 1
                    if domination_count[j] == 0:
                        next_front.append(j)
            current_front += 1
            front.append(next_front)

        return [f for f in front if f]

    def calculate_crowding_distance(self, population: List[Individual],
                                   front_indices: List[int]) -> Dict[int, float]:
        """计算拥挤距离"""
        n = len(front_indices)
        distances = {idx: 0.0 for idx in front_indices}

        if n <= 2:
            for idx in front_indices:
                distances[idx] = float('inf')
            return distances

        num_objectives = len(population[front_indices[0]].objectives)

        for obj_idx in range(num_objectives):
            # 按目标值排序
            sorted_indices = sorted(front_indices,
                                   key=lambda i: population[i].objectives[obj_idx])

            # 边界点距离无穷大
            distances[sorted_indices[0]] = float('inf')
            distances[sorted_indices[-1]] = float('inf')

            # 计算目标值范围
            obj_range = (population[sorted_indices[-1]].objectives[obj_idx] -
                        population[sorted_indices[0]].objectives[obj_idx])

            if obj_range == 0:
                continue

            # 计算中间点距离
            for i in range(1, n - 1):
                distances[sorted_indices[i]] += (
                    (population[sorted_indices[i+1]].objectives[obj_idx] -
                     population[sorted_indices[i-1]].objectives[obj_idx]) / obj_range
                )

        return distances

    def tournament_selection(self, population: List[Individual]) -> Individual:
        """锦标赛选择"""
        i, j = random.sample(range(len(population)), 2)

        if population[i].rank < population[j].rank:
            return population[i]
        elif population[i].rank > population[j].rank:
            return population[j]
        elif population[i].crowding_distance > population[j].crowding_distance:
            return population[i]
        else:
            return population[j]

    def sbx_crossover(self, parent1: Individual, parent2: Individual) -> Tuple[Individual, Individual]:
        """模拟二进制交叉(SBX)"""
        child1_vars = parent1.variables.copy()
        child2_vars = parent2.variables.copy()

        if random.random() < self.pc:
            for i in range(len(self.design_variables)):
                if random.random() < 0.5:
                    if abs(parent1.variables[i] - parent2.variables[i]) > 1e-10:
                        y1, y2 = min(parent1.variables[i], parent2.variables[i]), \
                                max(parent1.variables[i], parent2.variables[i])
                        lb, ub = self.design_variables[i].lower_bound, \
                                self.design_variables[i].upper_bound

                        # 计算beta
                        rand = random.random()
                        beta = 1.0 + (2.0 * (y1 - lb) / (y2 - y1))
                        alpha = 2.0 - beta ** (-(self.eta_c + 1.0))
                        if rand <= (1.0 / alpha):
                            betaq = (rand * alpha) ** (1.0 / (self.eta_c + 1.0))
                        else:
                            betaq = (1.0 / (2.0 - rand * alpha)) ** (1.0 / (self.eta_c + 1.0))

                        child1_vars[i] = 0.5 * ((y1 + y2) - betaq * (y2 - y1))
                        child2_vars[i] = 0.5 * ((y1 + y2) + betaq * (y2 - y1))

                        child1_vars[i] = np.clip(child1_vars[i], lb, ub)
                        child2_vars[i] = np.clip(child2_vars[i], lb, ub)

        return self._create_individual(child1_vars), self._create_individual(child2_vars)

    def polynomial_mutation(self, individual: Individual) -> Individual:
        """多项式变异"""
        mutated_vars = individual.variables.copy()

        if random.random() < self.pm:
            for i in range(len(self.design_variables)):
                if random.random() < 1.0 / len(self.design_variables):
                    lb, ub = self.design_variables[i].lower_bound, \
                            self.design_variables[i].upper_bound

                    delta1 = (mutated_vars[i] - lb) / (ub - lb)
                    delta2 = (ub - mutated_vars[i]) / (ub - lb)

                    rand = random.random()
                    if rand < 0.5:
                        deltaq = (2.0 * rand + (1.0 - 2.0 * rand) *
                                 (1.0 - delta1) ** (self.eta_m + 1.0)) ** \
                                (1.0 / (self.eta_m + 1.0)) - 1.0
                    else:
                        deltaq = 1.0 - (2.0 * (1.0 - rand) + 2.0 * (rand - 0.5) *
                                       (1.0 - delta2) ** (self.eta_m + 1.0)) ** \
                                (1.0 / (self.eta_m + 1.0))

                    mutated_vars[i] = mutated_vars[i] + deltaq * (ub - lb)
                    mutated_vars[i] = np.clip(mutated_vars[i], lb, ub)

        return self._create_individual(mutated_vars)

    def _create_individual(self, variables: np.ndarray) -> Individual:
        """创建个体"""
        objectives, violations = self._evaluate(variables)
        return Individual(
            variables=variables,
            objectives=objectives,
            constraint_violations=violations
        )

    def evolve(self, verbose: bool = True) -> List[Individual]:
        """执行优化"""
        if verbose:
            print("=" * 60)
            print("NSGA-II多目标优化算法")
            print("=" * 60)
            print(f"种群大小: {self.pop_size}")
            print(f"迭代代数: {self.num_gen}")
            print(f"设计变量数: {len(self.design_variables)}")
            print(f"目标函数数: {len(self.objective_functions)}")
            print(f"约束条件数: {len(self.constraints)}")
            print("=" * 60)

        # 初始化种群
        self.initialize_population()

        for gen in range(self.num_gen):
            # 非支配排序
            fronts = self.fast_non_dominated_sort(self.population)

            # 计算拥挤距离
            for front in fronts:
                distances = self.calculate_crowding_distance(self.population, front)
                for idx, dist in distances.items():
                    self.population[idx].crowding_distance = dist

            # 设置rank
            for rank, front in enumerate(fronts):
                for idx in front:
                    self.population[idx].rank = rank

            # 生成子代
            offspring = []
            while len(offspring) < self.pop_size:
                parent1 = self.tournament_selection(self.population)
                parent2 = self.tournament_selection(self.population)
                child1, child2 = self.sbx_crossover(parent1, parent2)
                child1 = self.polynomial_mutation(child1)
                child2 = self.polynomial_mutation(child2)
                offspring.extend([child1, child2])

            offspring = offspring[:self.pop_size]

            # 合并父代和子代
            combined = self.population + offspring

            # 非支配排序
            combined_fronts = self.fast_non_dominated_sort(combined)

            # 计算拥挤距离
            for front in combined_fronts:
                distances = self.calculate_crowding_distance(combined, front)
                for idx, dist in distances.items():
                    combined[idx].crowding_distance = dist

            # 选择新一代种群
            new_population = []
            for front in combined_fronts:
                if len(new_population) + len(front) <= self.pop_size:
                    for idx in front:
                        new_population.append(combined[idx])
                else:
                    remaining = self.pop_size - len(new_population)
                    sorted_front = sorted(front, key=lambda i: combined[i].crowding_distance,
                                         reverse=True)
                    for i in range(remaining):
                        new_population.append(combined[sorted_front[i]])
                    break

            self.population = new_population

            # 记录历史
            gen_stats = self._calculate_generation_stats(gen)
            self.history.append(gen_stats)

            if verbose and (gen % 10 == 0 or gen == self.num_gen - 1):
                self._print_generation_info(gen, gen_stats)

        # 提取Pareto前沿
        fronts = self.fast_non_dominated_sort(self.population)
        if fronts:
            self.pareto_front = [self.population[i] for i in fronts[0]]

        if verbose:
            self._print_optimization_summary()

        return self.pareto_front

    def _calculate_generation_stats(self, generation: int) -> Dict[str, Any]:
        """计算每代统计信息"""
        # 计算目标函数值
        obj_values = np.array([ind.objectives for ind in self.population])

        stats = {
            "generation": generation,
            "best_objectives": np.min(obj_values, axis=0).tolist(),
            "mean_objectives": np.mean(obj_values, axis=0).tolist(),
            "worst_objectives": np.max(obj_values, axis=0).tolist(),
            "std_objectives": np.std(obj_values, axis=0).tolist(),
            "num_pareto": len(self.pareto_front),
            "avg_constraint_violations": np.mean([ind.constraint_violations
                                                  for ind in self.population]),
        }

        return stats

    def _print_generation_info(self, generation: int, stats: Dict):
        """打印代信息"""
        print(f"\n第 {generation} 代:")
        print(f"  最优目标值: {[f'{v:.4f}' for v in stats['best_objectives']]}")
        print(f"  平均目标值: {[f'{v:.4f}' for v in stats['mean_objectives']]}")
        print(f"  Pareto解数量: {stats['num_pareto']}")
        print(f"  平均约束违反: {stats['avg_constraint_violations']:.4f}")

    def _print_optimization_summary(self):
        """打印优化摘要"""
        print("\n" + "=" * 60)
        print("优化完成！")
        print("=" * 60)
        print(f"Pareto前沿解数量: {len(self.pareto_front)}")

        if self.pareto_front:
            # 提取Pareto前沿目标值
            obj_values = np.array([ind.objectives for ind in self.pareto_front])
            print("\n目标函数范围:")
            for i, obj_func in enumerate(self.objective_functions):
                print(f"  {obj_func.name}: [{obj_values[:, i].min():.4f}, "
                      f"{obj_values[:, i].max():.4f}]")

            # 找到各目标的最优解
            print("\n各目标最优解:")
            for i, obj_func in enumerate(self.objective_functions):
                best_idx = np.argmin(obj_values[:, i])
                best_ind = self.pareto_front[best_idx]
                print(f"  {obj_func.name}最优:")
                print(f"    目标值: {obj_values[best_idx, i]:.4f}")
                print(f"    设计变量: {[f'{v:.4f}' for v in best_ind.variables]}")

    def get_pareto_front_data(self) -> Dict[str, Any]:
        """获取Pareto前沿数据"""
        if not self.pareto_front:
            return {}

        obj_values = np.array([ind.objectives for ind in self.pareto_front])
        var_values = np.array([ind.variables for ind in self.pareto_front])

        return {
            "objectives": {
                obj_func.name: obj_values[:, i].tolist()
                for i, obj_func in enumerate(self.objective_functions)
            },
            "variables": {
                var.name: var_values[:, i].tolist()
                for i, var in enumerate(self.design_variables)
            },
            "num_solutions": len(self.pareto_front),
            "convergence_history": self.history
        }

    def select_best_solution(self, method: str = "topsis",
                           weights: Optional[List[float]] = None) -> Individual:
        """选择最优解"""
        if not self.pareto_front:
            raise ValueError("Pareto前沿为空，请先执行优化")

        if method == "topsis":
            return self._topsis_selection(weights)
        elif method == "weighting":
            return self._weighting_selection(weights)
        elif method == "knee_point":
            return self._knee_point_selection()
        else:
            raise ValueError(f"不支持的选择方法: {method}")

    def _topsis_selection(self, weights: Optional[List[float]] = None) -> Individual:
        """TOPSIS法选择"""
        if weights is None:
            weights = [1.0 / len(self.objective_functions)] * len(self.objective_functions)

        obj_values = np.array([ind.objectives for ind in self.pareto_front])

        # 标准化
        norm_values = obj_values / np.sqrt(np.sum(obj_values**2, axis=0))

        # 加权
        weighted_values = norm_values * np.array(weights)

        # 计算正理想解和负理想解
        ideal_positive = np.min(weighted_values, axis=0)
        ideal_negative = np.max(weighted_values, axis=0)

        # 计算距离
        dist_positive = np.sqrt(np.sum((weighted_values - ideal_positive)**2, axis=1))
        dist_negative = np.sqrt(np.sum((weighted_values - ideal_negative)**2, axis=1))

        # 计算相对接近度
        closeness = dist_negative / (dist_positive + dist_negative)

        # 选择最优解
        best_idx = np.argmax(closeness)
        return self.pareto_front[best_idx]

    def _weighting_selection(self, weights: Optional[List[float]] = None) -> Individual:
        """加权和法选择"""
        if weights is None:
            weights = [1.0 / len(self.objective_functions)] * len(self.objective_functions)

        obj_values = np.array([ind.objectives for ind in self.pareto_front])
        weighted_sum = np.sum(obj_values * np.array(weights), axis=1)

        best_idx = np.argmin(weighted_sum)
        return self.pareto_front[best_idx]

    def _knee_point_selection(self) -> Individual:
        """膝点选择"""
        obj_values = np.array([ind.objectives for ind in self.pareto_front])

        # 标准化
        norm_values = (obj_values - np.min(obj_values, axis=0)) / \
                     (np.max(obj_values, axis=0) - np.min(obj_values, axis=0) + 1e-10)

        # 计算到理想点的距离
        ideal_point = np.zeros(len(self.objective_functions))
        distances = np.sqrt(np.sum((norm_values - ideal_point)**2, axis=1))

        # 选择最接近理想点的解
        best_idx = np.argmin(distances)
        return self.pareto_front[best_idx]
