"""
智能抗震节点设计与多目标优化Agent系统 - 主程序入口
"""

import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from models.data_models import (
    DesignTask, NodeGeometry, BeamSection, ColumnSection,
    SeismicDesignParams, SeismicIntensity, SiteClass, DesignGroup,
    LoadCase, LoadCombination, EndPlate, BoltLayout, BoltDiameter,
    BoltGrade, SteelGrade, Stiffener, WeldDetail, ConnectionType
)
from agents.orchestrator import OrchestratorAgent, AgentType
from agents.knowledge_agent import KnowledgeAgent
from agents.analysis_agent import AnalysisAgent
from agents.design_agent import DesignAgent
from agents.optimization_agent import OptimizationAgent
from agents.verification_agent import VerificationAgent


def create_sample_task() -> DesignTask:
    """创建示例任务"""
    # 定义梁截面
    beam = BeamSection(
        name="H500x200x10x16",
        height=500,
        width=200,
        web_thickness=10,
        flange_thickness=16,
        steel_grade=SteelGrade.Q345B
    )

    # 定义柱截面
    column = ColumnSection(
        name="H400x400x12x20",
        height=400,
        width=400,
        web_thickness=12,
        flange_thickness=20,
        steel_grade=SteelGrade.Q345B
    )

    # 定义节点几何
    geometry = NodeGeometry(
        beam=beam,
        column=column,
        connection_type=ConnectionType.END_PLATE,
        beam_span=6000,
        column_height=4000
    )

    # 定义抗震设计参数
    seismic_params = SeismicDesignParams(
        intensity=SeismicIntensity.VIII,
        site_class=SiteClass.II,
        design_group=DesignGroup.SECOND,
        design_life=50,
        importance_factor=1.0,
        response_modification=3.0
    )

    # 定义荷载工况
    load_cases = [
        LoadCase(
            name="恒载",
            dead_load=200,
            live_load=0
        ),
        LoadCase(
            name="活载",
            dead_load=0,
            live_load=150
        ),
        LoadCase(
            name="地震作用",
            dead_load=0,
            live_load=0,
            earthquake_load=300
        )
    ]

    # 定义荷载组合
    load_combinations = [
        LoadCombination(
            name="1.2恒+1.4活",
            factor_dead=1.2,
            factor_live=1.4
        ),
        LoadCombination(
            name="1.2恒+1.4活+0.5地震",
            factor_dead=1.2,
            factor_live=1.4,
            factor_earthquake=0.5
        ),
        LoadCombination(
            name="1.2恒+1.4地震+0.5活",
            factor_dead=1.2,
            factor_live=0.5,
            factor_earthquake=1.4
        )
    ]

    # 定义优化目标
    optimization_targets = {
        "capacity": True,
        "weight": True,
        "stiffness": True,
        "ductility": True
    }

    # 创建设计任务
    task = DesignTask(
        name="8度区钢框架梁柱端板连接节点设计",
        description="设计一个8度地震设防区的钢框架梁柱端板连接节点，要求满足承载力、刚度、延性和经济性等多目标优化",
        load_cases=load_cases,
        load_combinations=load_combinations,
        seismic_params=seismic_params,
        geometry=geometry,
        optimization_targets=optimization_targets
    )

    return task


def main():
    """主函数"""
    print("=" * 70)
    print("智能抗震节点设计与多目标优化Agent系统")
    print("=" * 70)
    print("版本: 1.0.0")
    print("作者: 抗震节点研究团队")
    print("=" * 70)

    # 创建设计任务
    print("\n[1/5] 创建设计任务...")
    task = create_sample_task()
    print(f"任务ID: {task.task_id}")
    print(f"任务名称: {task.name}")
    print(f"地震设防烈度: {task.seismic_params.intensity.value}度")
    print(f"场地类别: {task.seismic_params.site_class.value}")

    # 创建主控Agent
    print("\n[2/5] 初始化Agent系统...")
    orchestrator = OrchestratorAgent()

    # 注册子Agent
    knowledge_agent = KnowledgeAgent()
    analysis_agent = AnalysisAgent()
    design_agent = DesignAgent()
    optimization_agent = OptimizationAgent()
    verification_agent = VerificationAgent()

    orchestrator.register_agent(AgentType.KNOWLEDGE, knowledge_agent)
    orchestrator.register_agent(AgentType.ANALYSIS, analysis_agent)
    orchestrator.register_agent(AgentType.DESIGN, design_agent)
    orchestrator.register_agent(AgentType.OPTIMIZATION, optimization_agent)
    orchestrator.register_agent(AgentType.VERIFICATION, verification_agent)

    # 创建执行计划
    print("\n[3/5] 创建执行计划...")
    execution_plan = orchestrator.create_execution_plan(task)
    print(f"执行步骤数: {len(execution_plan)}")

    # 执行计划
    print("\n[4/5] 执行设计任务...")
    completed_task = orchestrator.execute_plan(verbose=True)

    # 输出结果
    print("\n[5/5] 输出设计结果...")
    print("\n" + "=" * 70)
    print("设计结果摘要")
    print("=" * 70)

    # 获取执行摘要
    summary = orchestrator.get_execution_summary()
    print(f"任务ID: {summary['task_id']}")
    print(f"总步骤数: {summary['total_steps']}")
    print(f"完成步骤数: {summary['completed_steps']}")
    print(f"失败步骤数: {summary['failed_steps']}")
    print(f"成功率: {summary['success_rate'] * 100:.1f}%")
    print(f"总耗时: {summary['total_time']:.2f}秒")

    # 输出关键结果
    if "final_report" in orchestrator.context:
        report = orchestrator.context["final_report"]
        print("\n最终报告:")
        if isinstance(report, dict):
            for key, value in report.items():
                try:
                    if isinstance(value, str):
                        print(f"  {key}: {value[:100]}...")
                    elif isinstance(value, (int, float)):
                        print(f"  {key}: {value}")
                    else:
                        # 对于复杂对象，只打印类型
                        print(f"  {key}: [{type(value).__name__}]")
                except UnicodeEncodeError:
                    # 忽略编码错误
                    pass

    print("\n" + "=" * 70)
    print("任务完成！")
    print("=" * 70)

    return completed_task


if __name__ == "__main__":
    main()
