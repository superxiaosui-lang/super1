"""
优化Agent - 负责多目标优化设计
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import numpy as np

from optimization.nsga2_optimizer import (
    NSGA2Optimizer, DesignVariable, ObjectiveFunction,
    Constraint, ObjectiveType
)
from optimization.multi_objective import MultiObjectiveMetrics, OptimizationVisualizer


class OptimizationAgent:
    """优化Agent - 多目标优化设计"""

    def __init__(self):
        self.optimizer: Optional[NSGA2Optimizer] = None
        self.optimization_history: List[Dict[str, Any]] = []

    def optimize_design(self, geometry: Dict[str, Any],
                       analysis_results: Dict[str, Any],
                       verification_results: Dict[str, Any],
                       targets: Dict[str, bool]) -> Dict[str, Any]:
        """执行多目标优化"""
        print(f"  [OptimizationAgent] 执行多目标优化")

        # 定义设计变量
        design_variables = self._define_design_variables(geometry)

        # 定义目标函数
        objective_functions = self._define_objective_functions(targets)

        # 定义约束条件
        constraints = self._define_constraints(analysis_results, verification_results)

        # 创建优化器
        self.optimizer = NSGA2Optimizer(
            design_variables=design_variables,
            objective_functions=objective_functions,
            constraints=constraints,
            population_size=50,
            num_generations=30,
            crossover_rate=0.9,
            mutation_rate=0.1
        )

        # 执行优化
        pareto_front = self.optimizer.evolve(verbose=True)

        # 选择最优解
        best_solution = self.optimizer.select_best_solution(method="topsis")

        # 整理优化结果
        results = {
            "pareto_front": self.optimizer.get_pareto_front_data(),
            "best_solution": {
                "variables": {
                    var.name: best_solution.variables[i]
                    for i, var in enumerate(design_variables)
                },
                "objectives": {
                    obj.name: -best_solution.objectives[i] if obj.objective_type == ObjectiveType.MAXIMIZE
                    else best_solution.objectives[i]
                    for i, obj in enumerate(objective_functions)
                }
            },
            "optimization_summary": self._generate_optimization_summary(
                design_variables, objective_functions, best_solution
            ),
            "recommended_design": self._generate_recommended_design(
                best_solution, design_variables
            )
        }

        self.optimization_history.append({
            "type": "multi_objective_optimization",
            "pareto_size": len(pareto_front),
            "best_fitness": results["best_solution"]["objectives"]
        })

        return results

    def _define_design_variables(self, geometry: Dict[str, Any]) -> List[DesignVariable]:
        """定义设计变量"""
        return [
            DesignVariable(
                name="bolt_diameter",
                lower_bound=16,
                upper_bound=30,
                variable_type="integer"
            ),
            DesignVariable(
                name="bolt_number_y",
                lower_bound=2,
                upper_bound=6,
                variable_type="integer"
            ),
            DesignVariable(
                name="end_plate_thickness",
                lower_bound=16,
                upper_bound=50,
                variable_type="continuous"
            ),
            DesignVariable(
                name="stiffener_thickness",
                lower_bound=8,
                upper_bound=30,
                variable_type="continuous"
            ),
            DesignVariable(
                name="weld_size",
                lower_bound=6,
                upper_bound=16,
                variable_type="continuous"
            ),
        ]

    def _define_objective_functions(self, targets: Dict[str, bool]) -> List[ObjectiveFunction]:
        """定义目标函数"""
        objectives = []

        # 承载力最大化
        if targets.get("capacity", True):
            objectives.append(ObjectiveFunction(
                name="承载力",
                objective_type=ObjectiveType.MAXIMIZE,
                function=self._capacity_objective,
                weight=1.0
            ))

        # 用钢量最小化
        if targets.get("weight", True):
            objectives.append(ObjectiveFunction(
                name="用钢量",
                objective_type=ObjectiveType.MINIMIZE,
                function=self._weight_objective,
                weight=0.8
            ))

        # 刚度最大化
        if targets.get("stiffness", True):
            objectives.append(ObjectiveFunction(
                name="刚度",
                objective_type=ObjectiveType.MAXIMIZE,
                function=self._stiffness_objective,
                weight=0.6
            ))

        # 延性最大化
        if targets.get("ductility", True):
            objectives.append(ObjectiveFunction(
                name="延性",
                objective_type=ObjectiveType.MAXIMIZE,
                function=self._ductility_objective,
                weight=0.5
            ))

        return objectives

    def _define_constraints(self, analysis_results: Dict[str, Any],
                           verification_results: Dict[str, Any]) -> List[Constraint]:
        """定义约束条件"""
        constraints = []

        # 螺栓间距约束
        constraints.append(Constraint(
            name="螺栓最小间距",
            function=lambda x: x[1] * 60 - (3 * x[0]),  # bolt_number_y * spacing >= 3d
            bound=0,
            constraint_type="inequality"
        ))

        # 端板厚度约束
        constraints.append(Constraint(
            name="端板最小厚度",
            function=lambda x: x[2] - 16,  # end_plate_thickness >= 16
            bound=0,
            constraint_type="inequality"
        ))

        # 承载力约束
        capacity_factor = analysis_results.get("summary", {}).get("safety_factors", {}).get("moment_ratio", 1.2)
        constraints.append(Constraint(
            name="承载力比",
            function=lambda x: self._capacity_ratio_constraint(x, capacity_factor),
            bound=0,
            constraint_type="inequality"
        ))

        return constraints

    def _capacity_objective(self, variables: np.ndarray) -> float:
        """承载力目标函数"""
        bolt_diameter = variables[0]
        bolt_number_y = variables[1]
        end_plate_thickness = variables[2]

        # 简化计算
        bolt_capacity = bolt_number_y * 0.1 * bolt_diameter**2
        plate_capacity = 0.01 * end_plate_thickness * 200
        capacity = min(bolt_capacity, plate_capacity)

        return capacity

    def _weight_objective(self, variables: np.ndarray) -> float:
        """用钢量目标函数"""
        bolt_diameter = variables[0]
        bolt_number_y = variables[1]
        end_plate_thickness = variables[2]
        stiffener_thickness = variables[3]

        # 螺栓重量
        bolt_weight = bolt_number_y * 4 * 0.001 * bolt_diameter**2

        # 端板重量
        plate_weight = 0.2 * 0.5 * end_plate_thickness * 7.85e-6 * 1e3

        # 加劲肋重量
        stiffener_weight = stiffener_thickness * 0.1 * 0.3 * 7.85e-6 * 1e3

        total_weight = bolt_weight + plate_weight + stiffener_weight
        return total_weight

    def _stiffness_objective(self, variables: np.ndarray) -> float:
        """刚度目标函数"""
        end_plate_thickness = variables[2]
        stiffener_thickness = variables[3]

        # 刚度与端板和加劲肋厚度相关
        stiffness = end_plate_thickness * 10 + stiffener_thickness * 5
        return stiffness

    def _ductility_objective(self, variables: np.ndarray) -> float:
        """延性目标函数"""
        end_plate_thickness = variables[2]
        bolt_number_y = variables[1]

        # 延性与端板厚度和螺栓数量相关
        ductility = bolt_number_y * 2.0 - end_plate_thickness * 0.05
        return max(1.0, ductility)

    def _capacity_ratio_constraint(self, variables: np.ndarray,
                                  capacity_factor: float) -> float:
        """承载力约束"""
        capacity = self._capacity_objective(variables)
        required = capacity_factor * 100
        return capacity - required

    def _generate_optimization_summary(self, design_variables: List[DesignVariable],
                                      objective_functions: List[ObjectiveFunction],
                                      best_solution) -> str:
        """生成优化摘要"""
        summary = "优化完成\n"
        summary += f"设计变量数: {len(design_variables)}\n"
        summary += f"目标函数数: {len(objective_functions)}\n"
        summary += f"Pareto前沿解数: {len(self.optimizer.pareto_front)}\n"
        summary += f"\n最优解设计变量:\n"

        for i, var in enumerate(design_variables):
            summary += f"  {var.name}: {best_solution.variables[i]:.2f}\n"

        summary += f"\n最优解目标值:\n"
        for i, obj in enumerate(objective_functions):
            value = best_solution.objectives[i]
            if obj.objective_type == ObjectiveType.MAXIMIZE:
                value = -value
            summary += f"  {obj.name}: {value:.4f}\n"

        return summary

    def _generate_recommended_design(self, best_solution,
                                    design_variables: List[DesignVariable]) -> Dict[str, Any]:
        """生成推荐设计"""
        design = {}
        for i, var in enumerate(design_variables):
            value = best_solution.variables[i]
            if var.variable_type == "integer":
                value = int(round(value))
            design[var.name] = value

        return {
            "parameters": design,
            "description": self._describe_design(design)
        }

    def _describe_design(self, design: Dict[str, Any]) -> str:
        """描述设计方案"""
        description = f"推荐采用M{int(design.get('bolt_diameter', 20))}高强度螺栓，"
        description += f"y方向布置{int(design.get('bolt_number_y', 2))}排，"
        description += f"端板厚度{design.get('end_plate_thickness', 20):.0f}mm"
        if design.get('stiffener_thickness', 0) > 0:
            description += f"，加劲肋厚度{design.get('stiffener_thickness', 0):.0f}mm"
        description += f"，焊脚尺寸{design.get('weld_size', 8):.0f}mm。"
        return description

    def receive_message(self, message):
        """接收消息"""
        print(f"  [OptimizationAgent] 收到消息: {message.message_type}")
