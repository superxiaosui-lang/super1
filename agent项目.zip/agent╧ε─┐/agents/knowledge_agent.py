"""
知识Agent - 负责规范条文查询、约束提取和知识推理
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import json

from knowledge.code_database import SeismicCodeDatabase, CodeType, DesignConstraint
from knowledge.knowledge_graph import SeismicKnowledgeGraph, NodeType, RelationType


class KnowledgeAgent:
    """知识Agent - 规范知识查询与推理"""

    def __init__(self):
        self.code_db = SeismicCodeDatabase()
        self.knowledge_graph = SeismicKnowledgeGraph()
        self.query_history: List[Dict[str, Any]] = []

    def query_code_requirements(self, connection_type: str,
                               seismic_intensity: int,
                               site_class: str) -> Dict[str, Any]:
        """查询规范要求"""
        print(f"  [KnowledgeAgent] 查询规范要求: {connection_type}, {seismic_intensity}度, {site_class}类场地")

        # 查询相关规范条文
        clauses = []
        keywords = ["梁柱连接", "端板", "高强度螺栓", "焊缝", "加劲肋"]
        for keyword in keywords:
            results = self.code_db.search_by_keyword(keyword)
            clauses.extend(results)

        # 提取约束
        constraints = {}
        component_types = ["bolt", "weld", "end_plate", "connection"]
        for comp_type in component_types:
            comp_constraints = self.code_db.get_constraints_for_component(comp_type)
            for constraint in comp_constraints:
                constraints[constraint.constraint_id] = {
                    "name": constraint.name,
                    "description": constraint.description,
                    "formula": constraint.formula,
                    "lower_bound": constraint.lower_bound,
                    "upper_bound": constraint.upper_bound,
                    "unit": constraint.unit,
                    "reference": constraint.reference_clause,
                    "severity": constraint.severity
                }

        # 查询知识图谱中的相关概念
        related_concepts = []
        concept_nodes = self.knowledge_graph.query_by_pattern({'node_type': NodeType.CONCEPT})
        for concept in concept_nodes:
            related_nodes = self.knowledge_graph.query_related_nodes(concept.node_id)
            related_concepts.append({
                "concept": concept.name,
                "description": concept.description,
                "related_components": [n.name for n in related_nodes if n.node_type == NodeType.COMPONENT]
            })

        # 整理结果
        result = {
            "applicable_clauses": [
                {
                    "code": clause.code_type.value,
                    "number": clause.clause_number,
                    "title": clause.title,
                    "content": clause.content[:200] + "..." if len(clause.content) > 200 else clause.content,
                    "type": clause.clause_type.value
                }
                for clause in clauses[:20]  # 限制返回数量
            ],
            "constraints": constraints,
            "design_concepts": related_concepts,
            "special_requirements": self._get_special_requirements(connection_type, seismic_intensity),
            "parameter_limits": self._get_parameter_limits(connection_type),
            "query_summary": {
                "num_clauses": len(clauses),
                "num_constraints": len(constraints),
                "num_concepts": len(related_concepts)
            }
        }

        self.query_history.append({
            "query": {"connection_type": connection_type,
                     "seismic_intensity": seismic_intensity,
                     "site_class": site_class},
            "result_summary": result["query_summary"]
        })

        return result

    def _get_special_requirements(self, connection_type: str,
                                 seismic_intensity: int) -> List[str]:
        """获取特殊要求"""
        requirements = []

        if "端板" in connection_type:
            requirements.extend([
                "端板厚度不宜小于16mm",
                "端板应采用高强度螺栓与柱翼缘连接",
                "端板连接处应设置加劲肋",
                "端板与梁翼缘应采用全熔透坡口焊缝连接"
            ])

        if seismic_intensity >= 8:
            requirements.extend([
                "应进行节点域承载力验算",
                "连接的极限承载力应满足规范要求",
                "应验算连接的塑性转动能力"
            ])

        if seismic_intensity >= 9:
            requirements.extend([
                "应采用更高性能的连接构造",
                "应进行时程分析验证节点性能"
            ])

        return requirements

    def _get_parameter_limits(self, connection_type: str) -> Dict[str, Any]:
        """获取参数限值"""
        limits = {
            "bolt_diameter": {"min": 16, "max": 30, "unit": "mm", "recommended": [20, 22, 24]},
            "bolt_spacing": {"min_ratio": "3d", "max_ratio": "12d", "unit": "d"},
            "end_plate_thickness": {"min": 16, "max": 80, "unit": "mm", "recommended": [20, 25, 30]},
            "weld_size": {"min_formula": "1.5√t", "max_formula": "1.2t", "unit": "mm"},
            "stiffener_thickness": {"min": 8, "max": 50, "unit": "mm"}
        }
        return limits

    def query_knowledge_graph(self, component: str) -> Dict[str, Any]:
        """查询知识图谱"""
        # 查找构件节点
        component_nodes = self.knowledge_graph.query_by_pattern({
            'node_type': NodeType.COMPONENT,
            'name_contains': component
        })

        if not component_nodes:
            return {"error": f"未找到构件: {component}"}

        node = component_nodes[0]

        # 查询相关参数
        related_params = self.knowledge_graph.query_related_nodes(node.node_id, RelationType.CONSTRAINT)

        # 查询约束链
        constraint_chain = self.knowledge_graph.get_constraint_chain(node.node_id)

        # 查询相关规范
        related_codes = self.knowledge_graph.query_reverse_related_nodes(node.node_id, RelationType.BELONGS_TO)

        return {
            "component": node.name,
            "description": node.description,
            "related_parameters": [
                {"name": p.name, "description": p.description}
                for p in related_params
            ],
            "constraint_chain": constraint_chain,
            "applicable_codes": [
                {"name": c.name, "description": c.description}
                for c in related_codes
            ]
        }

    def check_constraint(self, constraint_id: str,
                        design_params: Dict[str, float]) -> Dict[str, Any]:
        """检查单个约束"""
        constraints = self.code_db.constraints
        if constraint_id not in constraints:
            return {"error": f"约束 {constraint_id} 不存在"}

        constraint = constraints[constraint_id]
        value = design_params.get(constraint_id)

        if value is None:
            return {"error": f"缺少参数: {constraint_id}"}

        passed, message = constraint.check(value)

        return {
            "constraint_id": constraint_id,
            "constraint_name": constraint.name,
            "value": value,
            "passed": passed,
            "message": message,
            "reference": constraint.reference_clause,
            "severity": constraint.severity
        }

    def check_all_constraints(self, design_params: Dict[str, float]) -> Dict[str, Any]:
        """检查所有约束"""
        results = self.code_db.check_all_constraints(design_params)

        passed_count = sum(1 for passed, _ in results.values() if passed)
        total_count = len(results)

        return {
            "results": {
                cid: {"passed": passed, "message": message}
                for cid, (passed, message) in results.items()
            },
            "summary": {
                "total": total_count,
                "passed": passed_count,
                "failed": total_count - passed_count,
                "compliance_rate": passed_count / total_count if total_count > 0 else 0
            }
        }

    def infer_design_parameters(self, geometry: Dict[str, Any],
                               seismic_params: Dict[str, Any]) -> Dict[str, Any]:
        """推理设计参数"""
        # 基于几何参数和抗震参数推理推荐的设计参数
        beam_height = geometry.get("beam_height", 500)
        column_width = geometry.get("column_width", 400)
        intensity = seismic_params.get("intensity", 7)

        # 推理螺栓直径
        if beam_height <= 400:
            bolt_diameter = 20
        elif beam_height <= 600:
            bolt_diameter = 22
        else:
            bolt_diameter = 24

        # 推理螺栓数量
        bolt_number_y = max(2, beam_height // 150)

        # 推理端板厚度
        if intensity <= 7:
            end_plate_thickness = 20
        elif intensity == 8:
            end_plate_thickness = 25
        else:
            end_plate_thickness = 30

        # 推理加劲肋
        need_stiffener = beam_height > 500 or intensity >= 8

        return {
            "recommended_bolt_diameter": bolt_diameter,
            "recommended_bolt_number_y": bolt_number_y,
            "recommended_end_plate_thickness": end_plate_thickness,
            "need_stiffener": need_stiffener,
            "recommendations": [
                f"推荐螺栓直径: M{bolt_diameter}",
                f"推荐y方向螺栓数量: {bolt_number_y}个",
                f"推荐端板厚度: {end_plate_thickness}mm",
                "建议设置加劲肋" if need_stiffener else "可不设置加劲肋"
            ],
            "reasoning": self._explain_reasoning(geometry, seismic_params)
        }

    def _explain_reasoning(self, geometry: Dict[str, Any],
                          seismic_params: Dict[str, Any]) -> str:
        """解释推理过程"""
        beam_height = geometry.get("beam_height", 500)
        intensity = seismic_params.get("intensity", 7)

        reasoning = f"基于梁高{beam_height}mm"
        if beam_height > 500:
            reasoning += "，梁高较大，需要更多螺栓和更厚的端板"
        reasoning += f"，{intensity}度地震设防"
        if intensity >= 8:
            reasoning += "，高烈度区需加强连接构造"
        reasoning += "。"

        return reasoning

    def generate_report(self, **kwargs) -> Dict[str, Any]:
        """生成报告"""
        task = kwargs.get("task")
        all_results = kwargs.get("all_results", {})

        report = {
            "title": "抗震节点设计报告",
            "task_info": {
                "task_id": task.task_id if task else "N/A",
                "task_name": task.name if task else "N/A",
                "timestamp": datetime.now().isoformat()
            },
            "sections": [
                {
                    "title": "一、设计依据",
                    "content": "本设计依据以下规范：\n1. GB50011-2010 建筑抗震设计规范\n2. GB50017-2017 钢结构设计标准\n3. JGJ82-2011 钢结构高强度螺栓连接技术规程"
                },
                {
                    "title": "二、设计参数",
                    "content": json.dumps(all_results.get("initial_design", {}), indent=2, ensure_ascii=False)
                },
                {
                    "title": "三、分析结果",
                    "content": json.dumps(all_results.get("analysis_results", {}), indent=2, ensure_ascii=False)
                },
                {
                    "title": "四、优化结果",
                    "content": json.dumps(all_results.get("optimized_design", {}), indent=2, ensure_ascii=False)
                },
                {
                    "title": "五、校核结论",
                    "content": json.dumps(all_results.get("final_verification", {}), indent=2, ensure_ascii=False)
                }
            ],
            "conclusion": "设计满足规范要求，可以用于工程实践。"
        }

        return report

    def receive_message(self, message):
        """接收消息"""
        print(f"  [KnowledgeAgent] 收到消息: {message.message_type}")
