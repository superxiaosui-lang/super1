"""
设计Agent - 负责节点参数化设计和构造细节设计
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import numpy as np


class DesignAgent:
    """设计Agent - 节点设计与参数生成"""

    def __init__(self):
        self.design_history: List[Dict[str, Any]] = []

    def generate_initial_design(self, geometry,
                               seismic_params,
                               code_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """生成初始设计"""
        print(f"  [DesignAgent] 生成初始设计")

        # 提取输入参数
        if isinstance(geometry, dict):
            beam_height = geometry.get("beam_height_section", 500)
            beam_width = geometry.get("beam_width_section", 200)
            column_height = geometry.get("column_height_section", 400)
            column_width = geometry.get("column_width_section", 400)
        else:
            # NodeGeometry对象
            beam_height = geometry.beam.height if hasattr(geometry, 'beam') else 500
            beam_width = geometry.beam.width if hasattr(geometry, 'beam') else 200
            column_height = geometry.column.height if hasattr(geometry, 'column') else 400
            column_width = geometry.column.width if hasattr(geometry, 'column') else 400

        if isinstance(seismic_params, dict):
            intensity = seismic_params.get("intensity", 7)
        else:
            intensity = seismic_params.intensity.value if hasattr(seismic_params, 'intensity') else 7

        # 设计螺栓连接
        bolt_design = self._design_bolt_connection(
            beam_height, beam_width, intensity, code_requirements
        )

        # 设计端板
        end_plate_design = self._design_end_plate(
            beam_height, beam_width, bolt_design, intensity, code_requirements
        )

        # 设计加劲肋
        stiffener_design = self._design_stiffeners(
            beam_height, beam_width, column_height, column_width, intensity
        )

        # 设计焊缝
        weld_design = self._design_welds(
            beam_height, beam_width, bolt_design, end_plate_design
        )

        # 汇总设计
        design = {
            "bolt_connection": bolt_design,
            "end_plate": end_plate_design,
            "stiffeners": stiffener_design,
            "welds": weld_design,
            "design_parameters": self._compile_design_parameters(
                bolt_design, end_plate_design, stiffener_design, weld_design
            ),
            "design_summary": self._generate_design_summary(
                bolt_design, end_plate_design, stiffener_design, weld_design
            )
        }

        self.design_history.append({
            "type": "initial_design",
            "design": design["design_summary"]
        })

        return design

    def _design_bolt_connection(self, beam_height: float, beam_width: float,
                               intensity: int,
                               code_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """设计螺栓连接"""
        # 确定螺栓直径
        if beam_height <= 400:
            bolt_diameter = 20
        elif beam_height <= 600:
            bolt_diameter = 22
        else:
            bolt_diameter = 24

        # 确定螺栓等级
        if intensity >= 8:
            bolt_grade = "10.9S"
        else:
            bolt_grade = "8.8S"

        # 计算螺栓数量
        # 翼缘螺栓
        flange_bolts_x = 2
        flange_bolts_y = max(2, int(beam_width / 100))

        # 腹板螺栓
        web_bolts_x = 2
        web_bolts_y = max(2, int((beam_height - 2 * 16) / 100))

        # 计算螺栓间距
        bolt_spacing_x = beam_width / (flange_bolts_x + 1)
        bolt_spacing_y = beam_height / (flange_bolts_y + web_bolts_y + 2)

        # 边距
        edge_distance = max(1.5 * bolt_diameter, 30)

        # 预拉力
        if bolt_grade == "10.9S":
            if bolt_diameter == 20:
                initial_tension = 155
            elif bolt_diameter == 22:
                initial_tension = 190
            else:
                initial_tension = 225
        else:
            if bolt_diameter == 20:
                initial_tension = 110
            elif bolt_diameter == 22:
                initial_tension = 135
            else:
                initial_tension = 155

        return {
            "bolt_diameter": bolt_diameter,
            "bolt_grade": bolt_grade,
            "flange_bolts": {
                "number_x": flange_bolts_x,
                "number_y": flange_bolts_y,
                "total": flange_bolts_x * flange_bolts_y
            },
            "web_bolts": {
                "number_x": web_bolts_x,
                "number_y": web_bolts_y,
                "total": web_bolts_x * web_bolts_y
            },
            "total_bolts": flange_bolts_x * flange_bolts_y + web_bolts_x * web_bolts_y,
            "spacing": {
                "x": bolt_spacing_x,
                "y": bolt_spacing_y
            },
            "edge_distance": edge_distance,
            "initial_tension": initial_tension,
            "friction_coefficient": 0.45 if bolt_grade == "10.9S" else 0.35
        }

    def _design_end_plate(self, beam_height: float, beam_width: float,
                         bolt_design: Dict[str, Any], intensity: int,
                         code_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """设计端板"""
        # 端板高度
        end_plate_height = beam_height + 2 * bolt_design["edge_distance"]

        # 端板宽度
        end_plate_width = beam_width

        # 端板厚度
        bolt_diameter = bolt_design["bolt_diameter"]
        flange_bolts_y = bolt_design["flange_bolts"]["number_y"]

        # 基于强度和刚度要求计算
        # 简化计算：基于梁翼缘厚度
        beam_flange_thickness = 16  # 假设值
        if intensity <= 7:
            end_plate_thickness = max(20, beam_flange_thickness + 4)
        elif intensity == 8:
            end_plate_thickness = max(25, beam_flange_thickness + 8)
        else:
            end_plate_thickness = max(30, beam_flange_thickness + 12)

        # 端板屈服强度
        end_plate_fy = 345

        # 计算端板截面特性
        I_plate = end_plate_width * end_plate_thickness**3 / 12
        W_plate = I_plate / (end_plate_thickness / 2)

        return {
            "height": end_plate_height,
            "width": end_plate_width,
            "thickness": end_plate_thickness,
            "steel_grade": "Q345B",
            "yield_strength": end_plate_fy,
            "section_properties": {
                "moment_of_inertia": I_plate,
                "section_modulus": W_plate,
            },
            "stiffener_required": beam_height > 500 or intensity >= 8,
            "extended_length": max(0, end_plate_height - beam_height) / 2
        }

    def _design_stiffeners(self, beam_height: float, beam_width: float,
                          column_height: float, column_width: float,
                          intensity: int) -> Dict[str, Any]:
        """设计加劲肋"""
        need_stiffener = beam_height > 500 or intensity >= 8

        if not need_stiffener:
            return {
                "required": False,
                "description": "根据设计要求，可不设置加劲肋"
            }

        # 加劲肋厚度
        beam_flange_thickness = 16
        stiffener_thickness = max(12, beam_flange_thickness)

        # 加劲肋宽度
        stiffener_width = column_width / 2 - 10

        # 加劲肋高度
        stiffener_height = beam_height - 2 * beam_flange_thickness

        return {
            "required": True,
            "positions": ["梁上翼缘对应位置", "梁下翼缘对应位置"],
            "thickness": stiffener_thickness,
            "width": stiffener_width,
            "height": stiffener_height,
            "steel_grade": "Q345B",
            "weld_to_column_web": True,
            "weld_to_flange": True
        }

    def _design_welds(self, beam_height: float, beam_width: float,
                     bolt_design: Dict[str, Any],
                     end_plate_design: Dict[str, Any]) -> Dict[str, Any]:
        """设计焊缝"""
        # 翼缘对接焊缝
        beam_flange_thickness = 16
        flange_weld = {
            "type": "全熔透坡口焊缝",
            "position": "梁翼缘与端板连接",
            "weld_size": beam_flange_thickness,
            "quality_grade": "一级",
            "inspection": "100%超声波探伤"
        }

        # 腹板角焊缝
        beam_web_thickness = 10
        web_weld = {
            "type": "角焊缝",
            "position": "梁腹板与端板连接",
            "weld_size": max(6, int(beam_web_thickness * 0.7)),
            "weld_length": beam_height - 2 * beam_flange_thickness,
            "quality_grade": "二级"
        }

        # 加劲肋焊缝
        stiffener_weld = None
        if end_plate_design.get("stiffener_required"):
            stiffener_weld = {
                "type": "角焊缝",
                "position": "加劲肋与端板连接",
                "weld_size": 8,
                "quality_grade": "二级"
            }

        return {
            "flange_weld": flange_weld,
            "web_weld": web_weld,
            "stiffener_weld": stiffener_weld,
            "total_weld_length": self._calculate_total_weld_length(
                beam_height, beam_width, stiffener_weld
            )
        }

    def _calculate_total_weld_length(self, beam_height: float, beam_width: float,
                                    stiffener_weld: Optional[Dict]) -> float:
        """计算总焊缝长度"""
        # 翼缘焊缝：上下两条
        flange_weld_length = 2 * beam_width

        # 腹板焊缝：两侧
        web_weld_length = 2 * (beam_height - 32)

        total = flange_weld_length + web_weld_length

        if stiffener_weld:
            # 加劲肋焊缝
            stiffener_length = 4 * 100  # 假设4条100mm长焊缝
            total += stiffener_length

        return total

    def _compile_design_parameters(self, bolt_design: Dict[str, Any],
                                  end_plate_design: Dict[str, Any],
                                  stiffener_design: Dict[str, Any],
                                  weld_design: Dict[str, Any]) -> Dict[str, Any]:
        """编译设计参数"""
        return {
            "bolt_diameter": bolt_design["bolt_diameter"],
            "bolt_grade": bolt_design["bolt_grade"],
            "bolt_number": bolt_design["total_bolts"],
            "bolt_spacing_x": bolt_design["spacing"]["x"],
            "bolt_spacing_y": bolt_design["spacing"]["y"],
            "bolt_edge_distance": bolt_design["edge_distance"],
            "end_plate_thickness": end_plate_design["thickness"],
            "end_plate_width": end_plate_design["width"],
            "end_plate_height": end_plate_design["height"],
            "end_plate_yield_strength": end_plate_design["yield_strength"],
            "stiffener_thickness": stiffener_design.get("thickness", 0),
            "stiffener_width": stiffener_design.get("width", 0),
            "stiffener_required": stiffener_design.get("required", False),
            "weld_size_flange": weld_design["flange_weld"]["weld_size"],
            "weld_size_web": weld_design["web_weld"]["weld_size"],
        }

    def _generate_design_summary(self, bolt_design: Dict[str, Any],
                                end_plate_design: Dict[str, Any],
                                stiffener_design: Dict[str, Any],
                                weld_design: Dict[str, Any]) -> str:
        """生成设计摘要"""
        summary = f"螺栓连接: {bolt_design['bolt_grade']}级M{bolt_design['bolt_diameter']}螺栓，"
        summary += f"共{bolt_design['total_bolts']}个\n"
        summary += f"端板: {end_plate_design['thickness']}mm厚，"
        summary += f"{end_plate_design['width']}x{end_plate_design['height']}mm\n"

        if stiffener_design.get("required"):
            summary += f"加劲肋: {stiffener_design['thickness']}mm厚，"
            summary += f"设置于梁翼缘对应位置\n"
        else:
            summary += "加劲肋: 无需设置\n"

        summary += f"焊缝: 翼缘采用{weld_design['flange_weld']['type']}，"
        summary += f"腹板采用{weld_design['web_weld']['type']}\n"

        return summary

    def receive_message(self, message):
        """接收消息"""
        print(f"  [DesignAgent] 收到消息: {message.message_type}")
