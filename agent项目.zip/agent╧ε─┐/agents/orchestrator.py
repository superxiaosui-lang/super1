"""
主控Agent - 负责任务分解、调度和多Agent协作管理
实现基于LangGraph的长链推理流程
"""

import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, field
from enum import Enum
import json

from models.data_models import (
    DesignTask, AnalysisResult, OptimizationResult,
    NodeGeometry, SeismicDesignParams, LoadCase, LoadCombination
)


class TaskStatus(str, Enum):
    """任务状态"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class AgentType(str, Enum):
    """Agent类型"""
    KNOWLEDGE = "knowledge_agent"
    ANALYSIS = "analysis_agent"
    DESIGN = "design_agent"
    OPTIMIZATION = "optimization_agent"
    VERIFICATION = "verification_agent"


@dataclass
class AgentMessage:
    """Agent间通信消息"""
    message_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    sender: AgentType = AgentType.KNOWLEDGE
    receiver: AgentType = AgentType.KNOWLEDGE
    content: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    message_type: str = "request"  # request, response, notification
    priority: int = 0


@dataclass
class ExecutionStep:
    """执行步骤"""
    step_id: int
    agent_type: AgentType
    action: str
    input_data: Dict[str, Any]
    output_data: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    dependencies: List[int] = field(default_factory=list)


class OrchestratorAgent:
    """主控Agent - 协调多Agent完成抗震节点设计任务"""

    def __init__(self):
        self.agents: Dict[AgentType, Any] = {}
        self.message_queue: List[AgentMessage] = []
        self.execution_plan: List[ExecutionStep] = []
        self.context: Dict[str, Any] = {}
        self.current_task: Optional[DesignTask] = None
        self.execution_history: List[Dict[str, Any]] = []

    def register_agent(self, agent_type: AgentType, agent_instance: Any):
        """注册Agent"""
        self.agents[agent_type] = agent_instance
        print(f"[Orchestrator] 注册Agent: {agent_type.value}")

    def create_execution_plan(self, task: DesignTask) -> List[ExecutionStep]:
        """创建执行计划"""
        self.current_task = task
        steps = []

        # 步骤1: 知识查询
        steps.append(ExecutionStep(
            step_id=1,
            agent_type=AgentType.KNOWLEDGE,
            action="query_code_requirements",
            input_data={
                "connection_type": task.geometry.connection_type.value,
                "seismic_intensity": task.seismic_params.intensity.value,
                "site_class": task.seismic_params.site_class.value
            },
            dependencies=[]
        ))

        # 步骤2: 初始设计
        steps.append(ExecutionStep(
            step_id=2,
            agent_type=AgentType.DESIGN,
            action="generate_initial_design",
            input_data={
                "geometry": task.geometry,
                "seismic_params": task.seismic_params,
                "code_requirements": {}  # 将从步骤1获取
            },
            dependencies=[1]
        ))

        # 步骤3: 结构分析
        steps.append(ExecutionStep(
            step_id=3,
            agent_type=AgentType.ANALYSIS,
            action="perform_analysis",
            input_data={
                "geometry": task.geometry,
                "design_params": {},  # 将从步骤2获取
                "load_cases": task.load_cases,
                "seismic_params": task.seismic_params
            },
            dependencies=[2]
        ))

        # 步骤4: 规范校核
        steps.append(ExecutionStep(
            step_id=4,
            agent_type=AgentType.VERIFICATION,
            action="verify_design",
            input_data={
                "geometry": task.geometry,
                "analysis_results": {},  # 将从步骤3获取
                "code_requirements": {}  # 将从步骤1获取
            },
            dependencies=[1, 3]
        ))

        # 步骤5: 多目标优化
        steps.append(ExecutionStep(
            step_id=5,
            agent_type=AgentType.OPTIMIZATION,
            action="optimize_design",
            input_data={
                "geometry": task.geometry,
                "analysis_results": {},  # 将从步骤3获取
                "verification_results": {},  # 将从步骤4获取
                "targets": task.optimization_targets
            },
            dependencies=[3, 4]
        ))

        # 步骤6: 优化后分析验证
        steps.append(ExecutionStep(
            step_id=6,
            agent_type=AgentType.ANALYSIS,
            action="verify_optimized_design",
            input_data={
                "optimized_params": {},  # 将从步骤5获取
                "seismic_params": task.seismic_params
            },
            dependencies=[5]
        ))

        # 步骤7: 最终校核
        steps.append(ExecutionStep(
            step_id=7,
            agent_type=AgentType.VERIFICATION,
            action="final_verification",
            input_data={
                "final_design": {},  # 将从步骤5获取
                "analysis_results": {}  # 将从步骤6获取
            },
            dependencies=[5, 6]
        ))

        # 步骤8: 生成报告
        steps.append(ExecutionStep(
            step_id=8,
            agent_type=AgentType.KNOWLEDGE,
            action="generate_report",
            input_data={
                "task": task,
                "all_results": {}  # 将收集所有结果
            },
            dependencies=[7]
        ))

        self.execution_plan = steps
        return steps

    def execute_plan(self, verbose: bool = True) -> DesignTask:
        """执行计划"""
        if not self.execution_plan:
            raise ValueError("执行计划为空，请先调用create_execution_plan")

        if verbose:
            print("=" * 70)
            print("开始执行抗震节点设计任务")
            print("=" * 70)
            print(f"任务ID: {self.current_task.task_id}")
            print(f"任务名称: {self.current_task.name}")
            print(f"执行步骤数: {len(self.execution_plan)}")
            print("=" * 70)

        start_time = datetime.now()

        # 按依赖关系排序执行
        executed_steps = set()
        max_iterations = 100  # 防止无限循环
        iteration = 0

        while len(executed_steps) < len(self.execution_plan) and iteration < max_iterations:
            iteration += 1

            for step in self.execution_plan:
                if step.step_id in executed_steps:
                    continue

                # 检查依赖是否满足
                dependencies_met = all(
                    dep in executed_steps
                    for dep in step.dependencies
                )

                if dependencies_met:
                    # 准备输入数据
                    self._prepare_step_input(step, executed_steps)

                    # 执行步骤
                    self._execute_step(step, verbose)

                    # 保存输出数据到上下文
                    self._save_step_output(step)

                    executed_steps.add(step.step_id)

        end_time = datetime.now()
        self.current_task.total_time = (end_time - start_time).total_seconds()

        if verbose:
            print("\n" + "=" * 70)
            print("任务执行完成")
            print(f"总耗时: {self.current_task.total_time:.2f}秒")
            print("=" * 70)

        # 生成最终报告
        self._generate_final_report()

        return self.current_task

    def _prepare_step_input(self, step: ExecutionStep, executed_steps: set):
        """准备步骤输入数据"""
        # 从上下文中获取前序步骤的输出
        if step.step_id == 2:  # 初始设计需要知识查询结果
            if "code_requirements" in self.context:
                step.input_data["code_requirements"] = self.context["code_requirements"]

        elif step.step_id == 3:  # 结构分析需要设计结果
            if "initial_design" in self.context:
                step.input_data["design_params"] = self.context["initial_design"]

        elif step.step_id == 4:  # 规范校核需要分析结果
            if "analysis_results" in self.context:
                step.input_data["analysis_results"] = self.context["analysis_results"]

        elif step.step_id == 5:  # 优化需要分析和校核结果
            if "analysis_results" in self.context:
                step.input_data["analysis_results"] = self.context["analysis_results"]
            if "verification_results" in self.context:
                step.input_data["verification_results"] = self.context["verification_results"]

        elif step.step_id == 6:  # 优化后分析
            if "optimized_design" in self.context:
                step.input_data["optimized_params"] = self.context["optimized_design"]

        elif step.step_id == 7:  # 最终校核
            if "optimized_design" in self.context:
                step.input_data["final_design"] = self.context["optimized_design"]
            if "optimized_analysis" in self.context:
                step.input_data["analysis_results"] = self.context["optimized_analysis"]

        elif step.step_id == 8:  # 生成报告
            step.input_data["all_results"] = self.context

    def _execute_step(self, step: ExecutionStep, verbose: bool):
        """执行单个步骤"""
        if verbose:
            print(f"\n[步骤 {step.step_id}] 执行 {step.agent_type.value} - {step.action}")
            print(f"  依赖步骤: {step.dependencies}")

        step.status = TaskStatus.IN_PROGRESS
        step.start_time = datetime.now()

        try:
            # 获取对应的Agent
            agent = self.agents.get(step.agent_type)
            if agent is None:
                raise ValueError(f"Agent {step.agent_type.value} 未注册")

            # 根据动作调用相应方法
            result = self._call_agent_action(agent, step)

            step.output_data = result
            step.status = TaskStatus.COMPLETED
            step.end_time = datetime.now()

            if verbose:
                print(f"  状态: 完成")
                print(f"  耗时: {(step.end_time - step.start_time).total_seconds():.2f}秒")

            # 记录执行历史
            self.execution_history.append({
                "step_id": step.step_id,
                "agent": step.agent_type.value,
                "action": step.action,
                "status": "completed",
                "duration": (step.end_time - step.start_time).total_seconds()
            })

        except Exception as e:
            step.status = TaskStatus.FAILED
            step.end_time = datetime.now()
            if verbose:
                print(f"  状态: 失败 - {str(e)}")

            self.execution_history.append({
                "step_id": step.step_id,
                "agent": step.agent_type.value,
                "action": step.action,
                "status": "failed",
                "error": str(e)
            })

    def _call_agent_action(self, agent: Any, step: ExecutionStep) -> Dict[str, Any]:
        """调用Agent动作"""
        # 获取Agent的所有方法
        available_methods = [method for method in dir(agent) if not method.startswith('_')]

        if step.action not in available_methods:
            raise ValueError(f"Agent {step.agent_type.value} 没有动作 {step.action}")

        action_func = getattr(agent, step.action)
        return action_func(**step.input_data)

    def _save_step_output(self, step: ExecutionStep):
        """保存步骤输出到上下文"""
        if step.step_id == 1:
            self.context["code_requirements"] = step.output_data
        elif step.step_id == 2:
            self.context["initial_design"] = step.output_data
        elif step.step_id == 3:
            self.context["analysis_results"] = step.output_data
        elif step.step_id == 4:
            self.context["verification_results"] = step.output_data
        elif step.step_id == 5:
            self.context["optimized_design"] = step.output_data
        elif step.step_id == 6:
            self.context["optimized_analysis"] = step.output_data
        elif step.step_id == 7:
            self.context["final_verification"] = step.output_data
        elif step.step_id == 8:
            self.context["final_report"] = step.output_data

    def _generate_final_report(self):
        """生成最终报告"""
        self.current_task.agent_logs = self.execution_history

    def get_execution_summary(self) -> Dict[str, Any]:
        """获取执行摘要"""
        completed = sum(1 for step in self.execution_plan
                       if step.status == TaskStatus.COMPLETED)
        failed = sum(1 for step in self.execution_plan
                    if step.status == TaskStatus.FAILED)

        return {
            "task_id": self.current_task.task_id if self.current_task else None,
            "total_steps": len(self.execution_plan),
            "completed_steps": completed,
            "failed_steps": failed,
            "success_rate": completed / len(self.execution_plan) if self.execution_plan else 0,
            "total_time": self.current_task.total_time if self.current_task else 0,
            "execution_history": self.execution_history
        }

    def send_message(self, message: AgentMessage):
        """发送Agent间消息"""
        self.message_queue.append(message)

    def process_messages(self):
        """处理消息队列"""
        while self.message_queue:
            message = self.message_queue.pop(0)
            receiver_agent = self.agents.get(message.receiver)
            if receiver_agent:
                receiver_agent.receive_message(message)

    def reset(self):
        """重置状态"""
        self.execution_plan.clear()
        self.context.clear()
        self.message_queue.clear()
        self.execution_history.clear()
