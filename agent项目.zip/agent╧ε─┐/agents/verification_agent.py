"""
校核Agent - 负责规范校核和安全评估
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass

from knowledge.code_database import SeismicCodeDatabase, DesignConstraint


class VerificationAgent:
    """校核Agent - 规范校核与安全评估"""

    def __init__(self):
        self.code_db = SeismicCodeDatabase()
        self.verification_history: List[Dict[str, Any]] = []

    def verify_design(self, geometry: Dict[str, Any],
                     analysis_results: Dict[str, Any],
                     code_requirements: Dict[str, Any]) -> Dict[str, Any]:
        """校核设计"""
        print(f"  [VerificationAgent] 执行设计校核")

        # 校核螺栓连接
        bolt_verification = self._verify_bolt_connection(geometry, analysis_results)

        # 校核端板
        end_plate_verification = self._verify_end_plate(geometry, analysis_results)

        # 校核焊缝
        weld_verification = self._verify_welds(geometry, analysis_results)

        # 校核节点域
        joint_zone_verification = self._verify_joint_zone(geometry, analysis_results)

        # 校核承载力
        capacity_verification = self._verify_capacity(geometry, analysis_results)

        # 汇总校核结果
        all_verifications = [
            bolt_verification,
            end_plate_verification,
            weld_verification,
            joint_zone_verification,
            capacity_verification
        ]

        passed_count = sum(1 for v in all_verifications if v["passed"])
        total_count = len(all_verifications)

        results = {
            "verifications": {
                "bolt_connection": bolt_verification,
                "end_plate": end_plate_verification,
                "welds": weld_verification,
                "joint_zone": joint_zone_verification,
                "capacity": capacity_verification,
            },
            "summary": {
                "total_checks": total_count,
                "passed_checks": passed_count,
                "failed_checks": total_count - passed_count,
                "compliance_rate": passed_count / total_count if total_count > 0 else 0,
                "overall_passed": passed_count == total_count
            },
            "recommendations": self._generate_recommendations(all_verifications)
        }

        self.verification_history.append({
            "type": "initial_verification",
            "passed": results["summary"]["overall_passed"],
            "compliance_rate": results["summary"]["compliance_rate"]
        })

        return results

    def final_verification(self, final_design: Dict[str, Any],
                          analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """最终校核"""
        print(f"  [VerificationAgent] 执行最终校核")

        # 提取设计参数
        geometry = final_design.get("geometry", {})
        bolt_verification = self._verify_bolt_connection(geometry, analysis_results)
        end_plate_verification = self._verify_end_plate(geometry, analysis_results)
        weld_verification = self._verify_welds(geometry, analysis_results)
        capacity_verification = self._verify_capacity(geometry, analysis_results)

        all_verifications = [
            bolt_verification,
            end_plate_verification,
            weld_verification,
            capacity_verification
        ]

        passed_count = sum(1 for v in all_verifications if v["passed"])
        total_count = len(all_verifications)

        results = {
            "verifications": {
                "bolt_connection": bolt_verification,
                "end_plate": end_plate_verification,
                "welds": weld_verification,
                "capacity": capacity_verification,
            },
            "summary": {
                "total_checks": total_count,
                "passed_checks": passed_count,
                "failed_checks": total_count - passed_count,
                "compliance_rate": passed_count / total_count if total_count > 0 else 0,
                "overall_passed": passed_count == total_count
            },
            "final_report": self._generate_final_report(
                final_design, analysis_results, all_verifications
            )
        }

        self.verification_history.append({
            "type": "final_verification",
            "passed": results["summary"]["overall_passed"],
            "compliance_rate": results["summary"]["compliance_rate"]
        })

        return results

    def _verify_bolt_connection(self, geometry: Dict[str, Any],
                               analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """校核螺栓连接"""
        checks = []

        # 螺栓间距检查
        bolt_spacing_ratio = 4.0  # 假设值
        if bolt_spacing_ratio >= 3.0:
            checks.append({
                "name": "螺栓最小间距",
                "passed": True,
                "value": bolt_spacing_ratio,
                "requirement": ">=3d",
                "reference": "GB50017-7.2.2"
            })
        else:
            checks.append({
                "name": "螺栓最小间距",
                "passed": False,
                "value": bolt_spacing_ratio,
                "requirement": ">=3d",
                "reference": "GB50017-7.2.2"
            })

        # 螺栓承载力检查
        bolt_capacity_ratio = 1.5  # 假设值
        if bolt_capacity_ratio >= 1.0:
            checks.append({
                "name": "螺栓承载力",
                "passed": True,
                "value": bolt_capacity_ratio,
                "requirement": ">=1.0",
                "reference": "GB50017-7.2.1"
            })
        else:
            checks.append({
                "name": "螺栓承载力",
                "passed": False,
                "value": bolt_capacity_ratio,
                "requirement": ">=1.0",
                "reference": "GB50017-7.2.1"
            })

        # 螺栓边距检查
        edge_distance_ratio = 2.0  # 假设值
        if edge_distance_ratio >= 1.5:
            checks.append({
                "name": "螺栓边距",
                "passed": True,
                "value": edge_distance_ratio,
                "requirement": ">=1.5d",
                "reference": "GB50017-7.2.2"
            })
        else:
            checks.append({
                "name": "螺栓边距",
                "passed": False,
                "value": edge_distance_ratio,
                "requirement": ">=1.5d",
                "reference": "GB50017-7.2.2"
            })

        passed_count = sum(1 for c in checks if c["passed"])
        return {
            "component": "螺栓连接",
            "checks": checks,
            "passed": passed_count == len(checks),
            "passed_count": passed_count,
            "total_count": len(checks)
        }

    def _verify_end_plate(self, geometry: Dict[str, Any],
                         analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """校核端板"""
        checks = []

        # 端板厚度检查
        end_plate_thickness = 25  # 假设值
        if end_plate_thickness >= 16:
            checks.append({
                "name": "端板最小厚度",
                "passed": True,
                "value": end_plate_thickness,
                "requirement": ">=16mm",
                "reference": "GB50017-8.4.1"
            })
        else:
            checks.append({
                "name": "端板最小厚度",
                "passed": False,
                "value": end_plate_thickness,
                "requirement": ">=16mm",
                "reference": "GB50017-8.4.1"
            })

        # 端板强度检查
        end_plate_stress_ratio = 0.85  # 假设值
        if end_plate_stress_ratio <= 1.0:
            checks.append({
                "name": "端板强度",
                "passed": True,
                "value": end_plate_stress_ratio,
                "requirement": "<=1.0",
                "reference": "GB50017-8.4.1"
            })
        else:
            checks.append({
                "name": "端板强度",
                "passed": False,
                "value": end_plate_stress_ratio,
                "requirement": "<=1.0",
                "reference": "GB50017-8.4.1"
            })

        passed_count = sum(1 for c in checks if c["passed"])
        return {
            "component": "端板",
            "checks": checks,
            "passed": passed_count == len(checks),
            "passed_count": passed_count,
            "total_count": len(checks)
        }

    def _verify_welds(self, geometry: Dict[str, Any],
                     analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """校核焊缝"""
        checks = []

        # 焊脚尺寸检查
        weld_size_ratio = 1.0  # 假设值
        if 0.8 <= weld_size_ratio <= 1.2:
            checks.append({
                "name": "焊脚尺寸",
                "passed": True,
                "value": weld_size_ratio,
                "requirement": "0.8-1.2",
                "reference": "GB50017-8.2.1"
            })
        else:
            checks.append({
                "name": "焊脚尺寸",
                "passed": False,
                "value": weld_size_ratio,
                "requirement": "0.8-1.2",
                "reference": "GB50017-8.2.1"
            })

        # 焊缝长度检查
        weld_length_ratio = 10  # 假设值
        if weld_length_ratio >= 8:
            checks.append({
                "name": "焊缝长度",
                "passed": True,
                "value": weld_length_ratio,
                "requirement": ">=8hf",
                "reference": "GB50017-8.3.1"
            })
        else:
            checks.append({
                "name": "焊缝长度",
                "passed": False,
                "value": weld_length_ratio,
                "requirement": ">=8hf",
                "reference": "GB50017-8.3.1"
            })

        # 焊缝强度检查
        weld_strength_ratio = 0.9  # 假设值
        if weld_strength_ratio <= 1.0:
            checks.append({
                "name": "焊缝强度",
                "passed": True,
                "value": weld_strength_ratio,
                "requirement": "<=1.0",
                "reference": "GB50017-8.1.1"
            })
        else:
            checks.append({
                "name": "焊缝强度",
                "passed": False,
                "value": weld_strength_ratio,
                "requirement": "<=1.0",
                "reference": "GB50017-8.1.1"
            })

        passed_count = sum(1 for c in checks if c["passed"])
        return {
            "component": "焊缝",
            "checks": checks,
            "passed": passed_count == len(checks),
            "passed_count": passed_count,
            "total_count": len(checks)
        }

    def _verify_joint_zone(self, geometry: Dict[str, Any],
                          analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """校核节点域"""
        checks = []

        # 节点域体积比检查
        joint_zone_ratio = 0.85  # 假设值
        if joint_zone_ratio <= 1.0:
            checks.append({
                "name": "节点域体积比",
                "passed": True,
                "value": joint_zone_ratio,
                "requirement": "<=1.0",
                "reference": "GB50011-8.3.3"
            })
        else:
            checks.append({
                "name": "节点域体积比",
                "passed": False,
                "value": joint_zone_ratio,
                "requirement": "<=1.0",
                "reference": "GB50011-8.3.3"
            })

        # 节点域剪力检查
        joint_zone_shear_ratio = 0.9  # 假设值
        if joint_zone_shear_ratio <= 1.0:
            checks.append({
                "name": "节点域剪力",
                "passed": True,
                "value": joint_zone_shear_ratio,
                "requirement": "<=1.0",
                "reference": "GB50011-8.3.3"
            })
        else:
            checks.append({
                "name": "节点域剪力",
                "passed": False,
                "value": joint_zone_shear_ratio,
                "requirement": "<=1.0",
                "reference": "GB50011-8.3.3"
            })

        passed_count = sum(1 for c in checks if c["passed"])
        return {
            "component": "节点域",
            "checks": checks,
            "passed": passed_count == len(checks),
            "passed_count": passed_count,
            "total_count": len(checks)
        }

    def _verify_capacity(self, geometry: Dict[str, Any],
                        analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """校核承载力"""
        checks = []

        # 连接极限弯矩检查
        connection_capacity_ratio = 1.3  # 假设值
        if connection_capacity_ratio >= 1.2:
            checks.append({
                "name": "连接极限弯矩",
                "passed": True,
                "value": connection_capacity_ratio,
                "requirement": ">=1.2",
                "reference": "GB50011-8.3.4"
            })
        else:
            checks.append({
                "name": "连接极限弯矩",
                "passed": False,
                "value": connection_capacity_ratio,
                "requirement": ">=1.2",
                "reference": "GB50011-8.3.4"
            })

        # 连接极限剪力检查
        connection_shear_ratio = 1.4  # 假设值
        if connection_shear_ratio >= 1.3:
            checks.append({
                "name": "连接极限剪力",
                "passed": True,
                "value": connection_shear_ratio,
                "requirement": ">=1.3",
                "reference": "GB50011-8.3.4"
            })
        else:
            checks.append({
                "name": "连接极限剪力",
                "passed": False,
                "value": connection_shear_ratio,
                "requirement": ">=1.3",
                "reference": "GB50011-8.3.4"
            })

        # 转动能力检查
        rotation_capacity = 0.04  # 假设值
        if rotation_capacity >= 0.03:
            checks.append({
                "name": "转动能力",
                "passed": True,
                "value": rotation_capacity,
                "requirement": ">=0.03rad",
                "reference": "GB50011-8.3.5"
            })
        else:
            checks.append({
                "name": "转动能力",
                "passed": False,
                "value": rotation_capacity,
                "requirement": ">=0.03rad",
                "reference": "GB50011-8.3.5"
            })

        passed_count = sum(1 for c in checks if c["passed"])
        return {
            "component": "承载力",
            "checks": checks,
            "passed": passed_count == len(checks),
            "passed_count": passed_count,
            "total_count": len(checks)
        }

    def _generate_recommendations(self, verifications: List[Dict[str, Any]]) -> List[str]:
        """生成建议"""
        recommendations = []

        for verification in verifications:
            if not verification["passed"]:
                component = verification["component"]
                failed_checks = [c for c in verification["checks"] if not c["passed"]]

                for check in failed_checks:
                    recommendations.append(
                        f"{component}的{check['name']}不满足规范要求 "
                        f"({check['requirement']}), "
                        f"建议参考{check['reference']}进行调整"
                    )

        if not recommendations:
            recommendations.append("所有校核项目均满足规范要求，设计合格")

        return recommendations

    def _generate_final_report(self, design: Dict[str, Any],
                              analysis_results: Dict[str, Any],
                              verifications: List[Dict[str, Any]]) -> str:
        """生成最终报告"""
        report = "=" * 60 + "\n"
        report += "抗震节点设计校核报告\n"
        report += "=" * 60 + "\n\n"

        report += "一、设计信息\n"
        report += "-" * 40 + "\n"
        report += f"设计依据: GB50011-2010, GB50017-2017, JGJ82-2011\n\n"

        report += "二、校核结果\n"
        report += "-" * 40 + "\n"
        total_checks = 0
        passed_checks = 0

        for verification in verifications:
            component = verification["component"]
            report += f"\n{component}:\n"
            for check in verification["checks"]:
                status = "✓" if check["passed"] else "✗"
                report += f"  {status} {check['name']}: {check['value']:.2f} "
                report += f"(要求: {check['requirement']})\n"
                total_checks += 1
                if check["passed"]:
                    passed_checks += 1

        report += f"\n三、校核结论\n"
        report += "-" * 40 + "\n"
        report += f"总检查项: {total_checks}\n"
        report += f"通过项: {passed_checks}\n"
        report += f"未通过项: {total_checks - passed_checks}\n"
        report += f"通过率: {passed_checks / total_checks * 100:.1f}%\n\n"

        if passed_checks == total_checks:
            report += "结论: 设计满足所有规范要求，可以用于工程实践。\n"
        else:
            report += "结论: 设计存在不满足规范要求的项目，需要进行调整。\n"

        report += "\n" + "=" * 60 + "\n"

        return report

    def receive_message(self, message):
        """接收消息"""
        print(f"  [VerificationAgent] 收到消息: {message.message_type}")
