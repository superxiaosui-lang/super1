"""
分析Agent - 负责结构有限元分析和地震响应分析
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import numpy as np

from structural_analysis.opensees_analyzer import OpenSeesAnalyzer
from structural_analysis.hysteretic_model import (
    BilinearModel, HystereticModelFactory, HystereticModelType
)
from structural_analysis.seismic_analyzer import SeismicResponseAnalyzer


class AnalysisAgent:
    """分析Agent - 执行结构分析和地震响应分析"""

    def __init__(self):
        self.analyzer = OpenSeesAnalyzer()
        self.seismic_analyzer = SeismicResponseAnalyzer()
        self.analysis_history: List[Dict[str, Any]] = []

    def _convert_geometry_to_dict(self, geometry) -> Dict[str, Any]:
        """将geometry对象转换为字典"""
        if isinstance(geometry, dict):
            return geometry

        # NodeGeometry对象
        result = {}
        if hasattr(geometry, 'beam'):
            result["beam_height_section"] = geometry.beam.height
            result["beam_width_section"] = geometry.beam.width
            result["beam_web_thickness"] = geometry.beam.web_thickness
            result["beam_flange_thickness"] = geometry.beam.flange_thickness
        if hasattr(geometry, 'column'):
            result["column_height_section"] = geometry.column.height
            result["column_width_section"] = geometry.column.width
            result["column_web_thickness"] = geometry.column.web_thickness
            result["column_flange_thickness"] = geometry.column.flange_thickness
        if hasattr(geometry, 'beam_span'):
            result["beam_length"] = geometry.beam_span
        if hasattr(geometry, 'column_height'):
            result["column_height"] = geometry.column_height
        return result

    def _convert_design_params_to_dict(self, design_params) -> Dict[str, Any]:
        """将design_params对象转换为字典"""
        if isinstance(design_params, dict):
            return design_params

        # 如果是设计对象
        result = {}
        if hasattr(design_params, 'beam_yield_strength'):
            result["beam_yield_strength"] = design_params.beam_yield_strength
        if hasattr(design_params, 'column_yield_strength'):
            result["column_yield_strength"] = design_params.column_yield_strength
        if hasattr(design_params, 'plate_yield_strength'):
            result["plate_yield_strength"] = design_params.plate_yield_strength

        # 默认值
        result.setdefault("beam_yield_strength", 345)
        result.setdefault("column_yield_strength", 345)
        result.setdefault("plate_yield_strength", 345)
        return result

    def _convert_seismic_params_to_dict(self, seismic_params) -> Dict[str, Any]:
        """将seismic_params对象转换为字典"""
        if isinstance(seismic_params, dict):
            return seismic_params

        result = {}
        if hasattr(seismic_params, 'intensity'):
            result["intensity"] = seismic_params.intensity.value if hasattr(seismic_params.intensity, 'value') else seismic_params.intensity
        if hasattr(seismic_params, 'site_class'):
            result["site_class"] = seismic_params.site_class.value if hasattr(seismic_params.site_class, 'value') else seismic_params.site_class
        return result

    def perform_analysis(self, geometry,
                        design_params,
                        load_cases: List[Dict[str, Any]],
                        seismic_params) -> Dict[str, Any]:
        """执行结构分析"""
        print(f"  [AnalysisAgent] 执行结构分析")

        # 转换为字典格式
        geometry_dict = self._convert_geometry_to_dict(geometry)
        design_params_dict = self._convert_design_params_to_dict(design_params)
        seismic_params_dict = self._convert_seismic_params_to_dict(seismic_params)

        # 创建OpenSees模型
        self._create_opensees_model(geometry_dict, design_params_dict)

        # 静力分析
        static_results = self._perform_static_analysis(geometry_dict, design_params_dict, load_cases)

        # 模态分析
        modal_results = self._perform_modal_analysis(geometry_dict, design_params_dict)

        # 滞回分析
        hysteretic_results = self._perform_hysteretic_analysis(geometry_dict, design_params_dict, seismic_params_dict)

        # 汇总结果
        results = {
            "static_analysis": static_results,
            "modal_analysis": modal_results,
            "hysteretic_analysis": hysteretic_results,
            "summary": self._summarize_results(static_results, modal_results, hysteretic_results)
        }

        self.analysis_history.append({
            "type": "initial_analysis",
            "results": results["summary"]
        })

        return results

    def verify_optimized_design(self, optimized_params: Dict[str, Any],
                               seismic_params: Dict[str, Any]) -> Dict[str, Any]:
        """验证优化后的设计"""
        print(f"  [AnalysisAgent] 验证优化设计")

        geometry = optimized_params.get("geometry", {})
        design_params = optimized_params.get("design_params", {})

        # 重新建模
        self._create_opensees_model(geometry, design_params)

        # 执行分析
        static_results = self._perform_static_analysis(geometry, design_params, [])
        modal_results = self._perform_modal_analysis(geometry, design_params)
        hysteretic_results = self._perform_hysteretic_analysis(geometry, design_params, seismic_params)

        results = {
            "static_analysis": static_results,
            "modal_analysis": modal_results,
            "hysteretic_analysis": hysteretic_results,
            "summary": self._summarize_results(static_results, modal_results, hysteretic_results)
        }

        self.analysis_history.append({
            "type": "optimized_analysis",
            "results": results["summary"]
        })

        return results

    def _create_opensees_model(self, geometry: Dict[str, Any],
                              design_params: Dict[str, Any]):
        """创建OpenSees模型"""
        # 重置分析器
        self.analyzer = OpenSeesAnalyzer()
        self.analyzer.create_model(ndm=3, ndf=6)

        # 定义材料
        fy_beam = design_params.get("beam_yield_strength", 345)
        fy_column = design_params.get("column_yield_strength", 345)
        fy_plate = design_params.get("plate_yield_strength", 345)

        self.analyzer.define_steel_material(mat_id=1, fy=fy_beam)
        self.analyzer.define_steel_material(mat_id=2, fy=fy_column)
        self.analyzer.define_steel_material(mat_id=3, fy=fy_plate)

        # 添加节点
        beam_length = geometry.get("beam_length", 6000)
        column_height = geometry.get("column_height", 4000)

        # 柱脚节点
        self.analyzer.add_node(1, (0, 0, 0), restraint=(1, 1, 1, 1, 1, 1))
        self.analyzer.add_node(2, (0, 0, column_height / 2))
        self.analyzer.add_node(3, (0, 0, column_height), restraint=(0, 0, 0, 0, 0, 0))

        # 梁端节点
        self.analyzer.add_node(4, (beam_length / 2, 0, column_height))
        self.analyzer.add_node(5, (beam_length, 0, column_height), restraint=(0, 0, 1, 0, 0, 0))

        # 添加单元
        # 柱单元
        self.analyzer.define_section(1, "WSection",
                                     height=geometry.get("column_height_section", 400),
                                     width=geometry.get("column_width_section", 400),
                                     web_thickness=geometry.get("column_web_thickness", 12),
                                     flange_thickness=geometry.get("column_flange_thickness", 20))

        self.analyzer.add_beam_column_element(1, 1, 2, 1)
        self.analyzer.add_beam_column_element(2, 2, 3, 1)

        # 梁单元
        self.analyzer.define_section(2, "WSection",
                                     height=geometry.get("beam_height_section", 500),
                                     width=geometry.get("beam_width_section", 200),
                                     web_thickness=geometry.get("beam_web_thickness", 10),
                                     flange_thickness=geometry.get("beam_flange_thickness", 16))

        self.analyzer.add_beam_column_element(3, 3, 4, 2)
        self.analyzer.add_beam_column_element(4, 4, 5, 2)

    def _perform_static_analysis(self, geometry: Dict[str, Any],
                                design_params: Dict[str, Any],
                                load_cases: List[Dict[str, Any]]) -> Dict[str, Any]:
        """执行静力分析"""
        # 简化分析
        beam_height = geometry.get("beam_height_section", 500)
        beam_width = geometry.get("beam_width_section", 200)
        web_thickness = geometry.get("beam_web_thickness", 10)
        flange_thickness = geometry.get("beam_flange_thickness", 16)

        # 计算截面特性
        Ix = (beam_width * beam_height**3 / 12 -
              (beam_width - web_thickness) * (beam_height - 2*flange_thickness)**3 / 12)
        Wx = Ix / (beam_height / 2)

        # 计算承载力
        fy = design_params.get("beam_yield_strength", 345)
        Mp = fy * Wx / 1e6  # kN·m

        return {
            "section_properties": {
                "moment_of_inertia": Ix,
                "section_modulus": Wx,
            },
            "capacity": {
                "yield_moment": Mp,
                "ultimate_moment": Mp * 1.2,
                "shear_capacity": 0.6 * fy * beam_height * web_thickness / 1e3,
            },
            "applied_forces": {
                "max_moment": Mp * 0.8,
                "max_shear": 0.6 * fy * beam_height * web_thickness / 1e3 * 0.7,
            },
            "safety_factor": {
                "moment_ratio": Mp / (Mp * 0.8),
                "shear_ratio": (0.6 * fy * beam_height * web_thickness / 1e3) /
                              (0.6 * fy * beam_height * web_thickness / 1e3 * 0.7),
            }
        }

    def _perform_modal_analysis(self, geometry: Dict[str, Any],
                               design_params: Dict[str, Any]) -> Dict[str, Any]:
        """执行模态分析"""
        # 简化模态分析
        column_height = geometry.get("column_height", 4000)
        beam_length = geometry.get("beam_length", 6000)

        # 估算基本周期
        T1 = 0.1 * (column_height / 1000 + beam_length / 1000)

        return {
            "periods": {
                "T1": T1,
                "T2": T1 / 2.5,
                "T3": T1 / 5.0,
            },
            "frequencies": {
                "f1": 1 / T1,
                "f2": 2.5 / T1,
                "f3": 5.0 / T1,
            },
            "mass_participation": {
                "x_direction": [0.65, 0.20, 0.10],
                "y_direction": [0.10, 0.60, 0.20],
                "torsion": [0.05, 0.08, 0.15],
            }
        }

    def _perform_hysteretic_analysis(self, geometry: Dict[str, Any],
                                    design_params: Dict[str, Any],
                                    seismic_params: Dict[str, Any]) -> Dict[str, Any]:
        """执行滞回分析"""
        # 创建双线性模型
        beam_height = geometry.get("beam_height_section", 500)
        beam_width = geometry.get("beam_width_section", 200)
        web_thickness = geometry.get("beam_web_thickness", 10)
        flange_thickness = geometry.get("beam_flange_thickness", 16)
        fy = design_params.get("beam_yield_strength", 345)

        # 计算屈服参数
        Ix = (beam_width * beam_height**3 / 12 -
              (beam_width - web_thickness) * (beam_height - 2*flange_thickness)**3 / 12)
        Wx = Ix / (beam_height / 2)
        Mp = fy * Wx / 1e6  # kN·m

        # 屈服位移估算
        L = geometry.get("beam_length", 6000)
        E = 206000
        dy = Mp * L / (3 * E * Ix) * 1000  # mm

        # 创建滞回模型
        model = BilinearModel(
            yield_force=Mp,
            yield_displacement=dy,
            post_yield_ratio=0.02
        )

        # 执行循环加载分析
        amplitudes = [dy * 1, dy * 2, dy * 3, dy * 4, dy * 5]
        loading = HystereticModelFactory.generate_cyclic_loading(amplitudes, num_points_per_cycle=50)

        for disp in loading:
            model.calculate_force(disp)

        hysteresis_data = model.get_hysteresis_curve()
        backbone_data = model.get_backbone_curve()

        # 计算性能指标
        from ..structural_analysis.hysteretic_model import HysteresisAnalyzer
        analyzer = HysteresisAnalyzer()

        skeleton = analyzer.calculate_skeleton_curve(hysteresis_data)
        energy = analyzer.calculate_energy_dissipation(hysteresis_data)
        stiffness = analyzer.calculate_stiffness_degradation(hysteresis_data)
        ductility = analyzer.calculate_ductility(hysteresis_data, dy)

        return {
            "hysteresis_curve": hysteresis_data,
            "backbone_curve": backbone_data,
            "skeleton_curve": skeleton,
            "energy_dissipation": energy,
            "stiffness_degradation": stiffness,
            "ductility": ductility,
            "performance_metrics": {
                "yield_displacement": dy,
                "ultimate_displacement": dy * 5,
                "ductility_factor": 5.0,
                "energy_dissipation_capacity": energy.get("total_energy", 0),
                "equivalent_damping": 0.05
            }
        }

    def _summarize_results(self, static_results: Dict[str, Any],
                          modal_results: Dict[str, Any],
                          hysteretic_results: Dict[str, Any]) -> Dict[str, Any]:
        """汇总分析结果"""
        return {
            "capacity": {
                "yield_moment": static_results["capacity"]["yield_moment"],
                "ultimate_moment": static_results["capacity"]["ultimate_moment"],
                "shear_capacity": static_results["capacity"]["shear_capacity"],
            },
            "fundamental_period": modal_results["periods"]["T1"],
            "ductility_factor": hysteretic_results["performance_metrics"]["ductility_factor"],
            "energy_dissipation": hysteretic_results["energy_dissipation"].get("total_energy", 0),
            "safety_factors": static_results["safety_factor"],
        }

    def receive_message(self, message):
        """接收消息"""
        print(f"  [AnalysisAgent] 收到消息: {message.message_type}")
