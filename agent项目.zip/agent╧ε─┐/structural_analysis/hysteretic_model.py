"""
滞回模型模块 - 实现钢结构节点的滞回本构模型
支持多种滞回模型：双线性模型、Clough模型、武田模型等
"""

import numpy as np
from typing import List, Tuple, Optional, Dict, Any
from dataclasses import dataclass, field
from enum import Enum


class HystereticModelType(str, Enum):
    """滞回模型类型"""
    BILINEAR = "双线性模型"
    CLOUGH = "Clough模型"
    TAKEDA = "武田模型"
    GUEFFE = "Giuffré模型"
    MENEGOTTO = "Menegotto-Pinto模型"


@dataclass
class HystereticState:
    """滞回状态"""
    displacement: float = 0.0
    force: float = 0.0
    velocity: float = 0.0
    plastic_displacement: float = 0.0
    stiffness: float = 0.0
    energy: float = 0.0
    cycle_count: int = 0
    is_yielded: bool = False
    is_loaded: bool = True


class BilinearModel:
    """双线性滞回模型"""

    def __init__(self, yield_force: float, yield_displacement: float,
                 elastic_stiffness: Optional[float] = None,
                 post_yield_ratio: float = 0.02):
        """
        初始化双线性模型

        Args:
            yield_force: 屈服力
            yield_displacement: 屈服位移
            elastic_stiffness: 弹性刚度（可选，自动计算）
            post_yield_ratio: 屈服后刚度比
        """
        self.fy = yield_force
        self.dy = yield_displacement
        self.ke = elastic_stiffness if elastic_stiffness else yield_force / yield_displacement
        self.ks = self.ke * post_yield_ratio
        self.alpha = post_yield_ratio

        self.state = HystereticState()
        self.history: List[HystereticState] = []
        self.backbone_curve: List[Tuple[float, float]] = []

    def calculate_force(self, displacement: float) -> float:
        """根据位移计算力"""
        # 更新状态
        prev_state = self.state if self.history else HystereticState()

        # 判断加载方向
        if displacement > prev_state.displacement:
            is_loaded = True
        elif displacement < prev_state.displacement:
            is_loaded = False
        else:
            is_loaded = prev_state.is_loaded

        self.state.is_loaded = is_loaded
        self.state.displacement = displacement

        # 计算力
        if prev_state.is_yielded:
            # 已屈服
            if is_loaded:
                # 加载：沿屈服后刚度
                delta_d = displacement - prev_state.displacement
                self.state.force = prev_state.force + self.ks * delta_d
            else:
                # 卸载：沿弹性刚度
                delta_d = displacement - prev_state.displacement
                self.state.force = prev_state.force + self.ke * delta_d
        else:
            # 未屈服
            self.state.force = self.ke * displacement
            if abs(self.state.force) >= self.fy:
                self.state.is_yielded = True
                self.state.force = np.sign(displacement) * self.fy

        # 更新塑性位移
        if self.state.is_yielded:
            self.state.plastic_displacement = displacement - np.sign(self.state.force) * self.fy / self.ke
        else:
            self.state.plastic_displacement = 0.0

        # 更新刚度
        if self.state.is_yielded:
            self.state.stiffness = self.ks
        else:
            self.state.stiffness = self.ke

        # 更新能量（滞回耗能）
        if self.history:
            prev = self.history[-1]
            delta_energy = 0.5 * (self.state.force + prev.force) * (displacement - prev.displacement)
            self.state.energy = prev.energy + max(0, delta_energy)

        # 保存历史
        import copy
        self.history.append(copy.deepcopy(self.state))

        return self.state.force

    def get_hysteresis_curve(self) -> Dict[str, List[float]]:
        """获取滞回曲线"""
        return {
            "displacement": [s.displacement for s in self.history],
            "force": [s.force for s in self.history]
        }

    def get_backbone_curve(self) -> Dict[str, List[float]]:
        """获取骨架曲线"""
        # 生成骨架曲线点
        points = []
        # 弹性段
        points.append((0, 0))
        points.append((self.dy, self.fy))
        # 屈服后段
        max_disp = self.dy * 5
        for d in np.linspace(self.dy, max_disp, 50):
            f = self.fy + self.ks * (d - self.dy)
            points.append((d, f))

        return {
            "displacement": [p[0] for p in points],
            "force": [p[1] for p in points]
        }

    def calculate_energy_dissipation(self) -> float:
        """计算总滞回耗能"""
        if self.history:
            return self.history[-1].energy
        return 0.0

    def calculate_equivalent_damping(self, amplitude: float) -> float:
        """计算等效粘滞阻尼比"""
        force = self.calculate_force(amplitude)
        energy = self.calculate_energy_dissipation()
        strain_energy = 0.5 * force * amplitude

        if strain_energy > 0:
            zeta = energy / (4 * np.pi * strain_energy)
        else:
            zeta = 0.0

        return min(zeta, 0.5)  # 限制最大阻尼比

    def reset(self):
        """重置模型状态"""
        self.state = HystereticState()
        self.history = []


class CloughModel:
    """Clough退化刚度模型"""

    def __init__(self, yield_force: float, yield_displacement: float,
                 elastic_stiffness: Optional[float] = None,
                 post_yield_ratio: float = 0.02):
        self.fy = yield_force
        self.dy = yield_displacement
        self.ke = elastic_stiffness if elastic_stiffness else yield_force / yield_displacement
        self.ks = self.ke * post_yield_ratio

        self.state = HystereticState()
        self.history: List[HystereticState] = []
        self.max_displacement = 0.0
        self.max_force = 0.0

    def calculate_force(self, displacement: float) -> float:
        """根据位移计算力"""
        prev_state = self.state if self.history else HystereticState()

        # 更新最大位移
        self.max_displacement = max(self.max_displacement, abs(displacement))

        # 计算退化刚度
        if self.max_displacement > self.dy:
            degradation = self.dy / self.max_displacement
            ke_degraded = self.ke * degradation
        else:
            ke_degraded = self.ke

        # 判断加载方向
        if displacement > prev_state.displacement:
            is_loaded = True
        elif displacement < prev_state.displacement:
            is_loaded = False
        else:
            is_loaded = prev_state.is_loaded

        self.state.is_loaded = is_loaded
        self.state.displacement = displacement

        # 计算力
        if prev_state.is_yielded:
            if is_loaded:
                # 加载：指向当前骨架曲线
                peak_force = self.fy + self.ks * (self.max_displacement - self.dy)
                target_force = peak_force
                delta_d = displacement - prev_state.displacement
                self.state.force = prev_state.force + self.ks * delta_d
            else:
                # 卸载：指向反向屈服点
                delta_d = displacement - prev_state.displacement
                self.state.force = prev_state.force + ke_degraded * delta_d
        else:
            self.state.force = ke_degraded * displacement
            if abs(self.state.force) >= self.fy:
                self.state.is_yielded = True
                self.state.force = np.sign(displacement) * self.fy

        # 更新塑性位移
        if self.state.is_yielded:
            self.state.plastic_displacement = displacement - np.sign(self.state.force) * self.fy / ke_degraded
        else:
            self.state.plastic_displacement = 0.0

        # 更新能量
        if self.history:
            prev = self.history[-1]
            delta_energy = 0.5 * (self.state.force + prev.force) * (displacement - prev.displacement)
            self.state.energy = prev.energy + max(0, delta_energy)

        import copy
        self.history.append(copy.deepcopy(self.state))
        return self.state.force

    def get_hysteresis_curve(self) -> Dict[str, List[float]]:
        """获取滞回曲线"""
        return {
            "displacement": [s.displacement for s in self.history],
            "force": [s.force for s in self.history]
        }


class TakedaModel:
    """武田滞回模型"""

    def __init__(self, yield_force: float, yield_displacement: float,
                 elastic_stiffness: Optional[float] = None,
                 post_yield_ratio: float = 0.02,
                 alpha: float = 0.5):
        """
        初始化武田模型

        Args:
            alpha: 卸载刚度退化指数
        """
        self.fy = yield_force
        self.dy = yield_displacement
        self.ke = elastic_stiffness if elastic_stiffness else yield_force / yield_displacement
        self.ks = self.ke * post_yield_ratio
        self.alpha = alpha

        self.state = HystereticState()
        self.history: List[HystereticState] = []
        self.max_displacement = 0.0
        self.prev_peak_displacement = 0.0

    def calculate_force(self, displacement: float) -> float:
        """根据位移计算力"""
        prev_state = self.state if self.history else HystereticState()

        # 更新最大位移
        if abs(displacement) > self.max_displacement:
            self.prev_peak_displacement = self.max_displacement
            self.max_displacement = abs(displacement)

        # 计算卸载刚度
        if self.prev_peak_displacement > self.dy:
            ku = self.ke * (self.dy / self.prev_peak_displacement) ** self.alpha
        else:
            ku = self.ke

        # 判断加载方向
        if displacement > prev_state.displacement:
            is_loaded = True
        elif displacement < prev_state.displacement:
            is_loaded = False
        else:
            is_loaded = prev_state.is_loaded

        self.state.is_loaded = is_loaded
        self.state.displacement = displacement

        # 计算力
        if prev_state.is_yielded:
            if is_loaded:
                # 加载
                delta_d = displacement - prev_state.displacement
                self.state.force = prev_state.force + self.ks * delta_d
            else:
                # 卸载
                delta_d = displacement - prev_state.displacement
                self.state.force = prev_state.force + ku * delta_d
        else:
            self.state.force = self.ke * displacement
            if abs(self.state.force) >= self.fy:
                self.state.is_yielded = True
                self.state.force = np.sign(displacement) * self.fy

        # 更新能量
        if self.history:
            prev = self.history[-1]
            delta_energy = 0.5 * (self.state.force + prev.force) * (displacement - prev.displacement)
            self.state.energy = prev.energy + max(0, delta_energy)

        import copy
        self.history.append(copy.deepcopy(self.state))
        return self.state.force

    def get_hysteresis_curve(self) -> Dict[str, List[float]]:
        """获取滞回曲线"""
        return {
            "displacement": [s.displacement for s in self.history],
            "force": [s.force for s in self.history]
        }


class HystereticModelFactory:
    """滞回模型工厂"""

    @staticmethod
    def create_model(model_type: HystereticModelType, **kwargs):
        """创建滞回模型"""
        if model_type == HystereticModelType.BILINEAR:
            return BilinearModel(**kwargs)
        elif model_type == HystereticModelType.CLOUGH:
            return CloughModel(**kwargs)
        elif model_type == HystereticModelType.TAKEDA:
            return TakedaModel(**kwargs)
        else:
            raise ValueError(f"不支持的模型类型: {model_type}")

    @staticmethod
    def generate_cyclic_loading(amplitudes: List[float], num_points_per_cycle: int = 100) -> List[float]:
        """生成循环加载制度"""
        loading = []
        for amp in amplitudes:
            # 正向加载
            for d in np.linspace(0, amp, num_points_per_cycle):
                loading.append(d)
            # 正向卸载
            for d in np.linspace(amp, 0, num_points_per_cycle):
                loading.append(d)
            # 反向加载
            for d in np.linspace(0, -amp, num_points_per_cycle):
                loading.append(d)
            # 反向卸载
            for d in np.linspace(-amp, 0, num_points_per_cycle):
                loading.append(d)
        return loading

    @staticmethod
    def generate_monotonic_loading(max_displacement: float, num_points: int = 200) -> List[float]:
        """生成单向加载制度"""
        return np.linspace(0, max_displacement, num_points).tolist()


class HysteresisAnalyzer:
    """滞回曲线分析器"""

    @staticmethod
    def calculate_skeleton_curve(hysteresis_data: Dict[str, List[float]]) -> Dict[str, List[float]]:
        """从滞回曲线提取骨架曲线"""
        displacement = np.array(hysteresis_data["displacement"])
        force = np.array(hysteresis_data["force"])

        # 简化实现：取每个位移幅值下的最大力
        skeleton_disp = []
        skeleton_force = []

        # 按位移正负分组
        pos_mask = displacement >= 0
        neg_mask = displacement < 0

        if np.any(pos_mask):
            pos_disp = displacement[pos_mask]
            pos_force = force[pos_mask]
            unique_disp = np.unique(np.round(pos_disp, 2))
            for d in unique_disp:
                mask = np.abs(pos_disp - d) < 0.01
                max_f = np.max(pos_force[mask])
                skeleton_disp.append(d)
                skeleton_force.append(max_f)

        if np.any(neg_mask):
            neg_disp = displacement[neg_mask]
            neg_force = force[neg_mask]
            unique_disp = np.unique(np.round(neg_disp, 2))
            for d in unique_disp:
                mask = np.abs(neg_disp - d) < 0.01
                min_f = np.min(neg_force[mask])
                skeleton_disp.append(d)
                skeleton_force.append(min_f)

        # 排序
        sorted_indices = np.argsort(skeleton_disp)
        skeleton_disp = [skeleton_disp[i] for i in sorted_indices]
        skeleton_force = [skeleton_force[i] for i in sorted_indices]

        return {
            "displacement": skeleton_disp,
            "force": skeleton_force
        }

    @staticmethod
    def calculate_energy_dissipation(hysteresis_data: Dict[str, List[float]]) -> Dict[str, float]:
        """计算能量耗散"""
        displacement = np.array(hysteresis_data["displacement"])
        force = np.array(hysteresis_data["force"])

        total_energy = 0.0
        cycle_energy = []
        current_cycle = 0
        cycle_start_idx = 0

        for i in range(1, len(displacement)):
            # 计算增量功
            d_disp = displacement[i] - displacement[i-1]
            avg_force = (force[i] + force[i-1]) / 2
            delta_energy = avg_force * d_disp

            if delta_energy > 0:
                total_energy += delta_energy

            # 检测循环边界（位移过零点）
            if i > 0 and displacement[i-1] * displacement[i] < 0:
                cycle_energy.append(total_energy)
                current_cycle += 1

        return {
            "total_energy": total_energy,
            "energy_per_cycle": cycle_energy,
            "num_cycles": current_cycle
        }

    @staticmethod
    def calculate_stiffness_degradation(hysteresis_data: Dict[str, List[float]]) -> Dict[str, List[float]]:
        """计算刚度退化"""
        displacement = np.array(hysteresis_data["displacement"])
        force = np.array(hysteresis_data["force"])

        # 找峰值点
        peaks_disp = []
        peaks_force = []

        for i in range(1, len(displacement)-1):
            if abs(displacement[i]) > abs(displacement[i-1]) and \
               abs(displacement[i]) > abs(displacement[i+1]):
                peaks_disp.append(displacement[i])
                peaks_force.append(force[i])

        # 计算割线刚度
        secant_stiffness = []
        for d, f in zip(peaks_disp, peaks_force):
            if abs(d) > 0:
                k = f / d
                secant_stiffness.append(abs(k))

        return {
            "displacement": peaks_disp,
            "secant_stiffness": secant_stiffness
        }

    @staticmethod
    def calculate_equivalent_damping(hysteresis_data: Dict[str, List[float]],
                                     yield_force: float,
                                     yield_displacement: float) -> Dict[str, float]:
        """计算等效粘滞阻尼比"""
        displacement = np.array(hysteresis_data["displacement"])
        force = np.array(hysteresis_data["force"])

        # 计算总滞回耗能
        total_energy = 0.0
        for i in range(1, len(displacement)):
            d_disp = displacement[i] - displacement[i-1]
            avg_force = (force[i] + force[i-1]) / 2
            delta_energy = avg_force * d_disp
            if delta_energy > 0:
                total_energy += delta_energy

        # 计算最大应变能
        max_disp = np.max(np.abs(displacement))
        max_force = np.max(np.abs(force))
        strain_energy = 0.5 * max_force * max_disp

        # 等效阻尼比
        if strain_energy > 0:
            zeta_eq = total_energy / (4 * np.pi * strain_energy)
        else:
            zeta_eq = 0.0

        return {
            "equivalent_damping_ratio": zeta_eq,
            "total_hysteresis_energy": total_energy,
            "max_strain_energy": strain_energy
        }

    @staticmethod
    def calculate_ductility(hysteresis_data: Dict[str, List[float]],
                           yield_displacement: float) -> Dict[str, float]:
        """计算延性系数"""
        displacement = np.array(hysteresis_data["displacement"])

        max_displacement = np.max(np.abs(displacement))
        ductility_factor = max_displacement / yield_displacement if yield_displacement > 0 else 0

        return {
            "max_displacement": max_displacement,
            "yield_displacement": yield_displacement,
            "ductility_factor": ductility_factor
        }
