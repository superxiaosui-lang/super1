"""
地震分析模块 - 实现抗震节点的地震响应分析
包括反应谱分析、时程分析、增量动力分析(IDA)等
"""

import numpy as np
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum


class SeismicAnalysisType(str, Enum):
    """地震分析类型"""
    RESPONSE_SPECTRUM = "反应谱分析"
    TIME_HISTORY = "时程分析"
    IDA = "增量动力分析"
    PUSHOVER = "静力推覆分析"


@dataclass
class GroundMotion:
    """地震动记录"""
    name: str
    time_step: float
    acceleration: List[float]
    duration: float
    peak_acceleration: float
    strong_motion_duration: float
    frequency_content: Dict[str, float]


class SeismicResponseAnalyzer:
    """地震响应分析器"""

    def __init__(self):
        self.ground_motions: List[GroundMotion] = []
        self.response_data: Dict[str, Any] = {}

    def generate_design_spectrum(self, pga: float, site_class: str,
                                design_group: int, damping: float = 0.05) -> Dict[str, List[float]]:
        """生成设计反应谱"""
        # 特征周期
        Tg_map = {
            ("I0", 1): 0.20, ("I0", 2): 0.25, ("I0", 3): 0.30,
            ("I1", 1): 0.25, ("I1", 2): 0.30, ("I1", 3): 0.35,
            ("II", 1): 0.35, ("II", 2): 0.40, ("II", 3): 0.45,
            ("III", 1): 0.45, ("III", 2): 0.55, ("III", 3): 0.65,
            ("IV", 1): 0.65, ("IV", 2): 0.75, ("IV", 3): 0.90,
        }
        Tg = Tg_map.get((site_class, design_group), 0.40)

        # 阻尼调整系数
        if damping == 0.05:
            eta2 = 1.0
        else:
            eta2 = (0.05 / (0.05 + damping)) ** 0.3

        # 生成反应谱
        periods = np.linspace(0, 6, 600).tolist()
        spectral_acceleration = []

        for T in periods:
            if T == 0:
                Sa = pga
            elif T <= 0.1:
                Sa = pga * (1 + 15 * T) * eta2
            elif T <= Tg:
                Sa = 2.25 * pga * eta2
            elif T <= 5 * Tg:
                Sa = 2.25 * pga * (Tg / T) ** 0.9 * eta2
            else:
                Sa = 2.25 * pga * (Tg / (5 * Tg)) ** 0.9 * (5 * Tg / T) * eta2
            spectral_acceleration.append(Sa)

        return {
            "period": periods,
            "spectral_acceleration": spectral_acceleration,
            "Tg": Tg,
            "eta2": eta2
        }

    def analyze_response_spectrum(self, structure_periods: List[float],
                                 pga: float, site_class: str,
                                 design_group: int, damping: float = 0.05) -> Dict[str, Any]:
        """反应谱分析"""
        spectrum = self.generate_design_spectrum(pga, site_class, design_group, damping)

        # 计算各阶振型的地震作用
        modal_responses = []
        for i, T in enumerate(structure_periods):
            # 插值获取谱加速度
            Sa = np.interp(T, spectrum["period"], spectrum["spectral_acceleration"])
            modal_responses.append({
                "mode": i + 1,
                "period": T,
                "spectral_acceleration": Sa,
                "base_shear_coefficient": Sa / 9.81
            })

        # CQC或SRSS组合
        total_response = self._cqc_combination(modal_responses)

        return {
            "spectrum": spectrum,
            "modal_responses": modal_responses,
            "total_response": total_response
        }

    def _cqc_combination(self, modal_responses: List[Dict]) -> Dict[str, float]:
        """CQC组合"""
        # 简化实现：使用SRSS组合
        sum_sq = sum(resp["spectral_acceleration"]**2 for resp in modal_responses)
        return {
            "srss_acceleration": np.sqrt(sum_sq),
            "max_response": max(resp["spectral_acceleration"] for resp in modal_responses)
        }

    def analyze_time_history(self, ground_motion: GroundMotion,
                            mass: float, stiffness: float,
                            damping_ratio: float = 0.05) -> Dict[str, Any]:
        """时程分析"""
        dt = ground_motion.time_step
        n_steps = len(ground_motion.acceleration)

        # 结构参数
        omega_n = np.sqrt(stiffness / mass)
        T = 2 * np.pi / omega_n
        c = 2 * damping_ratio * mass * omega_n

        # Newmark-beta法参数
        gamma = 0.5
        beta = 0.25

        # 初始化
        displacement = np.zeros(n_steps)
        velocity = np.zeros(n_steps)
        acceleration = np.zeros(n_steps)

        # 初始条件
        u_prev = 0.0
        v_prev = 0.0
        a_prev = ground_motion.acceleration[0]

        # 有效刚度
        k_eff = stiffness + gamma / (beta * dt) * c + 1 / (beta * dt**2) * mass

        # 时程积分
        for i in range(1, n_steps):
            # 荷载增量
            p_inc = -mass * ground_motion.acceleration[i]

            # 有效荷载增量
            p_eff = p_inc + mass * (1/(beta*dt**2) * u_prev + 1/(beta*dt) * v_prev +
                                   (1/(2*beta) - 1) * a_prev) + \
                    c * (gamma/(beta*dt) * u_prev + (gamma/beta - 1) * v_prev +
                        dt * (gamma/(2*beta) - 1) * a_prev)

            # 求解位移增量
            du = p_eff / k_eff

            # 更新位移
            u_curr = u_prev + du

            # 更新加速度
            a_curr = 1/(beta*dt**2) * (u_curr - u_prev) - 1/(beta*dt) * v_prev - \
                    (1/(2*beta) - 1) * a_prev

            # 更新速度
            v_curr = v_prev + dt * ((1-gamma) * a_prev + gamma * a_curr)

            # 保存
            displacement[i] = u_curr
            velocity[i] = v_curr
            acceleration[i] = a_curr + ground_motion.acceleration[i]

            # 更新前一步
            u_prev = u_curr
            v_prev = v_curr
            a_prev = a_curr

        # 计算响应指标
        max_disp = np.max(np.abs(displacement))
        max_vel = np.max(np.abs(velocity))
        max_acc = np.max(np.abs(acceleration))

        # 计算基底剪力
        base_shear = stiffness * displacement

        return {
            "time": np.arange(n_steps) * dt,
            "displacement": displacement.tolist(),
            "velocity": velocity.tolist(),
            "acceleration": acceleration.tolist(),
            "base_shear": base_shear.tolist(),
            "max_displacement": max_disp,
            "max_velocity": max_vel,
            "max_acceleration": max_acc,
            "max_base_shear": np.max(np.abs(base_shear)),
            "period": T,
            "damping_ratio": damping_ratio
        }

    def analyze_ida(self, ground_motion: GroundMotion,
                   mass: float, stiffness: float,
                   intensity_levels: List[float]) -> Dict[str, Any]:
        """增量动力分析(IDA)"""
        ida_results = []

        for intensity in intensity_levels:
            # 缩放地震动
            scaled_gm = self._scale_ground_motion(ground_motion, intensity)

            # 时程分析
            result = self.analyze_time_history(scaled_gm, mass, stiffness)

            ida_results.append({
                "intensity": intensity,
                "max_displacement": result["max_displacement"],
                "max_base_shear": result["max_base_shear"],
                "max_acceleration": result["max_acceleration"],
                "collapse": result["max_displacement"] > 0.1  # 假设100mm为倒塌
            })

        # 计算IDA曲线
        intensities = [r["intensity"] for r in ida_results]
        max_disps = [r["max_displacement"] for r in ida_results]
        max_shears = [r["max_base_shear"] for r in ida_results]

        # 计算倒塌储备系数(CMR)
        median_capacity = np.median([r["max_displacement"] for r in ida_results if not r["collapse"]])
        cmr = median_capacity / 0.02 if median_capacity > 0 else 0

        return {
            "ida_curve": {
                "intensity": intensities,
                "max_displacement": max_disps,
                "max_base_shear": max_shears
            },
            "results": ida_results,
            "collapse_margin_ratio": cmr,
            "probability_of_collapse": sum(1 for r in ida_results if r["collapse"]) / len(ida_results)
        }

    def _scale_ground_motion(self, gm: GroundMotion, scale_factor: float) -> GroundMotion:
        """缩放地震动"""
        scaled_acc = [a * scale_factor for a in gm.acceleration]
        return GroundMotion(
            name=f"{gm.name}_scaled_{scale_factor:.2f}",
            time_step=gm.time_step,
            acceleration=scaled_acc,
            duration=gm.duration,
            peak_acceleration=gm.peak_acceleration * scale_factor,
            strong_motion_duration=gm.strong_motion_duration,
            frequency_content=gm.frequency_content
        )

    def generate_synthetic_ground_motion(self, pga: float, duration: float = 20.0,
                                        time_step: float = 0.01,
                                        target_spectrum: Optional[Dict] = None) -> GroundMotion:
        """生成人工地震动"""
        n_points = int(duration / time_step)
        time = np.linspace(0, duration, n_points)

        # 使用三角级数法生成
        if target_spectrum is None:
            # 使用简单模型
            frequencies = np.array([0.5, 1.0, 2.0, 5.0, 10.0])
            amplitudes = np.array([0.3, 0.5, 1.0, 0.7, 0.3])
        else:
            frequencies = np.array(target_spectrum.get("period", [1.0]))
            amplitudes = np.array(target_spectrum.get("spectral_acceleration", [1.0]))

        # 生成信号
        acceleration = np.zeros(n_points)
        for freq, amp in zip(frequencies, amplitudes):
            phase = np.random.uniform(0, 2*np.pi)
            acceleration += amp * np.sin(2*np.pi*freq*time + phase)

        # 应用包络函数
        envelope = self._envelope_function(time, duration)
        acceleration *= envelope

        # 归一化到目标PGA
        acceleration = acceleration / np.max(np.abs(acceleration)) * pga

        return GroundMotion(
            name="synthetic",
            time_step=time_step,
            acceleration=acceleration.tolist(),
            duration=duration,
            peak_acceleration=pga,
            strong_motion_duration=duration * 0.6,
            frequency_content={"dominant_freq": 2.0}
        )

    def _envelope_function(self, time: np.ndarray, duration: float) -> np.ndarray:
        """生成强度包络函数"""
        # 三段式包络
        t1 = duration * 0.1  # 上升段
        t2 = duration * 0.7  # 平稳段结束

        envelope = np.zeros_like(time)
        for i, t in enumerate(time):
            if t < t1:
                envelope[i] = (t / t1) ** 2
            elif t < t2:
                envelope[i] = 1.0
            else:
                envelope[i] = np.exp(-2 * (t - t2) / duration)

        return envelope

    def analyze_seismic_performance(self, hysteresis_data: Dict[str, List[float]],
                                   yield_displacement: float,
                                   collapse_displacement: float,
                                   design_displacement: float) -> Dict[str, Any]:
        """抗震性能评估"""
        # 计算性能点
        displacement = np.array(hysteresis_data["displacement"])
        force = np.array(hysteresis_data["force"])

        # 找到各性能水准对应的位移
        performance_points = {
            "immediate_occupancy": {
                "displacement": yield_displacement,
                "force": np.interp(yield_displacement, np.abs(displacement), force),
                "description": "正常使用"
            },
            "life_safety": {
                "displacement": (yield_displacement + collapse_displacement) / 2,
                "force": np.interp((yield_displacement + collapse_displacement) / 2,
                                  np.abs(displacement), force),
                "description": "生命安全"
            },
            "collapse_prevention": {
                "displacement": collapse_displacement * 0.8,
                "force": np.interp(collapse_displacement * 0.8,
                                  np.abs(displacement), force),
                "description": "防止倒塌"
            }
        }

        # 计算延性系数
        ductility = collapse_displacement / yield_displacement

        # 计算超强系数
        max_force = np.max(np.abs(force))
        yield_force = np.interp(yield_displacement, np.abs(displacement), force)
        overstrength = max_force / yield_force if yield_force > 0 else 0

        return {
            "performance_points": performance_points,
            "ductility_factor": ductility,
            "overstrength_factor": overstrength,
            "performance_level": self._assess_performance_level(
                np.max(np.abs(displacement)),
                yield_displacement,
                collapse_displacement
            )
        }

    def _assess_performance_level(self, max_displacement: float,
                                 yield_displacement: float,
                                 collapse_displacement: float) -> str:
        """评估性能水平"""
        ratio = max_displacement / collapse_displacement if collapse_displacement > 0 else 0

        if ratio < 0.3:
            return "Immediate Occupancy (IO)"
        elif ratio < 0.6:
            return "Life Safety (LS)"
        elif ratio < 0.8:
            return "Collapse Prevention (CP)"
        else:
            return "Collapse"

    def calculate_seismic_demand(self, period: float, damping: float,
                                site_class: str, intensity: str) -> Dict[str, float]:
        """计算地震需求"""
        # 特征周期
        Tg_map = {
            "I0": 0.25, "I1": 0.35, "II": 0.45, "III": 0.65, "IV": 0.90
        }
        Tg = Tg_map.get(site_class, 0.45)

        # PGA
        pga_map = {"6度": 0.05, "7度": 0.10, "8度": 0.20, "9度": 0.40}
        pga = pga_map.get(intensity, 0.10)

        # 谱加速度
        if period <= 0.1:
            Sa = pga * (1 + 15 * period)
        elif period <= Tg:
            Sa = 2.25 * pga
        elif period <= 5 * Tg:
            Sa = 2.25 * pga * (Tg / period) ** 0.9
        else:
            Sa = 2.25 * pga * (Tg / (5 * Tg)) ** 0.9 * (5 * Tg / period)

        # 阻尼调整
        if damping != 0.05:
            eta2 = (0.05 / (0.05 + damping)) ** 0.3
            Sa *= eta2

        return {
            "spectral_acceleration": Sa,
            "spectral_displacement": Sa * (period / (2 * np.pi)) ** 2,
            "peak_acceleration": pga,
            "characteristic_period": Tg
        }
