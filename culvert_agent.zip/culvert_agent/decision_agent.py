"""
Agent 3: 决策优化Agent (Decision & Optimization Agent)
职责：安全评估、参数优化建议、施工指导输出
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .data_agent import ParsedParameters
from .compute_agent import FullAnalysisResult


@dataclass
class SafetyGrade:
    """安全评级"""
    grade: str                      # A/B/C
    stress_safety_factor: float     # 应力安全系数
    deformation_safety_factor: float  # 变形安全系数
    overall_score: float            # 综合得分 (0-100)
    description: str                # 评级说明


@dataclass
class OptimizationSuggestion:
    """参数优化建议"""
    parameter_name: str     # 参数名称
    current_value: float    # 当前值
    recommended_value: float  # 推荐值
    reason: str             # 推荐理由
    expected_improvement: str  # 预期改善效果


@dataclass
class ConstructionGuidance:
    """施工指导"""
    backfill_speed: str         # 回填速度建议
    compaction_standard: str    # 压实度标准
    monitoring_points: list[str]  # 关键监测点
    bolt_positions: list[str]   # 螺栓拼接位置建议
    special_notes: list[str]    # 特殊注意事项


@dataclass
class DecisionReport:
    """决策报告"""
    safety_grade: SafetyGrade
    optimization_suggestions: list[OptimizationSuggestion]
    construction_guidance: ConstructionGuidance
    summary: str
    detailed_results: Optional[FullAnalysisResult] = None


class DecisionOptimizationAgent:
    """
    决策优化Agent

    基于计算推理Agent的分析结果，进行安全评级、参数优化和施工指导
    """

    def __init__(self):
        # 安全评级阈值
        self.grade_thresholds = {
            "A": {"stress_sf": 1.5, "deform_sf": 1.3, "score": 80},
            "B": {"stress_sf": 1.2, "deform_sf": 1.1, "score": 60},
            "C": {"stress_sf": 1.0, "deform_sf": 1.0, "score": 0},
        }

        # 推荐波纹参数组合 (基于论文优化建议)
        self.recommended_corrugations = [
            (230, 64),   # 推荐: 230mm×64mm
            (200, 55),   # 备选: 200mm×55mm
            (380, 140),  # 经济: 380mm×140mm
        ]

        # 推荐板厚范围
        self.recommended_thickness_range = (8.0, 12.0)  # mm

        # 推荐螺栓拼接位置 (顺时针方向)
        self.recommended_bolt_positions = ["30°", "180°", "330°"]

    # ========================================================================
    # 安全评级
    # ========================================================================

    def assess_safety(
        self, params: ParsedParameters, analysis: FullAnalysisResult
    ) -> SafetyGrade:
        """
        综合安全评级

        Parameters
        ----------
        params : ParsedParameters
        analysis : FullAnalysisResult

        Returns
        -------
        SafetyGrade
        """
        sr = analysis.structural_response
        sf = analysis.safety_factors

        stress_sf = sf.get("stress_safety_factor", 0)
        deform_sf = sf.get("deformation_safety_factor", 0)

        # 计算综合得分
        stress_score = min(100, stress_sf / 2.0 * 100)  # 2.0为满分基准
        deform_score = min(100, deform_sf / 1.5 * 100)  # 1.5为满分基准
        overall_score = 0.5 * stress_score + 0.5 * deform_score

        # 评级
        if stress_sf >= 1.5 and deform_sf >= 1.3 and overall_score >= 80:
            grade = "A"
            desc = "结构安全储备充足，满足设计要求"
        elif stress_sf >= 1.2 and deform_sf >= 1.1 and overall_score >= 60:
            grade = "B"
            desc = "结构安全储备适中，建议加强监测"
        else:
            grade = "C"
            desc = "结构安全储备不足，需要优化设计"

        return SafetyGrade(
            grade=grade,
            stress_safety_factor=stress_sf,
            deformation_safety_factor=deform_sf,
            overall_score=overall_score,
            description=desc,
        )

    # ========================================================================
    # 参数优化建议
    # ========================================================================

    def suggest_optimizations(
        self, params: ParsedParameters, analysis: FullAnalysisResult
    ) -> list[OptimizationSuggestion]:
        """
        生成参数优化建议

        Parameters
        ----------
        params : ParsedParameters
        analysis : FullAnalysisResult

        Returns
        -------
        list[OptimizationSuggestion]
        """
        suggestions = []
        sr = analysis.structural_response

        # 1. 波纹尺寸优化
        current_pitch = params.corrugation_pitch
        current_depth = params.corrugation_depth

        # 如果应力过大，建议增大波纹尺寸
        if sr.max_stress > params.steel.yield_strength * 0.7:
            # 论文建议230mm×64mm
            if current_pitch < 230:
                suggestions.append(OptimizationSuggestion(
                    parameter_name="波距a",
                    current_value=current_pitch,
                    recommended_value=230,
                    reason="当前波距偏小，应力集中明显。论文推荐230mm×64mm组合",
                    expected_improvement="应力降低约13.67%",
                ))
            if current_depth < 64:
                suggestions.append(OptimizationSuggestion(
                    parameter_name="波高b",
                    current_value=current_depth,
                    recommended_value=64,
                    reason="当前波高偏小，刚度不足。论文推荐64mm波高",
                    expected_improvement="竖向变形降低约15-20%",
                ))

        # 2. 板厚优化
        if sr.deformation_ratio > params.max_deformation_ratio * 100 * 0.8:
            # 变形接近限值，建议增大板厚
            min_recommended = max(
                params.plate_thickness + 2,
                self.recommended_thickness_range[0],
            )
            suggestions.append(OptimizationSuggestion(
                parameter_name="板厚t",
                current_value=params.plate_thickness,
                recommended_value=min_recommended,
                reason="变形接近规范限值(2%)，增大板厚可有效减小变形",
                expected_improvement=f"板厚每增加2mm，变形降低约30-45%",
            ))
        elif sr.deformation_ratio < params.max_deformation_ratio * 100 * 0.3:
            # 变形远小于限值，可考虑减小板厚（经济优化）
            suggestions.append(OptimizationSuggestion(
                parameter_name="板厚t",
                current_value=params.plate_thickness,
                recommended_value=max(6, params.plate_thickness - 2),
                reason="变形远小于限值，可适当减小板厚以节省材料",
                expected_improvement="节省钢材约20-30%",
            ))

        # 3. 螺栓拼接位置
        suggestions.append(OptimizationSuggestion(
            parameter_name="螺栓拼接位置",
            current_value=0,
            recommended_value=0,
            reason="论文建议螺栓拼接位置设在顺时针30°、180°、330°处",
            expected_improvement="改善拼接处应力分布，提高整体刚度",
        ))

        return suggestions

    # ========================================================================
    # 施工指导
    # ========================================================================

    def generate_construction_guidance(
        self, params: ParsedParameters, analysis: FullAnalysisResult
    ) -> ConstructionGuidance:
        """
        生成施工指导

        Parameters
        ----------
        params : ParsedParameters
        analysis : FullAnalysisResult

        Returns
        -------
        ConstructionGuidance
        """
        sr = analysis.structural_response

        # 回填速度建议
        if sr.max_stress > params.steel.yield_strength * 0.6:
            backfill_speed = "控制在每层40cm以内，分层压实，回填速度不宜过快"
        else:
            backfill_speed = "每层40cm标准分层回填，确保压实度"

        # 压实度标准
        compaction = f"压实度≥{params.compaction_ratio * 100:.0f}%标准击实密度"

        # 关键监测点
        monitoring = [
            "管顶中心(D1): 监测最大竖向变形",
            "管侧90°处(S2/S3): 监测最大应力",
            "管底(C1): 监测基底压力",
            "管顶填土面(C7-C13): 监测土压力分布",
        ]

        # 螺栓拼接位置
        bolt_positions = [
            f"顺时针{pos}处" for pos in self.recommended_bolt_positions
        ]

        # 特殊注意事项
        notes = []
        if sr.max_stress > params.steel.yield_strength * 0.5:
            notes.append("管侧90°处应力集中明显，需特别关注该区域的应力设计")
        if sr.deformation_ratio > params.max_deformation_ratio * 100 * 0.7:
            notes.append("变形接近规范限值，建议增加监测频率")
        if params.rise_span_ratio > 0.8:
            notes.append("矢跨比较大，回填时注意两侧对称加载，避免偏压")
        if params.span > 8:
            notes.append("超大跨径涵洞，建议采用管-土协同设计方法")

        notes.append("回填过程中实时监测变形，变形超限时暂停施工")

        return ConstructionGuidance(
            backfill_speed=backfill_speed,
            compaction_standard=compaction,
            monitoring_points=monitoring,
            bolt_positions=bolt_positions,
            special_notes=notes,
        )

    # ========================================================================
    # 完整决策报告
    # ========================================================================

    def generate_report(
        self, params: ParsedParameters, analysis: FullAnalysisResult
    ) -> DecisionReport:
        """
        生成完整决策报告

        Parameters
        ----------
        params : ParsedParameters
        analysis : FullAnalysisResult

        Returns
        -------
        DecisionReport
        """
        safety = self.assess_safety(params, analysis)
        suggestions = self.suggest_optimizations(params, analysis)
        guidance = self.generate_construction_guidance(params, analysis)

        # 生成摘要
        sr = analysis.structural_response
        ar = analysis.soil_arching

        summary = (
            f"【分析摘要】\n"
            f"涵洞参数: 跨径L={params.span}m, 拱高H={params.rise}m, "
            f"波纹{params.corrugation_size}, 板厚t={params.plate_thickness}mm\n"
            f"安全评级: {safety.grade}级 "
            f"(应力安全系数={safety.stress_safety_factor:.2f}, "
            f"变形安全系数={safety.deformation_safety_factor:.2f})\n"
            f"土拱效应系数Mf={ar.mf_coefficient:.4f}\n"
            f"最大应力: {sr.max_stress:.1f}MPa (位置: {sr.max_stress_location})\n"
            f"最大变形: {sr.max_deformation:.1f}mm, "
            f"变形比β={sr.deformation_ratio:.2f}% "
            f"({'满足' if sr.meets_specification else '不满足'}规范要求)\n"
            f"优化建议数: {len(suggestions)}条"
        )

        return DecisionReport(
            safety_grade=safety,
            optimization_suggestions=suggestions,
            construction_guidance=guidance,
            summary=summary,
            detailed_results=analysis,
        )
