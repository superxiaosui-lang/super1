"""
多Agent协作编排器 (Orchestrator)
协调数据感知Agent、计算推理Agent、决策优化Agent的协作执行
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .data_agent import DataPerceptionAgent, ParsedParameters
from .compute_agent import ComputationalReasoningAgent, FullAnalysisResult
from .decision_agent import DecisionOptimizationAgent, DecisionReport
from .material_db import CulvertConfig


@dataclass
class PipelineResult:
    """流水线执行结果"""
    parsed_params: ParsedParameters
    validation_warnings: list[str]
    derived_params: dict
    analysis_result: FullAnalysisResult
    decision_report: DecisionReport
    pipeline_log: list[str] = field(default_factory=list)


class CulvertAnalysisOrchestrator:
    """
    涵洞分析多Agent编排器

    三阶段流水线:
    Agent 1 (数据感知) → Agent 2 (计算推理) → Agent 3 (决策优化)
    """

    def __init__(self):
        self.data_agent = DataPerceptionAgent()
        self.compute_agent = ComputationalReasoningAgent()
        self.decision_agent = DecisionOptimizationAgent()

    def run(self, config: CulvertConfig) -> PipelineResult:
        """
        执行完整的三阶段分析流水线

        Parameters
        ----------
        config : CulvertConfig - 涵洞配置参数

        Returns
        -------
        PipelineResult - 完整分析结果
        """
        log = []

        # ================================================================
        # Stage 1: Agent 1 - 数据感知
        # ================================================================
        log.append("=" * 60)
        log.append("[Stage 1] 数据感知Agent: 解析输入参数...")
        log.append("=" * 60)

        params = self.data_agent.parse_config(config)
        log.append(f"  跨径 L = {params.span} m")
        log.append(f"  拱高 H = {params.rise} m")
        log.append(f"  矢跨比 H/L = {params.rise_span_ratio:.4f}")
        log.append(f"  波纹尺寸 = {params.corrugation_size}")
        log.append(f"  板厚 t = {params.plate_thickness} mm")
        log.append(f"  钢材 = {params.steel.name} (σ_y={params.steel.yield_strength}MPa)")
        log.append(f"  土体 = {params.soil.name} (φ={params.soil.friction_angle}°, c={params.soil.cohesion}kPa)")

        # 参数校验
        warnings = self.data_agent.validate_input(params)
        if warnings:
            log.append("\n  [参数校验]")
            for w in warnings:
                log.append(f"    {w}")

        # 派生参数
        derived = self.data_agent.compute_derived_params(params)
        log.append(f"\n  等效圆弧半径 R = {derived['equivalent_radius']:.3f} m")
        log.append(f"  截面面积 A = {derived['cross_section_area']:.3f} m²")

        # ================================================================
        # Stage 2: Agent 2 - 计算推理
        # ================================================================
        log.append("\n" + "=" * 60)
        log.append("[Stage 2] 计算推理Agent: 执行计算分析...")
        log.append("=" * 60)

        analysis = self.compute_agent.run_full_analysis(params)
        ar = analysis.soil_arching
        ep = analysis.earth_pressure
        sr = analysis.structural_response

        log.append(f"\n  [土拱效应分析]")
        log.append(f"    土拱效应系数 Mf = {ar.mf_coefficient:.4f}")
        log.append(f"    管顶中心竖向压力 V0 = {ar.vertical_pressure_center:.2f} kPa")
        log.append(f"    管顶边缘竖向压力 V1 = {ar.vertical_pressure_edge:.2f} kPa")
        log.append(f"    分布类型: {ar.pressure_distribution}")
        log.append(f"    V1/V0比值 = {ar.distribution_ratio:.3f}")

        log.append(f"\n  [土压力分布]")
        log.append(f"    最大土压力 = {ep.max_pressure:.2f} kPa")
        log.append(f"    最小土压力 = {ep.min_pressure:.2f} kPa")
        log.append(f"    最大压力位置: {ep.max_pressure_location}")

        log.append(f"\n  [结构响应]")
        log.append(f"    最大应力 = {sr.max_stress:.2f} MPa")
        log.append(f"    最大应力位置: {sr.max_stress_location}")
        log.append(f"    最大竖向变形 = {sr.max_deformation:.2f} mm")
        log.append(f"    变形比 β = {sr.deformation_ratio:.4f}%")
        log.append(f"    规范要求(≤2%): {'满足' if sr.meets_specification else '不满足'}")

        log.append(f"\n  [安全系数]")
        for k, v in analysis.safety_factors.items():
            log.append(f"    {k} = {v:.4f}")

        # ================================================================
        # Stage 3: Agent 3 - 决策优化
        # ================================================================
        log.append("\n" + "=" * 60)
        log.append("[Stage 3] 决策优化Agent: 生成决策报告...")
        log.append("=" * 60)

        report = self.decision_agent.generate_report(params, analysis)

        log.append(f"\n  [安全评级]")
        sg = report.safety_grade
        log.append(f"    评级: {sg.grade}级")
        log.append(f"    应力安全系数: {sg.stress_safety_factor:.3f}")
        log.append(f"    变形安全系数: {sg.deformation_safety_factor:.3f}")
        log.append(f"    综合得分: {sg.overall_score:.1f}/100")
        log.append(f"    说明: {sg.description}")

        log.append(f"\n  [优化建议]")
        for i, s in enumerate(report.optimization_suggestions, 1):
            if s.parameter_name == "螺栓拼接位置":
                log.append(f"    {i}. {s.parameter_name}: {s.reason}")
            else:
                log.append(
                    f"    {i}. {s.parameter_name}: "
                    f"{s.current_value} → {s.recommended_value} "
                    f"({s.reason})"
                )

        log.append(f"\n  [施工指导]")
        cg = report.construction_guidance
        log.append(f"    回填速度: {cg.backfill_speed}")
        log.append(f"    压实标准: {cg.compaction_standard}")
        log.append(f"    螺栓位置: {', '.join(cg.bolt_positions)}")
        log.append(f"    关键监测点:")
        for mp in cg.monitoring_points:
            log.append(f"      - {mp}")
        log.append(f"    注意事项:")
        for n in cg.special_notes:
            log.append(f"      - {n}")

        log.append("\n" + "=" * 60)
        log.append("[Pipeline Complete] 三阶段分析流水线执行完毕")
        log.append("=" * 60)

        return PipelineResult(
            parsed_params=params,
            validation_warnings=warnings,
            derived_params=derived,
            analysis_result=analysis,
            decision_report=report,
            pipeline_log=log,
        )

    def print_report(self, result: PipelineResult) -> None:
        """打印完整分析报告"""
        for line in result.pipeline_log:
            print(line)
        print("\n" + result.decision_report.summary)
