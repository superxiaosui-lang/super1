"""
材料属性数据库
包含波纹钢管涵常用钢材和回填土材料参数
"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SteelMaterial:
    """钢材材料属性"""
    name: str
    yield_strength: float   # 屈服强度 σ_y (MPa)
    tensile_strength: float # 抗拉强度 σ_b (MPa)
    elastic_modulus: float  # 弹性模量 E (GPa)
    density: float          # 密度 ρ (kg/m³)
    poisson_ratio: float    # 泊松比 ν


@dataclass
class SoilMaterial:
    """回填土材料属性"""
    name: str
    elastic_modulus: float  # 弹性模量 E (MPa)
    density: float          # 密度 ρ (kg/m³)
    cohesion: float         # 粘聚力 c (kPa)
    friction_angle: float   # 内摩擦角 φ (°)
    poisson_ratio: float = 0.35  # 泊松比 ν


# 常用钢材数据库
STEEL_DB: dict[str, SteelMaterial] = {
    "Q235": SteelMaterial(
        name="Q235", yield_strength=235, tensile_strength=370,
        elastic_modulus=206, density=7850, poisson_ratio=0.30,
    ),
    "Q345": SteelMaterial(
        name="Q345", yield_strength=345, tensile_strength=470,
        elastic_modulus=206, density=7850, poisson_ratio=0.30,
    ),
    "Q355": SteelMaterial(
        name="Q355", yield_strength=355, tensile_strength=450,
        elastic_modulus=210, density=7850, poisson_ratio=0.30,
    ),
    "Q420": SteelMaterial(
        name="Q420", yield_strength=420, tensile_strength=520,
        elastic_modulus=206, density=7850, poisson_ratio=0.30,
    ),
}

# 常用回填土数据库
SOIL_DB: dict[str, SoilMaterial] = {
    "砂土": SoilMaterial(
        name="砂土", elastic_modulus=40, density=1800,
        cohesion=0, friction_angle=30, poisson_ratio=0.30,
    ),
    "碎石土": SoilMaterial(
        name="碎石土", elastic_modulus=55, density=2000,
        cohesion=5, friction_angle=35, poisson_ratio=0.30,
    ),
    "粉质黏土": SoilMaterial(
        name="粉质黏土", elastic_modulus=25, density=1900,
        cohesion=20, friction_angle=22, poisson_ratio=0.35,
    ),
    "黏土": SoilMaterial(
        name="黏土", elastic_modulus=20, density=1850,
        cohesion=30, friction_angle=18, poisson_ratio=0.35,
    ),
    "黄土": SoilMaterial(
        name="黄土", elastic_modulus=30, density=1700,
        cohesion=25, friction_angle=25, poisson_ratio=0.35,
    ),
    "现场回填土": SoilMaterial(
        name="现场回填土", elastic_modulus=35, density=1800,
        cohesion=20, friction_angle=25, poisson_ratio=0.35,
    ),
}


@dataclass
class CulvertConfig:
    """涵洞几何与施工配置"""
    span: float              # 跨径 L (m)
    rise: float              # 拱高 H (m)
    length: float            # 涵洞长度 (m)
    corrugation_pitch: float # 波距 a (mm)
    corrugation_depth: float # 波高 b (mm)
    plate_thickness: float   # 板厚 t (mm)
    steel_grade: str = "Q355"
    soil_type: str = "现场回填土"
    backfill_heights: list[float] = field(default_factory=list)
    compaction_ratio: float = 0.93  # 压实度
    max_deformation_ratio: float = 0.02  # 允许变形比 2%

    def __post_init__(self):
        if not self.backfill_heights:
            self.backfill_heights = [0.5 * i for i in range(1, 34)]
