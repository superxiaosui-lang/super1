"""
Agent 1: 数据感知Agent (Data Perception Agent)
职责：输入参数解析、材料属性匹配、正交实验方案设计
"""
from __future__ import annotations

import math
import itertools
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from .material_db import (
    STEEL_DB, SOIL_DB, SteelMaterial, SoilMaterial, CulvertConfig,
)


@dataclass
class ParsedParameters:
    """解析后的标准参数集"""
    # 几何参数
    span: float               # 跨径 L (m)
    rise: float               # 拱高 H (m)
    length: float             # 涵洞长度 (m)
    corrugation_pitch: float  # 波距 a (mm)
    corrugation_depth: float  # 波高 b (mm)
    plate_thickness: float    # 板厚 t (mm)
    # 材料参数
    steel: SteelMaterial
    soil: SoilMaterial
    # 施工参数
    backfill_heights: list[float]
    compaction_ratio: float
    max_deformation_ratio: float
    # 派生参数
    span_radius: float = 0.0       # 等效圆弧半径 R (m)
    rise_span_ratio: float = 0.0   # 矢跨比 H/L
    corrugation_size: str = ""     # 波纹尺寸描述 "a×b"

    def __post_init__(self):
        self.rise_span_ratio = self.rise / self.span
        self.corrugation_size = f"{self.corrugation_pitch}mm×{self.corrugation_depth}mm"
        # 管拱形等效圆弧半径: R = (L² + 4H²) / (8H)
        self.span_radius = (self.span ** 2 + 4 * self.rise ** 2) / (8 * self.rise)


@dataclass
class OrthogonalExperiment:
    """正交实验设计"""
    factors: dict[str, list[float]]
    levels: int
    experiment_matrix: list[dict[str, float]] = field(default_factory=list)
    mf_results: list[float] = field(default_factory=list)

    def design(self, n_factors: int = 5, n_levels: int = 4) -> list[dict]:
        """生成L16(4^5)正交实验表"""
        factor_names = list(self.factors.keys())[:n_factors]
        # 确保每个因子有n_levels个水平值
        factor_levels = {}
        for name in factor_names:
            vals = self.factors[name]
            if len(vals) > n_levels:
                # 均匀取样
                indices = np.linspace(0, len(vals) - 1, n_levels, dtype=int)
                factor_levels[name] = [vals[i] for i in indices]
            else:
                factor_levels[name] = vals[:n_levels]

        # L16(4^5)正交表
        orthogonal_table = [
            [0, 0, 0, 0, 0],
            [0, 1, 1, 1, 1],
            [0, 2, 2, 2, 2],
            [0, 3, 3, 3, 3],
            [1, 0, 1, 2, 3],
            [1, 1, 0, 3, 2],
            [1, 2, 3, 0, 1],
            [1, 3, 2, 1, 0],
            [2, 0, 2, 3, 1],
            [2, 1, 3, 2, 0],
            [2, 2, 0, 1, 3],
            [2, 3, 1, 0, 2],
            [3, 0, 3, 1, 2],
            [3, 1, 2, 0, 3],
            [3, 2, 1, 3, 0],
            [3, 3, 0, 2, 1],
        ]

        self.experiment_matrix = []
        for row in orthogonal_table:
            exp = {}
            for j, name in enumerate(factor_names):
                level_idx = row[j]
                exp[name] = factor_levels[name][level_idx]
            self.experiment_matrix.append(exp)

        return self.experiment_matrix


class DataPerceptionAgent:
    """数据感知Agent：解析输入参数、匹配材料、设计正交实验"""

    def __init__(self):
        self.steel_db = STEEL_DB
        self.soil_db = SOIL_DB

    def parse_config(self, config: CulvertConfig) -> ParsedParameters:
        """从CulvertConfig解析标准参数"""
        steel = self._get_steel(config.steel_grade)
        soil = self._get_soil(config.soil_type)

        return ParsedParameters(
            span=config.span,
            rise=config.rise,
            length=config.length,
            corrugation_pitch=config.corrugation_pitch,
            corrugation_depth=config.corrugation_depth,
            plate_thickness=config.plate_thickness,
            steel=steel,
            soil=soil,
            backfill_heights=config.backfill_heights,
            compaction_ratio=config.compaction_ratio,
            max_deformation_ratio=config.max_deformation_ratio,
        )

    def _get_steel(self, grade: str) -> SteelMaterial:
        if grade not in self.steel_db:
            raise ValueError(
                f"未知钢材牌号: {grade}，可选: {list(self.steel_db.keys())}"
            )
        return self.steel_db[grade]

    def _get_soil(self, soil_type: str) -> SoilMaterial:
        if soil_type not in self.soil_db:
            raise ValueError(
                f"未知土体类型: {soil_type}，可选: {list(self.soil_db.keys())}"
            )
        return self.soil_db[soil_type]

    def design_orthogonal_experiment(
        self,
        params: ParsedParameters,
        span_range: tuple[float, float] = (5.0, 20.0),
        rise_range: tuple[float, float] = (3.0, 15.0),
        corrugation_variants: Optional[list[tuple[float, float]]] = None,
        thickness_range: tuple[float, float] = (6.0, 14.0),
    ) -> OrthogonalExperiment:
        """
        设计正交实验方案

        Parameters
        ----------
        params : ParsedParameters - 基准参数
        span_range : (min, max) 跨径变化范围 (m)
        rise_range : (min, max) 拱高变化范围 (m)
        corrugation_variants : 波纹尺寸变体列表 [(pitch, depth), ...]
        thickness_range : (min, max) 板厚变化范围 (mm)

        Returns
        -------
        OrthogonalExperiment : 正交实验设计对象
        """
        if corrugation_variants is None:
            corrugation_variants = [
                (150, 50), (200, 55), (230, 64), (380, 140), (400, 150),
            ]

        # 将波纹变体转换为等效的"波纹面积"因子便于正交分析
        corrugation_areas = [p * d for p, d in corrugation_variants]

        factors = {
            "span": list(np.linspace(*span_range, 8)),
            "rise": list(np.linspace(*rise_range, 8)),
            "corrugation_area": corrugation_areas,
            "thickness": list(np.linspace(*thickness_range, 8)),
            "elastic_modulus": [170, 190, 210, 230],  # GPa
        }

        oe = OrthogonalExperiment(factors=factors, levels=4)
        oe.design()
        return oe

    def compute_derived_params(self, params: ParsedParameters) -> dict:
        """计算派生几何参数"""
        R = params.span_radius
        L = params.span
        H = params.rise
        # 涵洞截面面积近似（抛物线形）
        area = (2.0 / 3.0) * L * H
        # 涵洞截面周长近似
        perimeter = L + 2 * math.sqrt((L / 2) ** 2 + H ** 2)
        # 涵洞体积
        volume = area * params.length

        return {
            "equivalent_radius": R,
            "rise_span_ratio": params.rise_span_ratio,
            "cross_section_area": area,
            "perimeter": perimeter,
            "volume": volume,
            "corrugation_size": params.corrugation_size,
        }

    def validate_input(self, params: ParsedParameters) -> list[str]:
        """校验输入参数的合理性"""
        warnings = []

        if params.span > 5.0:
            warnings.append(
                f"[INFO] 跨径L={params.span}m > 5m，属于超大跨径涵洞，"
                f"需按超大跨径管拱形涵洞专项分析"
            )

        ratio = params.rise_span_ratio
        if ratio < 0.3 or ratio > 1.2:
            warnings.append(
                f"[WARN] 矢跨比H/L={ratio:.3f}不在常规范围(0.3~1.2)，"
                f"请确认几何参数"
            )

        if params.plate_thickness < 4:
            warnings.append(
                f"[WARN] 板厚t={params.plate_thickness}mm过薄，"
                f"可能导致局部屈曲"
            )

        if params.plate_thickness > 20:
            warnings.append(
                f"[WARN] 板厚t={params.plate_thickness}mm过厚，"
                f"经济性较差"
            )

        if params.corrugation_pitch < 100 or params.corrugation_pitch > 500:
            warnings.append(
                f"[WARN] 波距a={params.corrugation_pitch}mm超出常见范围(100~500mm)"
            )

        if params.corrugation_depth < 30 or params.corrugation_depth > 200:
            warnings.append(
                f"[WARN] 波高b={params.corrugation_depth}mm超出常见范围(30~200mm)"
            )

        return warnings
